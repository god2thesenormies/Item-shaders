# Item Shaders

A client-side Fabric mod that paints shader effects over your first-person hand and held items,
with an in-game menu to configure them.

![Minecraft 1.21.11](https://img.shields.io/badge/minecraft-1.21.11-brightgreen)
![Fabric](https://img.shields.io/badge/loader-fabric-dbd0b4)
![Licence](https://img.shields.io/badge/licence-all%20rights%20reserved-red)

---

## What it does

The mod intercepts the single call that draws your hand, redirects it into its own render target,
and then runs that silhouette through a short post-processing chain before blending it back onto the
screen:

1. **Blur** — smooths the silhouette into a rounded surface and builds the glow.
2. **Orient** — works out which way the item's pixel grid runs on screen, so bevels follow the
   texture rather than the screen axes.
3. **Jump flood** — builds an exact signed distance field, so outlines and glass edges follow every
   stair-step of a pixel-art silhouette instead of smearing across it.
4. **Composite** — blends the glow, the outline and the chosen effect back over the scene.

### Effects

| Effect | Notes |
| --- | --- |
| **Liquid Metal** | Flowing four-colour metal. Presets: Default, Neon, Chrome, Ocean, Toxic, Fire, plus Custom with full control over pattern, noise, warp, palette and shine. |
| **Glass** | Refraction, dispersion, reflection, frost and a polished bevel. Presets: Clear, Frosted, Crystal, Prism, Smoky, Ice, Bubble, Mirror, plus Custom. |
| **Water** | Rolling waves with caustics, refraction and sun glint. |
| **Chrome** | Polished metal with sliding reflections and a bright rim. |
| **Outline** | A clean line around the hand over a flat fill. |
| **Aurora** | Drifting light curtains over a star field. |
| **Galaxy** | Swirling nebula clouds with twinkling stars. |
| **Hologram** | Scanlines, glitch slices and flicker. |
| **Electric** | Crawling arcs with a glow. |
| **Lava** | Cooled rock plates with molten cracks. |

Each effect has its own section of settings, plus shared controls for the outline, the glow, the rim
light and the colour mode (static, rainbow, pulse, gradient, or taken from the effect itself).

### The menu

A self-contained interface, not a vanilla options screen: a sidebar, a top bar with live search,
collapsible cards, spring-animated controls, an HSV colour picker, rebindable keys, and Rubik text
rendered through the mod's own smooth-font path. **Right Shift** opens it by default; the key, the
menu scale, the animation speed, the accent colours and the corner radius are all configurable.

Settings are saved to `.minecraft/config/itemshaders.json` when the menu closes and when the game
exits.

---

## Installing

1. Install [Fabric Loader](https://fabricmc.net/use/installer) 0.19.3 or newer for Minecraft 1.21.11.
2. Put [Fabric API](https://modrinth.com/mod/fabric-api) in your `mods` folder.
3. Put `itemshaders-<version>.jar` in your `mods` folder.

Client-side only. It does nothing on a server and does not need to be installed on one.

### Version support

There is one jar per Minecraft version. Take the one matching your game:

| Minecraft | Jar |
| --- | --- |
| 1.21.11 | `itemshaders-<version>+1.21.11.jar` |
| 1.21.10 | `itemshaders-<version>+1.21.10.jar` |
| 1.21.9 | `itemshaders-<version>+1.21.9.jar` |

Each jar refuses to load on a version it was not built for, so there is nothing to get wrong.

The renderer is built on the Blaze3D GPU API that Minecraft introduced in **1.21.9** (`GpuDevice`,
`RenderPipeline`, `MappableRingBuffer`, render-target output overrides) and on the
`SubmitNodeCollector` hand-rendering path from the same release. Minecraft 1.21.2–1.21.8 used a
different render system, and 1.21.1 and earlier used another one again; neither exposes the APIs
this effect chain is written against. Running on those versions would need a second renderer written
from scratch rather than a recompile, so they are out of scope.

**Minecraft 26.1 and newer** are not supported yet. From 26.1 Minecraft ships unobfuscated, Mojang
no longer publishes mappings and Yarn ended at 1.21.11, so those versions build with a different
Loom plugin (`net.fabricmc.fabric-loom` rather than `fabric-loom-remap`), plain `implementation`
dependencies, `jar` instead of `remapJar`, and Java 25. The effect chain itself largely survives,
but the GUI was reworked into an extract-render-state model — `GuiGraphics` became
`GuiGraphicsExtractor`, `Screen.render` became `extractRenderState`, `PlayerFaceRenderer` and
`GlyphRenderState` are gone — which the menu is written against throughout. That is a port on its
own branch, not another entry in the table above.

If a shader fails to compile on your driver, the mod logs it once and falls back to drawing your
plain hand — it will not crash the game.

### Shader packs

While an Iris shader pack is active, Iris draws the hand in its own passes. The mod detects this and
stays out of the way.

---

## Building

Requires JDK 21 or newer.

```bash
./gradlew build
```

That builds the default Minecraft version and leaves the jar in `dist/`. To build another one:

```bash
./gradlew build -Pmc=1.21.9
```

To build every supported version in one go, use `build-all.sh` (or `build-all.ps1` on Windows).
The supported versions, their Fabric API builds and their source variants are the `targets` map at
the top of `build.gradle` — adding a version means adding a line there.

To run a development client:

```bash
./gradlew runClient -Pmc=1.21.11
```

---

## Project layout

```
src/main/java/jay/rip/handchams/
  ItemShaders.java          entry point, menu key handling
  config/                   JSON config read and write
  module/                   module base class, registry, HandChams
  setting/                  typed settings (bool, number, mode, colour, keybind, …)
  mixin/                    hand capture hook, menu key hook, smooth-font hooks
  ui/
    Menu, MenuScreen        the window and its Minecraft screen
    framework/              renderer, input, springs, fonts, colours
    component/              sidebar, cards, setting rows, popups

src/compat/v1_21_9/java/    the handful of Minecraft APIs that changed,
src/compat/v1_21_11/java/   one variant per version; the build compiles in one

src/main/resources/assets/itemshaders/
  shaders/core/             the four fragment shaders
  font/                     Rubik and Lucide, rastered per size
```

Only four things differ between the supported versions, and they are all wrapped in the `compat`
package so the rest of the source never has to know: `ResourceLocation` was renamed to `Identifier`,
`Screen.resize` lost its `Minecraft` parameter, shader samplers gained an explicit sampler object,
and one mixin shadows a field whose type changed.

---

## Licence

**All rights reserved.** See [LICENSE](LICENSE).

You may read this source and run official builds for your own personal use. You may not copy,
modify, redistribute, or reuse any part of it in another project. The bundled Rubik and Lucide fonts
are third-party assets under their own licences; see [NOTICE](NOTICE).

Minecraft is a trademark of Mojang Studios. This is an unofficial mod, not approved by or associated
with Mojang Studios or Microsoft.
