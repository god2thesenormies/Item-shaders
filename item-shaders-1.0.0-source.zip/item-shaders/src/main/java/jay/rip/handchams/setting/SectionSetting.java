package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class SectionSetting extends Setting<Boolean> {
    public SectionSetting(String name) {
        this(name, true);
    }

    public SectionSetting(String name, boolean open) {
        super(name, "", open);
    }

    public boolean isOpen() {
        return get();
    }

    public void toggle() {
        set(!get());
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement json) {
        set(json.getAsBoolean());
    }
}
