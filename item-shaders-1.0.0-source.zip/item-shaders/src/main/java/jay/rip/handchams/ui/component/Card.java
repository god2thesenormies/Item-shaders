package jay.rip.handchams.ui.component;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.module.Module;
import jay.rip.handchams.setting.Setting;
import jay.rip.handchams.setting.SettingGroup;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.component.row.SettingRow;
import jay.rip.handchams.ui.component.row.SettingRows;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Icons;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

import java.util.ArrayList;
import java.util.List;

public final class Card {
    private static final float HEADER_HEIGHT = 48f;
    private static final float COLLAPSED_HEIGHT = 52f;
    private static final float FIRST_ROW = 56f;
    private static final float RADIUS = 14f;
    private static final float TITLE_SIZE = 18f;
    private static final float DESCRIPTION_SIZE = 14f;
    private static final float COLUMN_GAP = 6f;
    private static final float TOOLTIP_DELAY = 0.6f;

    private static final float SECTION_INDENT = 6f;

    private final SettingGroup group;
    private final Module module;
    private final List<SettingRow<?>> rows = new ArrayList<>();
    private final Switch toggle;
    private final Spring open;
    private final Spring hover = new Spring(0f, 15f, 0.55f);
    private final Jelly jelly = new Jelly();
    private final Spring enabled;
    private boolean expanded;
    private int background = Theme.CARD;
    private float bodyHeight;
    private float headerHoverTime;

    private final int splitAt;
    private final List<SettingRow<?>> leftRows = new ArrayList<>();
    private final List<SettingRow<?>> rightRows = new ArrayList<>();

    public Card(SettingGroup group, boolean expanded) {
        this.group = group;
        this.module = group instanceof Module m ? m : null;
        this.expanded = expanded;
        this.open = new Spring(expanded ? 1f : 0f, 13f, 0.55f);
        this.toggle = new Switch(module != null && module.isEnabled());
        this.enabled = Spring.smooth(module != null && module.isEnabled() ? 1f : 0f);

        int split = module != null ? module.splitIndex() : -1;

        for (Setting<?> setting : group.settings()) {
            rows.add(SettingRows.create(setting));
        }

        if (split > 0 && split < rows.size()) {
            this.splitAt = split;
            leftRows.addAll(rows.subList(0, split));
            rightRows.addAll(rows.subList(split, rows.size()));
        } else {
            this.splitAt = -1;
        }
    }

    public SettingGroup group() {
        return group;
    }

    public int background() {
        return background;
    }

    public float update(float delta) {
        bodyHeight = 0f;
        if (splitAt > 0) {
            float leftHeight = 0f;
            for (SettingRow<?> row : leftRows) {
                leftHeight += row.update(delta);
            }
            float rightHeight = 0f;
            for (SettingRow<?> row : rightRows) {
                rightHeight += row.update(delta);
            }
            bodyHeight = Math.max(leftHeight, rightHeight);
        } else {
            for (SettingRow<?> row : rows) {
                bodyHeight += row.update(delta);
            }
        }
        open.update(expanded ? 1f : 0f, delta);
        return height();
    }

    public float height() {
        float openAmount = Math.clamp(open.value(), 0f, 1f);
        return COLLAPSED_HEIGHT + Math.max(bodyHeight - 4f, 0f) * openAmount;
    }

    public void render(Ui ui, float x, float y, float width) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float height = height();
        float openAmount = Math.clamp(open.value(), 0f, 1f);

        boolean headerHovered = input.hovering(x, y, width, HEADER_HEIGHT);
        float hoverAmount = hover.update(headerHovered ? 1f : 0f, ui.delta());

        jelly.update(input.held(x, y, width, HEADER_HEIGHT), false, 0.22f, ui.delta());
        jelly.push(renderer, x + width * 0.5f, y + height * 0.5f);

        float enabledAmount = enabled.update(module != null && module.isEnabled() ? 1f : 0f, ui.delta());
        background = Colors.mix(Theme.CARD, Theme.accent(), 0.07f * enabledAmount);

        int rim = Colors.mix(Theme.CARD_RIM, Colors.fade(Theme.accent(), 0.45f), enabledAmount);
        renderer.roundedRectBorder(x, y, width, height, RADIUS, background, rim);
        renderHeader(ui, x, y, width, hoverAmount, openAmount);

        if (openAmount > 0.01f && !rows.isEmpty()) {
            renderer.rect(x + 20f, y + HEADER_HEIGHT, width - 40f, 1f, Colors.fade(Theme.accent(), 0.25f * openAmount));
            float bodyTop = y + HEADER_HEIGHT + 1f;
            ui.pushClip(x, bodyTop, width, height - (bodyTop - y));
            renderer.pushOpacity(Math.clamp(openAmount * 1.3f, 0f, 1f));

            if (splitAt > 0) {
                renderSplit(ui, x, y, width, openAmount);
            } else {
                renderSingle(ui, x, y, width, openAmount);
            }

            renderer.popOpacity();
            ui.popClip();
        }
        renderer.pop();
    }

    private void renderSingle(Ui ui, float x, float y, float width, float openAmount) {
        float rowY = y + FIRST_ROW - (1f - openAmount) * 24f;
        renderSectionPanels(ui, rows, x, rowY, width);
        boolean first = true;
        for (SettingRow<?> row : rows) {
            if (row.currentHeight() > 0.5f) {
                float indent = row.setting().section() != null ? SECTION_INDENT : 0f;
                row.render(ui, x + indent, rowY, width - indent * 2f, first, x, width);
                first = row.isSection();
            }
            rowY += row.currentHeight();
        }
    }

    private void renderSplit(Ui ui, float x, float y, float width, float openAmount) {
        float colWidth = (width - COLUMN_GAP) * 0.5f;
        float leftX = x;
        float rightX = x + colWidth + COLUMN_GAP;
        float startY = y + FIRST_ROW - (1f - openAmount) * 24f;

        float rowY = startY;
        renderSectionPanels(ui, leftRows, leftX, startY, colWidth);
        renderSectionPanels(ui, rightRows, rightX, startY, colWidth);
        boolean first = true;
        for (SettingRow<?> row : leftRows) {
            if (row.currentHeight() > 0.5f) {
                float indent = row.setting().section() != null ? SECTION_INDENT : 0f;
                row.render(ui, leftX + indent, rowY, colWidth - indent * 2f, first, x, width);
                first = row.isSection();
            }
            rowY += row.currentHeight();
        }

        rowY = startY;
        first = true;
        for (SettingRow<?> row : rightRows) {
            if (row.currentHeight() > 0.5f) {
                float indent = row.setting().section() != null ? SECTION_INDENT : 0f;
                row.render(ui, rightX + indent, rowY, colWidth - indent * 2f, first, x, width);
                first = row.isSection();
            }
            rowY += row.currentHeight();
        }
    }

    private void renderSectionPanels(Ui ui, List<SettingRow<?>> column, float x, float startY, float width) {
        Renderer renderer = ui.renderer();
        float rowY = startY;
        float sectionTop = Float.NaN;
        float sectionBottom = 0f;
        float sectionShown = 0f;
        Object section = null;
        for (SettingRow<?> row : column) {
            float height = row.currentHeight();
            if (row.isSection()) {
                drawSectionPanel(renderer, x, width, sectionTop, sectionBottom, sectionShown);
                section = row.setting();
                sectionTop = height > 0.5f ? rowY : Float.NaN;
                sectionBottom = rowY + height;
                sectionShown = height / row.height();
            } else if (!Float.isNaN(sectionTop) && height > 0.5f && row.setting().section() == section) {
                sectionBottom = rowY + height;
            }
            rowY += height;
        }
        drawSectionPanel(renderer, x, width, sectionTop, sectionBottom, sectionShown);
    }

    private static void drawSectionPanel(Renderer renderer, float x, float width, float top, float bottom, float shown) {
        if (Float.isNaN(top) || shown < 0.02f) {
            return;
        }
        float panelTop = top + 8f;
        float panelHeight = bottom - panelTop - 10f;
        if (panelHeight < 20f) {
            return;
        }
        renderer.roundedRectBorder(x + 10f, panelTop, width - 20f, panelHeight, 12f,
                Colors.rgba(255, 255, 255, Math.round(5 * shown)), Colors.rgba(255, 255, 255, Math.round(11 * shown)));
    }

    private void renderHeader(Ui ui, float x, float y, float width, float hoverAmount, float openAmount) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float centerY = y + HEADER_HEIGHT * 0.5f + 1f;
        float right = x + width - 31f;

        if (module != null) {
            float switchX = right - Switch.WIDTH;
            if (toggle.render(ui, switchX, centerY - Switch.HEIGHT * 0.5f, module.isEnabled())) {
                module.toggle();
            }
            right = switchX - 14f;
        } else {
            right -= 2f;
        }

        float chevronX = right - 10f;
        renderer.push();
        renderer.rotateAround(chevronX, centerY, (float) Math.PI * openAmount);
        renderer.icon(Icons.CHEVRON_DOWN, chevronX, centerY, 18f, Colors.mix(Colors.rgb(170, 170, 170), Colors.rgb(230, 230, 230), hoverAmount));
        renderer.pop();

        if (input.clicked(x, y, width, HEADER_HEIGHT) || input.clicked(Input.RIGHT, x, y, width, HEADER_HEIGHT)) {
            expanded = !expanded;
        }

        int accent = Theme.accentText();
        int titleColor = Colors.mix(Colors.mix(accent, Theme.CARD, 0.08f), Colors.mix(accent, Theme.TEXT_BRIGHT, 0.25f), hoverAmount);
        float titleX = x + 24f + Math.clamp(hoverAmount, 0f, 1f) * 4f;
        float maxWidth = chevronX - 22f - titleX;
        renderer.text(TextFont.SEMIBOLD, group.name(), titleX, centerY, TITLE_SIZE, titleColor, maxWidth);

        float titleWidth = Math.min(renderer.textWidth(TextFont.SEMIBOLD, group.name(), TITLE_SIZE), maxWidth);
        float descriptionX = titleX + titleWidth + 14f;
        float descriptionWidth = chevronX - 22f - descriptionX;
        if (ItemShaders.menuSettings().general.tooltips.isEnabled()) {
            boolean hovered = input.hovering(x, y, width, HEADER_HEIGHT);
            headerHoverTime = hovered ? headerHoverTime + ui.delta() : 0f;
            if (headerHoverTime > TOOLTIP_DELAY) {
                ui.tooltip(group.description(), input.mouseX(), input.mouseY());
            }
        } else {
            headerHoverTime = 0f;
            if (descriptionWidth > 60f) {
                renderer.text(TextFont.REGULAR, group.description(), descriptionX, centerY + 1f, DESCRIPTION_SIZE, Theme.TEXT_MUTED, descriptionWidth);
            }
        }
    }
}
