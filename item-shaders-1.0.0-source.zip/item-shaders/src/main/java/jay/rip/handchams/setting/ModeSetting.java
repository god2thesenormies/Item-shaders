package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public final class ModeSetting extends Setting<String> {
    private final List<String> modes;

    public ModeSetting(String name, String description, String defaultValue, String... modes) {
        super(name, description, defaultValue);
        this.modes = List.of(modes);
        if (!this.modes.contains(defaultValue)) {
            throw new IllegalArgumentException("Default mode '" + defaultValue + "' isn't one of " + this.modes);
        }
    }

    public List<String> modes() {
        return modes;
    }

    public boolean is(String mode) {
        return get().equalsIgnoreCase(mode);
    }

    public int index() {
        return modes.indexOf(get());
    }

    public void select(int index) {
        set(modes.get(Math.floorMod(index, modes.size())));
    }

    @Override
    protected String sanitize(String value) {
        return modes.contains(value) ? value : defaultValue();
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement json) {
        set(json.getAsString());
    }
}
