package jay.rip.handchams.ui;

import jay.rip.handchams.module.Category;
import jay.rip.handchams.ui.framework.Icons;

public enum Tab {
    VISUALS(Category.VISUALS, Icons.EYE),
    SETTINGS(null, Icons.SETTINGS);

    private final Category category;
    private final String icon;

    Tab(Category category, String icon) {
        this.category = category;
        this.icon = icon;
    }

    public Category category() {
        return category;
    }

    public String icon() {
        return icon;
    }

    public String title() {
        return category != null ? category.displayName() : "Settings";
    }
}
