package jay.rip.handchams.ui.framework;

public final class Icons {
    public static final String EYE = "";
    public static final String SETTINGS = "";
    public static final String SEARCH = "";
    public static final String CHEVRON_DOWN = "";

    private Icons() {
    }
}
