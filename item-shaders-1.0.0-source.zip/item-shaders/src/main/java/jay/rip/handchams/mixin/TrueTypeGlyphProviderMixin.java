package jay.rip.handchams.mixin;

import com.mojang.blaze3d.font.TrueTypeGlyphProvider;
import jay.rip.handchams.ui.framework.SmoothFonts;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FreeType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(TrueTypeGlyphProvider.class)
public abstract class TrueTypeGlyphProviderMixin {
    @Redirect(method = "loadGlyph", at = @At(value = "INVOKE",
            target = "Lorg/lwjgl/util/freetype/FreeType;FT_Load_Glyph(Lorg/lwjgl/util/freetype/FT_Face;II)I"))
    private int itemshaders$loadUnhinted(FT_Face face, int glyphIndex, int flags) {
        return FreeType.FT_Load_Glyph(face, glyphIndex, SmoothFonts.loadFlags(face, flags));
    }
}
