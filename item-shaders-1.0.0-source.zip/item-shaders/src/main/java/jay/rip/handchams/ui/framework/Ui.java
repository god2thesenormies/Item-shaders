package jay.rip.handchams.ui.framework;

import net.minecraft.client.gui.GuiGraphics;

public final class Ui {
    private static final float MAX_DELTA = 1f / 20f;

    private final Renderer renderer = new Renderer();
    private final Input input = new Input();
    private long lastFrame;
    private float delta;
    private float time;
    private float pageTime;
    private int rowIndex;
    private float viewWidth;
    private float viewHeight;
    private Popup popup;
    private Object keyboardOwner;
    private Label tooltip;
    private float tooltipX;
    private float tooltipY;

    public void beginFrame(GuiGraphics graphics, float viewWidth, float viewHeight, float animationSpeed) {
        long now = System.nanoTime();
        float frameTime = lastFrame == 0L ? 0f : (now - lastFrame) / 1_000_000_000f;
        lastFrame = now;

        renderer.begin(graphics);
        this.viewWidth = viewWidth;
        this.viewHeight = viewHeight;
        delta = Math.min(frameTime, MAX_DELTA) * animationSpeed;
        time += delta;
        pageTime += delta;
        rowIndex = 0;
        tooltip = null;
    }

    public void restartPage() {
        pageTime = 0f;
    }

    public float pageTime() {
        return pageTime;
    }

    public int nextRowIndex() {
        return rowIndex++;
    }

    public Renderer renderer() {
        return renderer;
    }

    public Input input() {
        return input;
    }

    public float delta() {
        return delta;
    }

    public float time() {
        return time;
    }

    public float viewWidth() {
        return viewWidth;
    }

    public float viewHeight() {
        return viewHeight;
    }

    public void pushClip(float x, float y, float width, float height) {
        renderer.pushClip(x, y, width, height);
        input.pushClip(x, y, width, height);
    }

    public void popClip() {
        renderer.popClip();
        input.popClip();
    }

    public void openPopup(Popup popup) {
        closePopup();
        this.popup = popup;
    }

    public void closePopup() {
        if (popup != null && keyboardOwner == popup) {
            keyboardOwner = null;
        }
        popup = null;
    }

    public Popup popup() {
        return popup;
    }

    public boolean isOpen(Popup popup) {
        return this.popup == popup;
    }

    public void focus(Object owner) {
        keyboardOwner = owner;
    }

    public void unfocus(Object owner) {
        if (keyboardOwner == owner) {
            keyboardOwner = null;
        }
    }

    public void clearFocus() {
        keyboardOwner = null;
    }

    public boolean hasFocus(Object owner) {
        return keyboardOwner == owner;
    }

    public boolean isKeyboardCaptured() {
        return keyboardOwner != null;
    }

    public void tooltip(Label text, float x, float y) {
        tooltip = text;
        tooltipX = x;
        tooltipY = y;
    }

    public Label tooltipText() {
        return tooltip;
    }

    public float tooltipX() {
        return tooltipX;
    }

    public float tooltipY() {
        return tooltipY;
    }
}
