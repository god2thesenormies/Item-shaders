package jay.rip.handchams.ui.component;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.ui.Menu;
import jay.rip.handchams.ui.Tab;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.world.entity.player.PlayerSkin;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

public final class Sidebar {
    public static final float WIDTH = 290f;
    public static final float LOGO_HEIGHT = 170f;

    private static final String WORDMARK = "shaders";
    private static final float GAP = 14f;
    private static final float PROFILE_HEIGHT = 102f;
    private static final float ITEM_HEIGHT = 49f;
    private static final float ITEM_STEP = 56f;
    private static final float ITEM_INSET = 12f;
    private static final float FIRST_ITEM_CENTER = 43f;

    private static final float SWEEP_TIME = 1.1f;
    private static final float SWEEP_EVERY = 4.5f;

    private static final float WARP_PART = 0.28f;

    private final Menu menu;
    private final Spring selection = new Spring(0f, 13f, 0.5f);
    private final Jelly selectionJelly = new Jelly();
    private final Jelly logoJelly = new Jelly();
    private final Spring avatarPop = new Spring(1f, 15f, 0.3f);
    private final Spring logoHover = Spring.smooth(0f);
    private final Map<Tab, Spring> hovers = new EnumMap<>(Tab.class);
    private final Map<Tab, Spring> iconScales = new EnumMap<>(Tab.class);
    private final Map<Tab, Spring> ghosts = new EnumMap<>(Tab.class);
    private final Map<Tab, Approach> actives = new EnumMap<>(Tab.class);
    private final Map<Tab, Jelly> ghostJellies = new EnumMap<>(Tab.class);
    private float introTime;
    private float sweepClock;
    private Supplier<PlayerSkin> skin;
    private boolean wasHovered;
    private boolean wasLogoHeld;
    private boolean selectionPlaced;

    public Sidebar(Menu menu) {
        this.menu = menu;
        for (Tab tab : Tab.values()) {
            hovers.put(tab, new Spring(0f, 15f, 0.55f));
            iconScales.put(tab, new Spring(1f, 16f, 0.3f));
            ghosts.put(tab, new Spring(0f, 16f, 0.6f));
            actives.put(tab, new Approach(0f));
            ghostJellies.put(tab, new Jelly());
        }
    }

    public void render(Ui ui, float x, float y, float height) {
        renderLogo(ui, x, y);
        float navY = y + LOGO_HEIGHT + GAP;
        float profileY = y + height - PROFILE_HEIGHT;
        renderNavigation(ui, x, navY, profileY - GAP - navY);
        renderProfile(ui, x, profileY);
    }

    public void replayIntro() {
        introTime = 0f;
        sweepClock = SWEEP_EVERY - 0.9f;
    }

    private void renderLogo(Ui ui, float x, float y) {
        Renderer renderer = ui.renderer();
        Theme.panel(renderer, x, y, WIDTH, LOGO_HEIGHT);

        float time = ui.time();
        float delta = ui.delta();
        introTime += delta;
        boolean hovered = ui.input().hovering(x, y, WIDTH, LOGO_HEIGHT);
        float hover = logoHover.update(hovered ? 1f : 0f, delta);
        sweepClock += delta;
        if (hovered && !wasHovered && sweepClock > SWEEP_TIME) {
            sweepClock = SWEEP_EVERY;
        }
        wasHovered = hovered;
        if (sweepClock >= SWEEP_EVERY) {
            sweepClock -= SWEEP_EVERY;
        }
        float centerY = y + 46f;

        float size = 42f;
        float tracking = -0.5f;
        float prefixSize = 19f;
        float[] letterX = new float[WORDMARK.length()];
        float prefixWidth = renderer.textWidth(TextFont.BOLD, "item", prefixSize);
        float wordWidth = 0f;
        for (int i = 0; i < WORDMARK.length(); i++) {
            wordWidth += renderer.textWidth(TextFont.HEAVY, letter(i), size) + tracking;
        }
        float groupWidth = prefixWidth + 5f + wordWidth;
        float groupX = x + (WIDTH - groupWidth) * 0.5f;
        float cursor = groupX + prefixWidth + 5f;
        for (int i = 0; i < WORDMARK.length(); i++) {
            letterX[i] = cursor;
            cursor += renderer.textWidth(TextFont.HEAVY, letter(i), size) + tracking;
        }

        float settled = Math.clamp((introTime - 0.6f) / 0.6f, 0f, 1f);
        float bob = (float) Math.sin(time * 1.7f) * 1.6f * settled;
        float wave = (1.2f + 1.6f * hover) * settled;

        float sweepProgress = sweepClock / SWEEP_TIME;
        float burst = introTime > 0.8f && sweepProgress < WARP_PART
                ? (float) Math.sin(sweepProgress / WARP_PART * Math.PI)
                : 0f;
        float shakeX = 0f;
        float shakeY = bob;
        if (burst > 0.01f) {
            int step = (int) (time * 40f);
            shakeX += noise(step) * 2.6f * burst;
            shakeY += noise(step + 7919) * 1.2f * burst;
        }
        float split = 3.2f * burst;

        boolean logoHeld = ui.input().held(x, y, WIDTH, LOGO_HEIGHT);
        if (logoHeld && !wasLogoHeld) {
            logoJelly.poke(0.82f);
        }
        wasLogoHeld = logoHeld;
        logoJelly.update(false, hovered, 1.6f, delta);
        logoJelly.push(renderer, x + WIDTH * 0.5f, centerY + 10f + bob);

        renderer.pushFloating();
        float prefixIn = letterIn(0);
        renderer.pushOpacity(prefixIn);
        renderer.text(TextFont.BOLD, "item", groupX + shakeX,
                centerY + 9f + (1f - prefixIn) * 6f + shakeY, prefixSize, Theme.TEXT_DIM);
        renderer.popOpacity();

        float[] letterY = new float[WORDMARK.length()];
        for (int i = 0; i < WORDMARK.length(); i++) {
            float letterIn = letterIn(i + 1);
            float lift = (float) Math.sin(time * 2.4f - i * 0.65f) * wave;
            letterY[i] = centerY + (1f - letterIn) * 10f + shakeY + lift;
            letterX[i] += shakeX;
            if (split > 0.05f) {
                renderer.text(TextFont.HEAVY, letter(i), letterX[i] - split, letterY[i], size,
                        Colors.fade(Theme.accentText(), 0.45f * burst));
                renderer.text(TextFont.HEAVY, letter(i), letterX[i] + split, letterY[i], size,
                        Colors.fade(Theme.secondaryText(), 0.45f * burst));
            }
            renderer.pushOpacity(letterIn);
            renderer.text(TextFont.HEAVY, letter(i), letterX[i], letterY[i], size, Theme.shimmer(time, i));
            renderer.popOpacity();
        }

        float sweep = sweepClock / SWEEP_TIME;
        if (sweep < 1f && introTime > 0.8f) {
            float eased = sweep * sweep * (3f - 2f * sweep);
            float bandWidth = 34f;
            float left = groupX - bandWidth;
            float bandCenter = left + (groupWidth + bandWidth * 2f) * eased;
            float strength = (float) Math.sin(sweep * Math.PI);
            for (int layer = 1; layer <= 3; layer++) {
                float layerWidth = bandWidth * (1.15f - layer * 0.3f);
                int light = Colors.rgba(255, 246, 252, Math.round(34 * strength));
                renderer.pushClip(bandCenter - layerWidth * 0.5f, y + 6f, layerWidth, 76f);
                for (int i = 0; i < WORDMARK.length(); i++) {
                    renderer.text(TextFont.HEAVY, letter(i), letterX[i], letterY[i], size, light);
                }
                renderer.popClip();
            }
        }
        renderer.popFloating();
        renderer.pop();

        renderer.rect(x + 22f, y + 88f, WIDTH - 44f, 1f, Theme.LOGO_SEPARATOR);
        renderer.textCentered(TextFont.SEMIBOLD, "Shader effects for your hand",
                x + WIDTH * 0.5f, y + 110f, 18.8f, Theme.accentText());
        renderer.textCentered(TextFont.REGULAR, "Version " + ItemShaders.VERSION,
                x + WIDTH * 0.5f, y + 133f, 17.5f, Theme.TEXT_DIM);
    }

    private static String letter(int index) {
        return String.valueOf(WORDMARK.charAt(index));
    }

    private static float noise(int step) {
        int hash = step * 0x27d4eb2d;
        hash ^= hash >>> 15;
        hash *= 0x165667b1;
        hash ^= hash >>> 13;
        return (hash & 0xFFFF) / 32767.5f - 1f;
    }

    private float letterIn(int index) {
        return Easing.outCubic((introTime - 0.15f - index * 0.06f) / 0.4f);
    }

    private void renderProfile(Ui ui, float x, float y) {
        Renderer renderer = ui.renderer();
        Theme.panel(renderer, x, y, WIDTH, PROFILE_HEIGHT);
        Minecraft minecraft = Minecraft.getInstance();
        float centerY = y + PROFILE_HEIGHT * 0.5f;
        float avatarX = x + 40f;

        boolean avatarHovered = ui.input().hovering(avatarX - 26f, centerY - 26f, 52f, 52f);
        boolean avatarHeld = ui.input().held(avatarX - 26f, centerY - 26f, 52f, 52f);
        float pop = avatarPop.update(avatarHeld ? 0.92f : avatarHovered ? 1.1f : 1f, ui.delta());
        renderer.push();
        renderer.scaleAround(avatarX, centerY, pop, pop);

        renderer.roundedRect(avatarX - 25f, centerY - 25f, 50f, 50f, 10f, Theme.PILL);
        if (skin == null) {
            skin = minecraft.getSkinManager().createLookup(minecraft.getGameProfile(), false);
        }
        int faceColor = Colors.rgba(255, 255, 255, Math.round(255 * renderer.opacity()));
        PlayerFaceRenderer.draw(renderer.graphics(), skin.get(),
                Math.round(avatarX - 20f), Math.round(centerY - 20f), 40, faceColor);
        renderer.pop();

        float textX = avatarX + 36f;
        String name = renderer.trim(TextFont.SEMIBOLD, minecraft.getUser().getName(), 19.3f,
                WIDTH - (textX - x) - 16f);
        renderer.text(TextFont.SEMIBOLD, name, textX, centerY - 11f, 19.3f, Theme.accentText());
        renderer.text(TextFont.REGULAR, "Menu: " + ItemShaders.menuSettings().general.menuKey.keyName(),
                textX, centerY + 11f, 17.5f, Theme.TEXT_DIM);
    }

    private void renderNavigation(Ui ui, float x, float y, float height) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        Theme.panel(renderer, x, y, WIDTH, height);

        float target = itemCenter(menu.tab(), y);
        if (!selectionPlaced) {
            selection.snap(target - y);
            selectionPlaced = true;
            for (Tab tab : Tab.values()) {
                actives.get(tab).snap(menu.tab() == tab ? 1f : 0f);
            }
        }
        float delta = ui.delta();
        float pillX = x + ITEM_INSET;
        float pillWidth = WIDTH - ITEM_INSET * 2f;
        float pillCenterX = pillX + pillWidth * 0.5f;

        boolean heldActive = false;
        for (Tab tab : Tab.values()) {
            float top = itemCenter(tab, y) - ITEM_HEIGHT * 0.5f;
            if (menu.tab() == tab && input.held(pillX, top, pillWidth, ITEM_HEIGHT)) {
                heldActive = true;
            }
        }

        float selectedCenter = y + selection.update(target - y, delta);
        float speed = Math.abs(selection.velocity());
        float halfHeight = ITEM_HEIGHT * 0.5f + Math.min(speed * 0.03f, 24f) * 0.5f;
        float halfWidth = (pillWidth - Math.min(speed * 0.02f, 16f)) * 0.5f;
        selectionJelly.update(heldActive, false, 0.8f, delta);
        selectionJelly.push(renderer, pillCenterX, selectedCenter);
        renderer.roundedRect(pillCenterX - halfWidth, selectedCenter - halfHeight, halfWidth * 2f, halfHeight * 2f,
                Math.min(halfHeight, halfWidth), Colors.mix(Theme.PILL, Theme.accent(), 0.14f));
        renderer.pop();

        for (Tab tab : Tab.values()) {
            float centerY = itemCenter(tab, y);
            float top = centerY - ITEM_HEIGHT * 0.5f;
            boolean selected = menu.tab() == tab;
            boolean hovered = input.hovering(pillX, top, pillWidth, ITEM_HEIGHT);
            boolean held = input.held(pillX, top, pillWidth, ITEM_HEIGHT);
            if (input.clicked(pillX, top, pillWidth, ITEM_HEIGHT) && !selected) {
                menu.selectTab(tab);
                iconScales.get(tab).snap(0.55f);
                selected = true;
            }

            float active = actives.get(tab).update(selected ? 1f : 0f, delta);
            float hover = hovers.get(tab).update(hovered ? 1f : 0f, delta);
            float iconScale = iconScales.get(tab).update(held ? 0.85f : hovered ? 1.14f : 1f, delta);
            float ghost = ghosts.get(tab).update(hovered && !selected ? 1f : 0f, delta);
            Jelly ghostJelly = ghostJellies.get(tab);
            ghostJelly.update(held && !selected, false, 0.7f, delta);

            if (ghost > 0.01f) {
                ghostJelly.push(renderer, pillCenterX, centerY, 0.9f + 0.1f * ghost);
                renderer.roundedRect(pillX, top, pillWidth, ITEM_HEIGHT, ITEM_HEIGHT * 0.5f,
                        Colors.fade(Theme.PILL_HOVER, 0.55f * Math.clamp(ghost, 0f, 1f)));
                renderer.pop();
            }

            int color = Colors.mix(Colors.mix(Theme.NAV_TEXT, Theme.TEXT_BRIGHT, hover), Theme.accentText(), active);
            float iconX = x + 44f;
            renderer.push();
            renderer.scaleAround(iconX, centerY, iconScale, iconScale);
            renderer.icon(tab.icon(), iconX, centerY, 22f, color);
            renderer.pop();
            renderer.text(TextFont.SEMIBOLD, tab.title(), x + 66f + hover * 4f, centerY, 19.3f, color);
        }
    }

    private static float itemCenter(Tab tab, float navY) {
        return navY + FIRST_ITEM_CENTER + tab.ordinal() * ITEM_STEP;
    }
}
