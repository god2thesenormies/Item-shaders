package jay.rip.handchams.ui.framework;

public final class Spring {
    private static final int SUBSTEPS = 4;

    private final float frequency;
    private final float damping;
    private float value;
    private float velocity;

    public Spring(float initial, float frequency, float damping) {
        this.value = initial;
        this.frequency = frequency;
        this.damping = damping;
    }

    public static Spring bouncy(float initial) {
        return new Spring(initial, 16f, 0.5f);
    }

    public static Spring smooth(float initial) {
        return new Spring(initial, 18f, 1f);
    }

    public float update(float target, float delta) {
        return update(target, delta, frequency, damping);
    }

    public float update(float target, float delta, float frequency, float damping) {
        float step = delta / SUBSTEPS;
        for (int i = 0; i < SUBSTEPS; i++) {
            float acceleration = frequency * frequency * (target - value) - 2f * damping * frequency * velocity;
            velocity += acceleration * step;
            value += velocity * step;
        }
        if (Math.abs(target - value) < 1e-4f && Math.abs(velocity) < 1e-3f) {
            value = target;
            velocity = 0f;
        }
        return value;
    }

    public float value() {
        return value;
    }

    public float velocity() {
        return velocity;
    }

    public void snap(float value) {
        this.value = value;
        this.velocity = 0f;
    }
}
