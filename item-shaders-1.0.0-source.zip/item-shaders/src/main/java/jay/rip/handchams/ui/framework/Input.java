package jay.rip.handchams.ui.framework;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public final class Input {
    public static final int LEFT = 0;
    public static final int RIGHT = 1;

    private final boolean[] down = new boolean[8];
    private final boolean[] pressed = new boolean[8];
    private final boolean[] released = new boolean[8];
    private final Deque<float[]> clips = new ArrayDeque<>();
    private final List<Integer> keys = new ArrayList<>();
    private final StringBuilder typed = new StringBuilder();
    private float mouseX = -1;
    private float mouseY = -1;
    private float pressX = -1;
    private float pressY = -1;
    private float scroll;
    private boolean clickTaken;
    private boolean blocked;

    public void onMouseMove(float x, float y) {
        mouseX = x;
        mouseY = y;
    }

    public void onMouseButton(int button, boolean isDown) {
        if (button < 0 || button >= down.length) {
            return;
        }
        down[button] = isDown;
        if (isDown) {
            pressed[button] = true;
            if (button == LEFT) {
                pressX = mouseX;
                pressY = mouseY;
            }
        } else {
            released[button] = true;
        }
    }

    public void onScroll(float amount) {
        scroll += amount;
    }

    public void onKey(int key) {
        keys.add(key);
    }

    public void onChar(String text) {
        typed.append(text);
    }

    public void endFrame() {
        for (int i = 0; i < down.length; i++) {
            pressed[i] = false;
            released[i] = false;
        }
        keys.clear();
        typed.setLength(0);
        scroll = 0f;
        clickTaken = false;
    }

    public float mouseX() {
        return mouseX;
    }

    public float mouseY() {
        return mouseY;
    }

    public boolean isDown(int button) {
        return down[button];
    }

    public boolean wasPressed(int button) {
        return pressed[button] && !clickTaken && !blocked;
    }

    public boolean wasReleased(int button) {
        return released[button];
    }

    public boolean hovering(float x, float y, float width, float height) {
        if (blocked || !inClip(mouseX, mouseY)) {
            return false;
        }
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    public boolean held(float x, float y, float width, float height) {
        return down[LEFT] && !blocked && pressX >= x && pressX < x + width && pressY >= y && pressY < y + height;
    }

    public boolean clicked(float x, float y, float width, float height) {
        return clicked(LEFT, x, y, width, height);
    }

    public boolean clicked(int button, float x, float y, float width, float height) {
        if (wasPressed(button) && hovering(x, y, width, height)) {
            clickTaken = true;
            return true;
        }
        return false;
    }

    public void takeClick() {
        clickTaken = true;
    }

    public float takeScroll(float x, float y, float width, float height) {
        if (scroll == 0f || !hovering(x, y, width, height)) {
            return 0f;
        }
        float amount = scroll;
        scroll = 0f;
        return amount;
    }

    public List<Integer> keys() {
        return keys;
    }

    public String typed() {
        return typed.toString();
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public void pushClip(float x, float y, float width, float height) {
        float[] parent = clips.peek();
        if (parent != null) {
            float x1 = Math.min(x + width, parent[2]);
            float y1 = Math.min(y + height, parent[3]);
            x = Math.max(x, parent[0]);
            y = Math.max(y, parent[1]);
            clips.push(new float[]{x, y, x1, y1});
        } else {
            clips.push(new float[]{x, y, x + width, y + height});
        }
    }

    public void popClip() {
        clips.pop();
    }

    private boolean inClip(float x, float y) {
        float[] clip = clips.peek();
        return clip == null || x >= clip[0] && x < clip[2] && y >= clip[1] && y < clip[3];
    }
}
