package jay.rip.handchams.ui.framework;

public final class Approach {
    private final float speed;
    private float value;

    public Approach(float initial) {
        this(initial, 14f);
    }

    public Approach(float initial, float speed) {
        this.value = initial;
        this.speed = speed;
    }

    public float update(float target, float delta) {
        value += (target - value) * Math.clamp(delta * speed, 0f, 1f);
        if (Math.abs(value - target) < 0.001f) {
            value = target;
        }
        return value;
    }

    public float value() {
        return value;
    }

    public void snap(float value) {
        this.value = value;
    }
}
