package jay.rip.handchams.module;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.compat.Ids;
import jay.rip.handchams.compat.Samplers;
import jay.rip.handchams.module.Category;
import jay.rip.handchams.module.Module;
import jay.rip.handchams.setting.BooleanSetting;
import jay.rip.handchams.setting.ColorSetting;
import jay.rip.handchams.setting.ModeSetting;
import jay.rip.handchams.setting.NumberSetting;
import jay.rip.handchams.setting.SectionSetting;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.world.level.GameType;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;

public final class HandChams extends Module {
    private static final RenderPipeline PIPELINE = RenderPipeline.builder()
            .withLocation(Ids.of("pipeline/hand_chams"))
            .withVertexShader("core/screenquad")
            .withFragmentShader(Ids.of("core/hand_chams"))
            .withSampler("HandSampler")
            .withSampler("SceneSampler")
            .withSampler("BlurSampler")
            .withSampler("DistSampler")
            .withSampler("OrientSampler")
            .withUniform("HandChamsConfig", UniformType.UNIFORM_BUFFER)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthWrite(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withColorWrite(true, false)
            .withVertexFormat(DefaultVertexFormat.EMPTY, VertexFormat.Mode.TRIANGLES)
            .build();

    private static final RenderPipeline BLUR_H = pass("pipeline/hand_chams_blur_h", "core/hand_chams_blur", true, "HORIZONTAL");
    private static final RenderPipeline BLUR_V = pass("pipeline/hand_chams_blur_v", "core/hand_chams_blur", true, null);
    private static final RenderPipeline ORIENT_GATHER = pass("pipeline/hand_chams_orient_gather", "core/hand_chams_orient", false, "GATHER");
    private static final RenderPipeline ORIENT_SPREAD = pass("pipeline/hand_chams_orient_spread", "core/hand_chams_orient", false, null);
    private static final RenderPipeline JFA_INIT = jfaPipeline(-1);

    private static final RenderPipeline[] JFA_STEPS = {
            jfaPipeline(1), jfaPipeline(2), jfaPipeline(4), jfaPipeline(8), jfaPipeline(16), jfaPipeline(32), jfaPipeline(64)
    };

    private static final boolean LINEAR = true;
    private static final boolean NEAREST = false;

    private static final int UBO_SIZE = 47 * 16;

    private static RenderPipeline pass(String location, String shader, boolean config, String define) {
        RenderPipeline.Builder builder = RenderPipeline.builder()
                .withLocation(Ids.of(location))
                .withVertexShader("core/screenquad")
                .withFragmentShader(Ids.of(shader))
                .withSampler("InSampler")
                .withoutBlend()
                .withDepthWrite(false)
                .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                .withVertexFormat(DefaultVertexFormat.EMPTY, VertexFormat.Mode.TRIANGLES);
        if (config) {
            builder.withUniform("HandChamsConfig", UniformType.UNIFORM_BUFFER);
        }
        if (define != null) {
            builder.withShaderDefine(define);
        }
        return builder.build();
    }

    private static RenderPipeline jfaPipeline(int jump) {
        RenderPipeline.Builder builder = RenderPipeline.builder()
                .withLocation(Ids.of(jump < 0 ? "pipeline/hand_chams_jfa_init" : "pipeline/hand_chams_jfa_" + jump))
                .withVertexShader("core/screenquad")
                .withFragmentShader(Ids.of("core/hand_chams_jfa"))
                .withSampler("InSampler")
                .withoutBlend()
                .withDepthWrite(false)
                .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                .withVertexFormat(DefaultVertexFormat.EMPTY, VertexFormat.Mode.TRIANGLES);
        if (jump < 0) {
            builder.withShaderDefine("INIT").withSampler("BlurSampler");
        } else {
            builder.withShaderDefine("STEP", jump).withSampler("OrientSampler");
        }
        return builder.build();
    }

    public final SectionSetting appearanceSection = add(new SectionSetting("Appearance"));
    public final ModeSetting effect = add(new ModeSetting("Effect", "The look painted over your hand",
            "Liquid Metal", "Outline", "Glass", "Water", "Chrome", "Liquid Metal",
            "Aurora", "Galaxy", "Hologram", "Electric", "Lava"));
    public final NumberSetting animSpeed = add(new NumberSetting("Animation Speed",
            "How fast every effect moves", 1.5, 0, 5, 0.1));
    public final NumberSetting strength = add(new NumberSetting("Strength",
            "How much the effect covers your normal hand", 1.0, 0, 1, 0.05));
    public final NumberSetting handDetail = add(new NumberSetting("Hand Detail",
            "Keeps some of your hand's and item's own texture showing through the effect", 0.3, 0, 1, 0.05));
    public final NumberSetting rimLight = add(new NumberSetting("Rim Light",
            "A soft light along the hand's edge, in the outline color", 0.1, 0, 2, 0.05));
    public final NumberSetting textureLines = add(new NumberSetting("Texture Lines",
            "Lets the item's own pixel and block edges glow through the effect", 0.6, 0, 1, 0.05));
    public final BooleanSetting smoothEdges = add(new BooleanSetting("Smooth Edges",
            "Anti-aliases the hand's outline, so it isn't jagged", true));

    public final SectionSetting outlineSection = add(new SectionSetting("Outline & Glow"));
    public final BooleanSetting outline = add(new BooleanSetting("Outline",
            "Draws a line around your hand (always on for the Outline effect)", false));
    public final NumberSetting outlineWidth = add(new NumberSetting("Outline Width",
            "Thickness of the outline", 1.5, 0.5, 8, 0.25, "px")
            .visibleWhen(this::outlineShown));
    public final NumberSetting outlineSoftness = add(new NumberSetting("Outline Softness",
            "How gently the outline fades out: 0 is a crisp line, higher melts into the background", 0.3, 0, 1, 0.05)
            .visibleWhen(this::outlineShown));
    public final NumberSetting outlineOpacity = add(new NumberSetting("Outline Opacity",
            "How solid the outline is", 0.9, 0.05, 1, 0.05)
            .visibleWhen(this::outlineShown));
    public final BooleanSetting glow = add(new BooleanSetting("Glow",
            "A soft glow spreading out from your hand", false));
    public final NumberSetting glowRadius = add(new NumberSetting("Glow Size",
            "How far the glow spreads out from your hand", 14, 2, 60, 1, "px")
            .visibleWhen(glow::isEnabled));
    public final NumberSetting glowStrength = add(new NumberSetting("Glow Strength",
            "How bright the glow is", 1.2, 0, 3, 0.05)
            .visibleWhen(glow::isEnabled));
    public final NumberSetting glowFalloff = add(new NumberSetting("Glow Falloff",
            "How quickly the glow fades: low is a wide soft haze, high hugs your hand", 1, 0.3, 3, 0.05)
            .visibleWhen(glow::isEnabled));
    public final ColorSetting color = add(new ColorSetting("Color",
            "Outline, glow and rim light color", 0xFF9B4DFF)
            .visibleWhen(() -> !this.colorMode.is("Shader")));
    public final ModeSetting colorMode = add(new ModeSetting("Color Mode",
            "Static uses Color, Rainbow cycles hues, Pulse and Gradient blend Color with Second Color, "
                    + "Shader takes its colors from the effect itself so it flows with it",
            "Static", "Static", "Rainbow", "Pulse", "Gradient", "Shader"));
    public final ColorSetting colorTwo = add(new ColorSetting("Second Color",
            "Second color for Pulse and Gradient", 0xFF4DD2FF)
            .visibleWhen(() -> colorMode.is("Pulse") || colorMode.is("Gradient")));
    public final NumberSetting colorSpeed = add(new NumberSetting("Color Speed",
            "How fast Rainbow, Pulse and Gradient move", 1, 0, 5, 0.1)
            .visibleWhen(() -> !colorMode.is("Static") && !colorMode.is("Shader")));

    public final SectionSetting fillSection = add(new SectionSetting("Outline Fill")
            .visibleWhen(() -> effect.is("Outline")));
    public final ColorSetting fillColor = add(new ColorSetting("Fill Color",
            "Color filling the hand for the Outline effect", 0xFF9B4DFF)
            .visibleWhen(() -> effect.is("Outline")));
    public final NumberSetting fillOpacity = add(new NumberSetting("Fill Opacity",
            "How strongly the fill covers the hand", 0.35, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Outline")));

    public final SectionSetting glassSection = add(new SectionSetting("Glass")
            .visibleWhen(() -> effect.is("Glass")));
    public final ModeSetting glassStyle = add(new ModeSetting("Glass Style",
            "A ready-made glass look. Pick Custom to tune every slider yourself",
            "Clear", "Clear", "Frosted", "Crystal", "Prism", "Smoky", "Ice", "Bubble", "Mirror", "Custom")
            .visibleWhen(() -> effect.is("Glass")));
    public final ColorSetting glassTint = add(new ColorSetting("Tint Color",
            "The color of the glass itself", 0xFFE8F4FF)
            .visibleWhen(this::customGlass));
    public final NumberSetting glassTintStrength = add(new NumberSetting("Tint Amount",
            "How strongly the glass is colored. 0% is perfectly clear", 15, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassRefraction = add(new NumberSetting("Refraction",
            "How much the glass bends the world behind it", 50, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassDepth = add(new NumberSetting("Thickness",
            "Thicker glass holds more of the tint in its middle", 30, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassFrost = add(new NumberSetting("Frost",
            "Blurs what you see through it, like frosted glass", 0, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassDispersion = add(new NumberSetting("Rainbow Edges",
            "Splits light into rainbow fringes along the edges, like a prism", 30, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassReflection = add(new NumberSetting("Reflection",
            "How much the glass mirrors the world. Up to half is real glass, past that it turns into a mirror",
            50, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final ColorSetting glassReflectTint = add(new ColorSetting("Reflection Tint",
            "Color of reflections, shine and sheen. White keeps them natural", 0xFFFFFFFF)
            .visibleWhen(this::customGlass));
    public final NumberSetting glassShine = add(new NumberSetting("Glass Shine",
            "Sharp highlights where the light hits", 70, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting glassSheen = add(new NumberSetting("Sheen",
            "A soft band of light that sweeps across the glass now and then", 40, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting lightIntensity = add(new NumberSetting("Edge Light",
            "How bright the glass edge glows on the side facing the light", 60, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final ColorSetting bevelColor = add(new ColorSetting("Edge Light Color",
            "Color of that edge glow", 0xFFFFFFFF)
            .visibleWhen(this::customGlass));
    public final NumberSetting splay = add(new NumberSetting("Edge Width",
            "How wide the polished border of the glass is. Wider looks thicker and chunkier", 35, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting edgeSharpness = add(new NumberSetting("Edge Sharpness",
            "0% is a soft rounded edge, 100% crisp cut-glass facets that follow every step", 70, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting edgeDarkening = add(new NumberSetting("Edge Darkening",
            "Thick glass looks darker and richer at its edges, where you look through more of it", 20, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting studioLight = add(new NumberSetting("Studio Light",
            "A soft window-shaped light reflected in the glass, like a product photo", 50, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting iridescence = add(new NumberSetting("Iridescence",
            "Rainbow soap-bubble swirls, strongest where the glass curves away", 0, 0, 100, 1, "%")
            .visibleWhen(this::customGlass));
    public final NumberSetting lightAngle = add(new NumberSetting("Light Direction",
            "Where the light comes from: 0 is the right, 90 straight down, 270 straight up", 45, 0, 360, 5, "°")
            .visibleWhen(this::customGlass));

    public final SectionSetting waterSection = add(new SectionSetting("Water")
            .visibleWhen(() -> effect.is("Water")));
    public final ColorSetting waterColor = add(new ColorSetting("Water Color",
            "Color of the water", 0xFFC8203C)
            .visibleWhen(() -> effect.is("Water")));
    public final ColorSetting waterHighlight = add(new ColorSetting("Highlight Color",
            "Color of the caustic streaks and glints", 0xFFFFFFFF)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting waterOpacity = add(new NumberSetting("Water Opacity",
            "How much the water hides the world behind it", 0.9, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting flowSpeed = add(new NumberSetting("Flow Speed",
            "How fast the waves roll", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting flowScale = add(new NumberSetting("Flow Scale",
            "Size of the waves, bigger is busier", 1.5, 0.2, 6, 0.1)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting waveHeight = add(new NumberSetting("Wave Height",
            "How tall and 3D the waves look", 0.8, 0, 2, 0.05)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting choppiness = add(new NumberSetting("Choppiness",
            "Sharper, pointier crests", 3, 1, 8, 0.5)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting waveFreq = add(new NumberSetting("Wave Freq",
            "How close together the waves are", 0.24, 0, 1, 0.01)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting caustics = add(new NumberSetting("Caustics",
            "Bright streaks of light dancing on the water", 1, 0, 2, 0.05)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting waterRefraction = add(new NumberSetting("Water Refraction",
            "How much the waves bend the world behind them", 8, 0, 60, 1)
            .visibleWhen(() -> effect.is("Water")));
    public final NumberSetting waterSpecular = add(new NumberSetting("Water Specular",
            "Sun glint on the wave tops", 0.6, 0, 2, 0.05)
            .visibleWhen(() -> effect.is("Water")));

    public final SectionSetting chromeSection = add(new SectionSetting("Chrome")
            .visibleWhen(() -> effect.is("Chrome")));
    public final ColorSetting chromeTint = add(new ColorSetting("Chrome Tint",
            "Base color of the metal", 0xFF2C3446)
            .visibleWhen(() -> effect.is("Chrome")));
    public final ColorSetting chromeHighlight = add(new ColorSetting("Reflection Color",
            "Color of the light sliding over it", 0xFFB8C8E8)
            .visibleWhen(() -> effect.is("Chrome")));
    public final NumberSetting chromeReflectivity = add(new NumberSetting("Reflectivity",
            "How strong the reflections are", 0.8, 0, 2, 0.05)
            .visibleWhen(() -> effect.is("Chrome")));
    public final NumberSetting chromeRimSharpness = add(new NumberSetting("Chrome Rim Sharpness",
            "How tight the bright edge is", 3, 0.5, 8, 0.1)
            .visibleWhen(() -> effect.is("Chrome")));
    public final NumberSetting chromeRimIntensity = add(new NumberSetting("Chrome Rim Intensity",
            "How bright the edge is", 1, 0, 4, 0.05)
            .visibleWhen(() -> effect.is("Chrome")));
    public final NumberSetting chromeSpeed = add(new NumberSetting("Chrome Speed",
            "How fast the reflections slide", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Chrome")));
    public final NumberSetting chromeBands = add(new NumberSetting("Swirl Scale",
            "Size of the reflection swirls, bigger is busier", 1, 0, 4, 0.1)
            .visibleWhen(() -> effect.is("Chrome")));

    public final SectionSetting metalSection = add(new SectionSetting("Liquid Metal")
            .visibleWhen(() -> effect.is("Liquid Metal")));
    public final ModeSetting preset = add(new ModeSetting("Preset",
            "A ready-made look, or Custom to tune everything yourself",
            "Toxic", "Default", "Neon", "Chrome", "Ocean", "Toxic", "Fire", "Custom")
            .visibleWhen(() -> effect.is("Liquid Metal")));
    public final ModeSetting pattern = add(new ModeSetting("Pattern",
            "The shape of the flow", "Liquid", "Liquid", "Plasma", "Ripple", "Marble")
            .visibleWhen(this::customMetal));
    public final NumberSetting scale = add(new NumberSetting("Scale",
            "Zoom of the pattern, bigger is busier", 1.7, 0.2, 5, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting freqX = add(new NumberSetting("Noise Freq X",
            "Sideways wobble frequency", 5.3, 0, 15, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting freqY = add(new NumberSetting("Noise Freq Y",
            "Up-down wobble frequency", 7.2, 0, 15, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting freqX2 = add(new NumberSetting("Noise Freq X2",
            "Second layer sideways frequency", 10.8, 0, 15, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting freqY2 = add(new NumberSetting("Noise Freq Y2",
            "Second layer up-down frequency", 8.1, 0, 15, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting warpX = add(new NumberSetting("Warp Intensity X",
            "How hard the flow swirls sideways", 0.8, -5, 5, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting warpY = add(new NumberSetting("Warp Intensity Y",
            "How hard the flow swirls up and down", -0.55, -5, 5, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting detail = add(new NumberSetting("Detail",
            "Layers of swirl, more is more intricate", 3, 1, 5, 1)
            .visibleWhen(this::customMetal));
    public final NumberSetting flowAngle = add(new NumberSetting("Flow Angle",
            "Turns the whole pattern", 0, 0, 360, 5, "°")
            .visibleWhen(this::customMetal));
    public final ColorSetting colorOne = add(new ColorSetting("Color One",
            "First palette color", 0xFF0A2A00)
            .visibleWhen(this::customMetal));
    public final ColorSetting colorTwoMetal = add(new ColorSetting("Color Two",
            "Second palette color", 0xFF2AFF2A)
            .visibleWhen(this::customMetal));
    public final ColorSetting colorThree = add(new ColorSetting("Color Three",
            "Third palette color", 0xFF9DFF00)
            .visibleWhen(this::customMetal));
    public final ColorSetting colorFour = add(new ColorSetting("Color Four",
            "Fourth palette color", 0xFF00FFA0)
            .visibleWhen(this::customMetal));
    public final NumberSetting colorCycle = add(new NumberSetting("Color Cycle",
            "Slowly rotates the palette over time", 0, 0, 3, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting brightness = add(new NumberSetting("Brightness",
            "Overall brightness", 2, 0, 6, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting metalSpeed = add(new NumberSetting("Speed",
            "How fast the metal flows", 1, 0, 6, 0.1)
            .visibleWhen(this::customMetal));
    public final NumberSetting redShift = add(new NumberSetting("Red Shift",
            "Pulls the red channel off to one side, for a chromatic edge", 0.5, 0, 3, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting blueShift = add(new NumberSetting("Blue Shift",
            "Pulls the blue channel off to the other side", 0.5, 0, 3, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting contour = add(new NumberSetting("Contour",
            "Glossy bands along the flow lines", 0.4, 0, 1, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting softness = add(new NumberSetting("Softness",
            "How soft those bands are", 0.85, 0, 1, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting shine = add(new NumberSetting("Shine",
            "Metallic highlights on the flow", 0.6, 0, 3, 0.05)
            .visibleWhen(this::customMetal));
    public final NumberSetting edgeGlow = add(new NumberSetting("Edge Glow",
            "Palette-colored light around the hand's edge", 0.4, 0, 3, 0.05)
            .visibleWhen(this::customMetal));

    public final SectionSetting auroraSection = add(new SectionSetting("Aurora")
            .visibleWhen(() -> effect.is("Aurora")));
    public final ColorSetting auroraColor = add(new ColorSetting("Aurora Color",
            "Color of the bright lower hem of the lights", 0xFF2BFFA3)
            .visibleWhen(() -> effect.is("Aurora")));
    public final ColorSetting auroraTop = add(new ColorSetting("Aurora Top Color",
            "Color the lights fade into toward their top", 0xFFB061FF)
            .visibleWhen(() -> effect.is("Aurora")));
    public final ColorSetting nightSky = add(new ColorSetting("Night Sky Color",
            "The sky behind the lights", 0xFF060B24)
            .visibleWhen(() -> effect.is("Aurora")));
    public final NumberSetting auroraSpeed = add(new NumberSetting("Aurora Speed",
            "How fast the lights drift and ripple", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Aurora")));
    public final NumberSetting auroraBrightness = add(new NumberSetting("Aurora Brightness",
            "How bright the lights are", 1.2, 0, 3, 0.05)
            .visibleWhen(() -> effect.is("Aurora")));
    public final NumberSetting curtainSize = add(new NumberSetting("Curtain Size",
            "Size of the light curtains, bigger is broader and calmer", 1, 0.3, 3, 0.05)
            .visibleWhen(() -> effect.is("Aurora")));
    public final NumberSetting auroraStars = add(new NumberSetting("Aurora Stars",
            "How many stars twinkle behind the lights", 0.6, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Aurora")));

    public final SectionSetting galaxySection = add(new SectionSetting("Galaxy")
            .visibleWhen(() -> effect.is("Galaxy")));
    public final ColorSetting nebulaColor = add(new ColorSetting("Nebula Color",
            "Main color of the swirling gas clouds", 0xFF8A3BFF)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final ColorSetting nebulaColorTwo = add(new ColorSetting("Second Nebula Color",
            "Color of the second, thinner cloud layer", 0xFF1EC8FF)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final NumberSetting galaxySpeed = add(new NumberSetting("Galaxy Speed",
            "How fast the clouds swirl", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final NumberSetting nebulaBrightness = add(new NumberSetting("Nebula Brightness",
            "How bright the gas clouds glow", 1, 0, 3, 0.05)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final NumberSetting starDensity = add(new NumberSetting("Star Density",
            "How many stars there are", 0.5, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final NumberSetting twinkle = add(new NumberSetting("Twinkle",
            "How much the stars twinkle", 0.6, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Galaxy")));
    public final NumberSetting galaxyScale = add(new NumberSetting("Galaxy Scale",
            "Size of the clouds, bigger is broader", 1, 0.3, 3, 0.05)
            .visibleWhen(() -> effect.is("Galaxy")));

    public final SectionSetting hologramSection = add(new SectionSetting("Hologram")
            .visibleWhen(() -> effect.is("Hologram")));
    public final ColorSetting hologramColor = add(new ColorSetting("Hologram Color",
            "Color of the projected light", 0xFF3DE8FF)
            .visibleWhen(() -> effect.is("Hologram")));
    public final NumberSetting hologramOpacity = add(new NumberSetting("Hologram Opacity",
            "How solid the hologram is; lower shows more of the world through it", 0.75, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Hologram")));
    public final NumberSetting scanlines = add(new NumberSetting("Scanlines",
            "How strong the moving scanlines are", 0.6, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Hologram")));
    public final NumberSetting scanlineSize = add(new NumberSetting("Scanline Size",
            "Spacing between scanlines", 4, 2, 12, 0.5, "px")
            .visibleWhen(() -> effect.is("Hologram")));
    public final NumberSetting glitch = add(new NumberSetting("Glitch",
            "How often slices of the hologram slip sideways and split their colors", 0.4, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Hologram")));
    public final NumberSetting flicker = add(new NumberSetting("Flicker",
            "How much the projection flickers", 0.3, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Hologram")));

    public final SectionSetting electricSection = add(new SectionSetting("Electric")
            .visibleWhen(() -> effect.is("Electric")));
    public final ColorSetting electricColor = add(new ColorSetting("Electric Color",
            "Color of the arcs and their glow", 0xFF5AB4FF)
            .visibleWhen(() -> effect.is("Electric")));
    public final NumberSetting electricSpeed = add(new NumberSetting("Electric Speed",
            "How fast the arcs crawl and flicker", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Electric")));
    public final NumberSetting boltAmount = add(new NumberSetting("Bolt Amount",
            "How many arcs are live at once", 0.5, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Electric")));
    public final NumberSetting boltSize = add(new NumberSetting("Bolt Size",
            "Size of the arcs, bigger is longer and calmer", 1, 0.3, 3, 0.05)
            .visibleWhen(() -> effect.is("Electric")));
    public final NumberSetting electricGlow = add(new NumberSetting("Electric Glow",
            "How bright the arcs and their glow are", 1, 0, 3, 0.05)
            .visibleWhen(() -> effect.is("Electric")));

    public final SectionSetting lavaSection = add(new SectionSetting("Lava")
            .visibleWhen(() -> effect.is("Lava")));
    public final ColorSetting lavaColor = add(new ColorSetting("Lava Color",
            "Color of the molten rock in the cracks", 0xFFFF5A00)
            .visibleWhen(() -> effect.is("Lava")));
    public final ColorSetting crustColor = add(new ColorSetting("Crust Color",
            "Color of the cooled rock plates", 0xFF1C0D08)
            .visibleWhen(() -> effect.is("Lava")));
    public final NumberSetting lavaSpeed = add(new NumberSetting("Lava Speed",
            "How fast the plates drift and the heat pulses", 1, 0, 5, 0.1)
            .visibleWhen(() -> effect.is("Lava")));
    public final NumberSetting crackWidth = add(new NumberSetting("Crack Width",
            "How wide the glowing cracks are", 0.5, 0, 1, 0.05)
            .visibleWhen(() -> effect.is("Lava")));
    public final NumberSetting lavaGlow = add(new NumberSetting("Lava Glow",
            "How hot the lava glows, through the cracks and under the crust", 1, 0, 3, 0.05)
            .visibleWhen(() -> effect.is("Lava")));
    public final NumberSetting rockSize = add(new NumberSetting("Rock Size",
            "Size of the rock plates", 1, 0.3, 3, 0.05)
            .visibleWhen(() -> effect.is("Lava")));

    private RenderTarget handTarget;
    private RenderTarget sceneTarget;
    private RenderTarget blurTargetA;
    private RenderTarget blurTargetB;
    private RenderTarget orientTargetA;
    private RenderTarget orientTargetB;
    private RenderTarget distTargetA;
    private RenderTarget distTargetB;
    private MappableRingBuffer ubo;
    private final long startNanos = System.nanoTime();

    private boolean shaderBroken;

    public HandChams() {
        super("Hand Chams", "Custom shader effects on your first-person hand", Category.VISUALS);
    }

    @Override
    protected void onDisable() {
        if (handTarget != null) RenderSystem.queueFencedTask(this::freeTargets);
    }

    private boolean outlineShown() {
        return outline.isEnabled() || effect.is("Outline");
    }

    private boolean customGlass() {
        return effect.is("Glass") && glassStyle.is("Custom");
    }

    private boolean customMetal() {
        return effect.is("Liquid Metal") && preset.is("Custom");
    }

    public boolean shouldRender(boolean sleeping) {
        return isEnabled() && !sleeping && mc.player != null && mc.gameMode != null
                && mc.options.getCameraType().isFirstPerson()
                && !mc.options.hideGui
                && mc.gameMode.getPlayerMode() != GameType.SPECTATOR
                && !irisShadersActive();
    }

    public boolean beginCapture() {
        RenderTarget main = mc.getMainRenderTarget();
        int w = main.width;
        int h = main.height;
        int lowW = (w + 7) / 8;
        int lowH = (h + 7) / 8;
        if (handTarget == null) {
            handTarget = new TextureTarget("hand chams", w, h, true);
            sceneTarget = new TextureTarget("hand chams scene", w, h, false);
            blurTargetA = new TextureTarget("hand chams blur A", w, h, false);
            blurTargetB = new TextureTarget("hand chams blur B", w, h, false);
            orientTargetA = new TextureTarget("hand chams edges A", lowW, lowH, false);
            orientTargetB = new TextureTarget("hand chams edges B", lowW, lowH, false);
            distTargetA = new TextureTarget("hand chams distance A", w, h, false);
            distTargetB = new TextureTarget("hand chams distance B", w, h, false);
            ubo = new MappableRingBuffer(() -> "hand chams config",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE, UBO_SIZE);
        } else if (handTarget.width != w || handTarget.height != h) {
            handTarget.resize(w, h);
            sceneTarget.resize(w, h);
            blurTargetA.resize(w, h);
            blurTargetB.resize(w, h);
            orientTargetA.resize(lowW, lowH);
            orientTargetB.resize(lowW, lowH);
            distTargetA.resize(w, h);
            distTargetB.resize(w, h);
        }
        RenderSystem.getDevice().createCommandEncoder()
                .clearColorAndDepthTextures(handTarget.getColorTexture(), 0, handTarget.getDepthTexture(), 1.0);
        RenderSystem.outputColorTextureOverride = handTarget.getColorTextureView();
        RenderSystem.outputDepthTextureOverride = handTarget.getDepthTextureView();
        return true;
    }

    public void endCapture() {
        RenderSystem.outputColorTextureOverride = null;
        RenderSystem.outputDepthTextureOverride = null;

        RenderTarget main = mc.getMainRenderTarget();
        int w = main.width;
        int h = main.height;
        if (shaderBroken || !pipelinesValid()) {
            if (!shaderBroken) {
                ItemShaders.LOGGER.error("Hand Chams shaders failed to compile; drawing the plain hand instead");
                shaderBroken = true;
            }
            handTarget.blitAndBlendToTexture(main.getColorTextureView());
            return;
        }

        boolean glass = effect.is("Glass");
        boolean distance = glass || outlineShown();
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();

        if (glass || effect.is("Water") || effect.is("Hologram")) {
            encoder.copyTextureToTexture(main.getColorTexture(), sceneTarget.getColorTexture(), 0, 0, 0, 0, 0, w, h);
        }
        try (GpuBuffer.MappedView view = encoder.mapBuffer(ubo.currentBuffer(), false, true)) {
            writeConfig(Std140Builder.intoBuffer(view.data()), w, h, distance);
        }

        draw(encoder, BLUR_H, blurTargetA, true, "InSampler", handTarget, LINEAR);
        draw(encoder, BLUR_V, blurTargetB, true, "InSampler", blurTargetA, LINEAR);
        if (glass) {
            draw(encoder, ORIENT_GATHER, orientTargetA, false, "InSampler", blurTargetB, LINEAR);
            draw(encoder, ORIENT_SPREAD, orientTargetB, false, "InSampler", orientTargetA, NEAREST);
        }
        RenderTarget field = distTargetA;
        if (distance) {
            try (RenderPass pass = encoder.createRenderPass(() -> "hand chams distance seed",
                    distTargetA.getColorTextureView(), OptionalInt.empty())) {
                pass.setPipeline(JFA_INIT);
                Samplers.bind(pass, "InSampler", handTarget, NEAREST);
                Samplers.bind(pass, "BlurSampler", blurTargetB, NEAREST);
                pass.draw(0, 3);
            }
            RenderTarget from = distTargetA;
            RenderTarget to = distTargetB;
            for (int jump : jumps(h)) {
                try (RenderPass pass = encoder.createRenderPass(() -> "hand chams distance",
                        to.getColorTextureView(), OptionalInt.empty())) {
                    pass.setPipeline(JFA_STEPS[Integer.numberOfTrailingZeros(jump)]);
                    Samplers.bind(pass, "InSampler", from, NEAREST);
                    Samplers.bind(pass, "OrientSampler", orientTargetB, NEAREST);
                    pass.draw(0, 3);
                }
                RenderTarget swap = from;
                from = to;
                to = swap;
            }
            field = from;
        }
        try (RenderPass pass = encoder.createRenderPass(() -> "hand chams", main.getColorTextureView(), OptionalInt.empty())) {
            pass.setPipeline(PIPELINE);
            pass.setUniform("HandChamsConfig", ubo.currentBuffer());
            Samplers.bind(pass, "HandSampler", handTarget, LINEAR);
            Samplers.bind(pass, "SceneSampler", sceneTarget, LINEAR);
            Samplers.bind(pass, "BlurSampler", blurTargetB, LINEAR);
            Samplers.bind(pass, "DistSampler", field, NEAREST);
            Samplers.bind(pass, "OrientSampler", orientTargetB, NEAREST);
            pass.draw(0, 3);
        }
        ubo.rotate();
    }

    private void draw(CommandEncoder encoder, RenderPipeline pipeline, RenderTarget to, boolean config,
                      String samplerName, RenderTarget from, boolean linear) {
        try (RenderPass pass = encoder.createRenderPass(() -> "hand chams", to.getColorTextureView(), OptionalInt.empty())) {
            pass.setPipeline(pipeline);
            if (config) pass.setUniform("HandChamsConfig", ubo.currentBuffer());
            Samplers.bind(pass, samplerName, from, linear);
            pass.draw(0, 3);
        }
    }

    private List<Integer> jumps(int h) {
        float need = 0;
        if (effect.is("Glass")) need = Math.max(need, bevelRadius(h) + 3);
        if (outlineShown()) need = Math.max(need, outlineWidth.floatValue() * (1 + outlineSoftness.floatValue()) + 3);
        int first = 1;
        while (2 * first - 1 < need && first < 64) first *= 2;
        List<Integer> jumps = new ArrayList<>();
        for (int jump = first; jump >= 1; jump /= 2) jumps.add(jump);
        jumps.add(1);
        return jumps;
    }

    private static boolean pipelinesValid() {
        GpuDevice device = RenderSystem.getDevice();
        if (!device.precompilePipeline(PIPELINE).isValid()
                || !device.precompilePipeline(BLUR_H).isValid()
                || !device.precompilePipeline(BLUR_V).isValid()
                || !device.precompilePipeline(ORIENT_GATHER).isValid()
                || !device.precompilePipeline(ORIENT_SPREAD).isValid()
                || !device.precompilePipeline(JFA_INIT).isValid()) {
            return false;
        }
        for (RenderPipeline step : JFA_STEPS) {
            if (!device.precompilePipeline(step).isValid()) return false;
        }
        return true;
    }

    private float bevelRadius(int h) {
        return (2f + glassPreset().edgeWidth * 0.4f) * (h / 1080f);
    }

    private GlassPreset glassPreset() {
        return glassStyle.is("Custom") ? customGlassPreset() : GlassPreset.byName(glassStyle.get());
    }

    private void writeConfig(Std140Builder b, int w, int h, boolean distance) {
        float time = ((System.nanoTime() - startNanos) / 1e9f % 3600f) * animSpeed.floatValue();
        boolean outlineOn = outlineShown();
        boolean glass = effect.is("Glass");
        GlassPreset g = glassPreset();

        b.putVec4(time, effect.index(), w, h);
        b.putVec4(glass ? bevelRadius(h) : 7f, glowRadius.floatValue(), distance ? 1f : 0f, glow.isEnabled() ? 1f : 0f);
        b.putVec4(strength.floatValue(), handDetail.floatValue(), rimLight.floatValue(), textureLines.floatValue());
        b.putVec4(smoothEdges.isEnabled() ? 1f : 0f, outlineOn ? 1f : 0f, outlineWidth.floatValue(), outlineSoftness.floatValue());
        b.putVec4(glowStrength.floatValue(), colorMode.index(), glowFalloff.floatValue(), colorSpeed.floatValue());
        b.putVec4(outlineOpacity.floatValue(), 0f, 0f, 0f);
        putColor(b, color.get(), 1f);
        putColor(b, colorTwo.get(), 1f);
        putColor(b, fillColor.get(), fillOpacity.floatValue());

        b.putVec4(g.refraction, g.thickness, g.frost, g.rainbow);

        b.putVec4((float) Math.toRadians(-g.lightAngle), g.edgeLight, bevelRadius(h), g.edgeSharpness);
        b.putVec4(g.reflection, g.shine, g.sheen, g.studioLight);
        b.putVec4(g.iridescence, g.edgeDarkening, 0f, 0f);
        putColor(b, g.tint, g.tintAmount / 100f);
        putColor(b, g.edgeColor, 1f);
        putColor(b, g.reflectTint, 1f);

        b.putVec4(flowSpeed.floatValue(), flowScale.floatValue(), waveHeight.floatValue(), choppiness.floatValue());
        b.putVec4(waveFreq.floatValue(), waterRefraction.floatValue(), waterSpecular.floatValue(), caustics.floatValue());
        putColor(b, waterColor.get(), waterOpacity.floatValue());
        putColor(b, waterHighlight.get(), 1f);

        b.putVec4(chromeRimSharpness.floatValue(), chromeRimIntensity.floatValue(), chromeSpeed.floatValue(), chromeBands.floatValue());
        putColor(b, chromeTint.get(), chromeReflectivity.floatValue());
        putColor(b, chromeHighlight.get(), 1f);

        MetalPreset m = preset.is("Custom") ? customPreset() : MetalPreset.byName(preset.get());
        b.putVec4(m.scale, m.freqX, m.freqY, m.freqX2);
        b.putVec4(m.freqY2, m.warpX, m.warpY, m.brightness);
        b.putVec4(m.speed, m.redShift, m.blueShift, m.contour);
        b.putVec4(m.softness, m.pattern, m.shine, m.colorCycle);
        b.putVec4((float) Math.toRadians(m.flowAngle), m.detail, m.edgeGlow, 0f);
        putColor(b, m.color1, 1f);
        putColor(b, m.color2, 1f);
        putColor(b, m.color3, 1f);
        putColor(b, m.color4, 1f);

        b.putVec4(auroraSpeed.floatValue(), auroraBrightness.floatValue(), curtainSize.floatValue(), auroraStars.floatValue());
        putColor(b, auroraColor.get(), 1f);
        putColor(b, auroraTop.get(), 1f);
        putColor(b, nightSky.get(), 1f);

        b.putVec4(galaxySpeed.floatValue(), nebulaBrightness.floatValue(), starDensity.floatValue(), twinkle.floatValue());
        b.putVec4(galaxyScale.floatValue(), 0f, 0f, 0f);
        putColor(b, nebulaColor.get(), 1f);
        putColor(b, nebulaColorTwo.get(), 1f);

        b.putVec4(scanlines.floatValue(), scanlineSize.floatValue(), glitch.floatValue(), flicker.floatValue());
        putColor(b, hologramColor.get(), hologramOpacity.floatValue());

        b.putVec4(electricSpeed.floatValue(), boltAmount.floatValue(), boltSize.floatValue(), electricGlow.floatValue());
        putColor(b, electricColor.get(), 1f);

        b.putVec4(lavaSpeed.floatValue(), crackWidth.floatValue(), lavaGlow.floatValue(), rockSize.floatValue());
        putColor(b, lavaColor.get(), 1f);
        putColor(b, crustColor.get(), 1f);
    }

    private static void putColor(Std140Builder b, int argb, float alpha) {
        b.putVec4(((argb >> 16) & 0xFF) / 255f, ((argb >> 8) & 0xFF) / 255f, (argb & 0xFF) / 255f, alpha);
    }

    private MetalPreset customPreset() {
        return new MetalPreset(pattern.index(), scale.floatValue(), freqX.floatValue(), freqY.floatValue(),
                freqX2.floatValue(), freqY2.floatValue(), warpX.floatValue(), warpY.floatValue(),
                detail.floatValue(), flowAngle.floatValue(),
                colorOne.get(), colorTwoMetal.get(), colorThree.get(), colorFour.get(),
                colorCycle.floatValue(), brightness.floatValue(), metalSpeed.floatValue(),
                redShift.floatValue(), blueShift.floatValue(), contour.floatValue(), softness.floatValue(),
                shine.floatValue(), edgeGlow.floatValue());
    }

    private GlassPreset customGlassPreset() {
        return new GlassPreset(glassTint.get(), glassTintStrength.floatValue(), glassRefraction.floatValue(),
                glassDepth.floatValue(), glassFrost.floatValue(), glassDispersion.floatValue(),
                glassReflection.floatValue(), glassReflectTint.get(), glassShine.floatValue(), glassSheen.floatValue(),
                lightIntensity.floatValue(), bevelColor.get(), splay.floatValue(), lightAngle.floatValue(),
                iridescence.floatValue(), edgeDarkening.floatValue(), studioLight.floatValue(),
                edgeSharpness.floatValue());
    }

    private void freeTargets() {
        if (handTarget == null) return;
        for (RenderTarget target : new RenderTarget[]{handTarget, sceneTarget, blurTargetA, blurTargetB,
                orientTargetA, orientTargetB, distTargetA, distTargetB}) {
            target.destroyBuffers();
        }
        ubo.close();
        handTarget = null;
        sceneTarget = null;
        blurTargetA = null;
        blurTargetB = null;
        orientTargetA = null;
        orientTargetB = null;
        distTargetA = null;
        distTargetB = null;
        ubo = null;
    }

    private static final MethodHandle IRIS_PACK_IN_USE = lookupIris();

    private static MethodHandle lookupIris() {
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            MethodHandles.Lookup lookup = MethodHandles.publicLookup();
            Object instance = lookup.findStatic(api, "getInstance", MethodType.methodType(api)).invoke();
            return lookup.findVirtual(api, "isShaderPackInUse", MethodType.methodType(boolean.class)).bindTo(instance);
        } catch (Throwable e) {
            return null;
        }
    }

    private static boolean irisShadersActive() {
        if (IRIS_PACK_IN_USE == null) return false;
        try {
            return (boolean) IRIS_PACK_IN_USE.invoke();
        } catch (Throwable e) {
            return false;
        }
    }

    private record GlassPreset(int tint, float tintAmount, float refraction, float thickness, float frost,
                               float rainbow, float reflection, int reflectTint, float shine, float sheen,
                               float edgeLight, int edgeColor, float edgeWidth, float lightAngle,
                               float iridescence, float edgeDarkening, float studioLight, float edgeSharpness) {
        static final GlassPreset CLEAR = new GlassPreset(0xFFE8F4FF, 10, 45, 20, 0, 25,
                50, 0xFFFFFFFF, 70, 35, 55, 0xFFFFFFFF, 18, 45, 0, 15, 50, 85);
        static final GlassPreset FROSTED = new GlassPreset(0xFFDDEBFF, 25, 30, 40, 70, 10,
                30, 0xFFFFFFFF, 35, 20, 50, 0xFFFFFFFF, 30, 45, 0, 20, 30, 40);
        static final GlassPreset CRYSTAL = new GlassPreset(0xFFBFE6FF, 30, 80, 55, 3, 70,
                65, 0xFFE8F6FF, 95, 55, 80, 0xFFFFFFFF, 40, 45, 8, 30, 70, 100);
        static final GlassPreset PRISM = new GlassPreset(0xFFFFFFFF, 5, 70, 25, 0, 100,
                45, 0xFFFFFFFF, 80, 45, 70, 0xFFFFE6FA, 32, 45, 25, 10, 60, 90);
        static final GlassPreset SMOKY = new GlassPreset(0xFF2A2F3A, 45, 40, 45, 12, 15,
                60, 0xFFB0C0D8, 60, 25, 45, 0xFFB0C0D8, 30, 45, 0, 60, 45, 70);
        static final GlassPreset ICE = new GlassPreset(0xFFCFEFFF, 30, 55, 60, 45, 15,
                45, 0xFFE6F6FF, 60, 30, 70, 0xFFDFF4FF, 45, 45, 5, 30, 40, 60);
        static final GlassPreset BUBBLE = new GlassPreset(0xFFFFFFFF, 0, 15, 5, 0, 20,
                40, 0xFFFFFFFF, 85, 30, 40, 0xFFFFFFFF, 55, 45, 100, 0, 60, 0);
        static final GlassPreset MIRROR = new GlassPreset(0xFFDDE3EA, 10, 20, 10, 0, 5,
                100, 0xFFFFFFFF, 90, 50, 50, 0xFFFFFFFF, 30, 45, 0, 0, 80, 80);

        static GlassPreset byName(String name) {
            return switch (name) {
                case "Frosted" -> FROSTED;
                case "Crystal" -> CRYSTAL;
                case "Prism" -> PRISM;
                case "Smoky" -> SMOKY;
                case "Ice" -> ICE;
                case "Bubble" -> BUBBLE;
                case "Mirror" -> MIRROR;
                default -> CLEAR;
            };
        }
    }

    private record MetalPreset(float pattern, float scale, float freqX, float freqY, float freqX2, float freqY2,
                               float warpX, float warpY, float detail, float flowAngle,
                               int color1, int color2, int color3, int color4,
                               float colorCycle, float brightness, float speed, float redShift, float blueShift,
                               float contour, float softness, float shine, float edgeGlow) {
        static final MetalPreset DEFAULT = new MetalPreset(0, 1.5f, 4.0f, 5.0f, 8.0f, 6.0f, 0.6f, -0.4f, 3, 0,
                0xFF0B0F2A, 0xFF5B2A86, 0xFF2EC4F1, 0xFFE8F7FF, 0.1f, 2.0f, 1.0f, 0.4f, 0.4f, 0.5f, 0.35f, 0.6f, 0.4f);
        static final MetalPreset NEON = new MetalPreset(1, 1.2f, 3.5f, 4.5f, 9.0f, 7.0f, 1.2f, 0.9f, 3, 30,
                0xFF12002A, 0xFFFF2BD6, 0xFF00F0FF, 0xFFF8FF4A, 0.3f, 2.4f, 1.3f, 0.8f, 0.8f, 0.6f, 0.25f, 0.9f, 0.8f);
        static final MetalPreset CHROME = new MetalPreset(0, 1.3f, 3.0f, 4.0f, 7.0f, 5.0f, 0.7f, -0.6f, 3, 0,
                0xFF1A1A1A, 0xFF7A7A7A, 0xFFD9D9D9, 0xFFFFFFFF, 0f, 1.8f, 0.8f, 0.15f, 0.15f, 0.7f, 0.15f, 1.2f, 0.5f);
        static final MetalPreset OCEAN = new MetalPreset(3, 1.6f, 4.5f, 6.0f, 9.5f, 7.5f, 0.9f, 0.5f, 3, 15,
                0xFF001B3A, 0xFF005F8F, 0xFF18B4D8, 0xFFBFF6FF, 0.05f, 2.0f, 0.8f, 0.3f, 0.6f, 0.35f, 0.6f, 0.5f, 0.5f);
        static final MetalPreset TOXIC = new MetalPreset(0, 1.7f, 5.3f, 7.2f, 10.8f, 8.1f, 0.8f, -0.55f, 3, 0,
                0xFF0A2A00, 0xFF2AFF2A, 0xFF9DFF00, 0xFF00FFA0, 0f, 2.0f, 1.0f, 0.5f, 0.5f, 0.4f, 0.85f, 0.6f, 0.4f);
        static final MetalPreset FIRE = new MetalPreset(0, 1.0f, 1.7f, 7.9f, 11.1f, 5.7f, -4.15f, -1.95f, 3, 90,
                0xFF1A0000, 0xFFB31200, 0xFFFF6A00, 0xFFFFE14D, 0f, 2.3f, 1.6f, 1.0f, 0.2f, 0.4f, 0.6f, 0.8f, 0.9f);

        static MetalPreset byName(String name) {
            return switch (name) {
                case "Neon" -> NEON;
                case "Chrome" -> CHROME;
                case "Ocean" -> OCEAN;
                case "Fire" -> FIRE;
                case "Toxic" -> TOXIC;
                default -> DEFAULT;
            };
        }
    }
}
