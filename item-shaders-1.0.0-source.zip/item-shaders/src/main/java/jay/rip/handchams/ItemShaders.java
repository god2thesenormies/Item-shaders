package jay.rip.handchams;

import jay.rip.handchams.config.ConfigManager;
import jay.rip.handchams.module.ModuleManager;
import jay.rip.handchams.ui.Menu;
import jay.rip.handchams.ui.MenuScreen;
import jay.rip.handchams.ui.MenuSettings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ItemShaders implements ClientModInitializer {
    public static final String MOD_ID = "itemshaders";
    public static final String NAME = "Item Shaders";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    public static final String VERSION = FabricLoader.getInstance().getModContainer(MOD_ID)
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse("dev");

    private static MenuSettings menuSettings;
    private static ModuleManager modules;
    private static ConfigManager config;
    private static Menu menu;

    @Override
    public void onInitializeClient() {
        menuSettings = new MenuSettings();
        modules = new ModuleManager();
        config = new ConfigManager();
        config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> modules.onTick());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> config.save());
    }

    public static boolean onKeyPressed(int key) {
        if (key == menuSettings.general.menuKey.get()) {
            openMenu();
            return true;
        }
        modules.onKeyPressed(key);
        return false;
    }

    public static boolean onKeyPressedInScreen(int key) {
        if (key == menuSettings.general.menuKey.get()) {
            openMenu();
            return true;
        }
        return false;
    }

    public static void openMenu() {
        if (menu == null) {
            menu = new Menu();
        }
        Minecraft minecraft = Minecraft.getInstance();
        Screen parent = minecraft.screen;

        if (minecraft.level != null && parent != null && !parent.isPauseScreen()) {
            parent = null;
        }
        minecraft.setScreen(new MenuScreen(menu, parent));
    }

    public static MenuSettings menuSettings() {
        return menuSettings;
    }

    public static ModuleManager modules() {
        return modules;
    }

    public static ConfigManager config() {
        return config;
    }
}
