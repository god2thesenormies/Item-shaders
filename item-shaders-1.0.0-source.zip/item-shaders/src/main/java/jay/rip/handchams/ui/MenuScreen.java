package jay.rip.handchams.ui;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.compat.Screens;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class MenuScreen extends Screen {
    private static final int DIM = 0x70000000;

    private final Menu menu;
    private final Screen parent;

    public MenuScreen(Menu menu, Screen parent) {
        super(Component.literal(ItemShaders.NAME));
        this.menu = menu;
        this.parent = parent;
    }

    @Override
    public void added() {
        super.added();
        menu.open();
    }

    @Override
    public void removed() {
        super.removed();
        menu.close();
        ItemShaders.config().save();
    }

    @Override
    public void tick() {
        if (menu.isClosed()) {
            minecraft.setScreen(parent);
        }
    }

    @Override
    public void onClose() {
        menu.close();
    }

    @Override
    public boolean isPauseScreen() {
        return parent != null && parent.isPauseScreen();
    }

    @Override
    protected void init() {
        if (parent != null) {
            Screens.resize(parent, width, height);
        }
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        if (minecraft.level == null) {
            renderPanorama(graphics, partialTick);
        }

        if (parent != null) {
            parent.render(graphics, -1, -1, partialTick);
            graphics.nextStratum();
        }
        if (ItemShaders.menuSettings().general.blur.isEnabled()) {
            try {
                renderBlurredBackground(graphics);
            } catch (IllegalStateException alreadyBlurred) {
            }
        }
        graphics.fill(0, 0, width, height, Colors.fade(DIM, menu.openProgress()));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        moveMouse(minecraft.mouseHandler.getScaledXPos(minecraft.getWindow()),
                minecraft.mouseHandler.getScaledYPos(minecraft.getWindow()));
        float scale = guiToMenu();
        graphics.pose().pushMatrix();
        graphics.pose().scale(1f / scale, 1f / scale);
        menu.render(graphics, width * scale, height * scale);
        graphics.pose().popMatrix();
    }

    private float guiToMenu() {
        return minecraft.getWindow().getGuiScale() / menu.scale();
    }

    private Input input() {
        return menu.ui().input();
    }

    private void moveMouse(double x, double y) {
        float scale = guiToMenu();
        input().onMouseMove((float) x * scale, (float) y * scale);
    }

    @Override
    public void mouseMoved(double x, double y) {
        moveMouse(x, y);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        moveMouse(event.x(), event.y());
        input().onMouseButton(event.button(), true);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        moveMouse(event.x(), event.y());
        input().onMouseButton(event.button(), false);
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        moveMouse(event.x(), event.y());
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        input().onScroll((float) scrollY);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (menu.ui().isKeyboardCaptured()) {
            input().onKey(event.key());
            return true;
        }
        if (event.isEscape() && menu.ui().popup() != null) {
            menu.ui().closePopup();
            return true;
        }
        if (event.isEscape() || ItemShaders.menuSettings().general.menuKey.matches(event.key())) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (menu.ui().isKeyboardCaptured()) {
            input().onChar(event.codepointAsString());
            return true;
        }
        return false;
    }
}
