package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.ActionSetting;
import jay.rip.handchams.setting.BooleanSetting;
import jay.rip.handchams.setting.ColorSetting;
import jay.rip.handchams.setting.KeybindSetting;
import jay.rip.handchams.setting.ModeSetting;
import jay.rip.handchams.setting.NumberSetting;
import jay.rip.handchams.setting.SectionSetting;
import jay.rip.handchams.setting.Setting;

public final class SettingRows {
    private SettingRows() {
    }

    public static SettingRow<?> create(Setting<?> setting) {
        return switch (setting) {
            case BooleanSetting toggle -> new ToggleRow(toggle);
            case NumberSetting number -> new SliderRow(number);
            case ModeSetting mode -> new ModeRow(mode);
            case ColorSetting color -> new ColorRow(color);
            case KeybindSetting keybind -> new KeybindRow(keybind);
            case ActionSetting action -> new ActionRow(action);
            case SectionSetting section -> new SectionRow(section);
            default -> throw new IllegalArgumentException("No row for " + setting.getClass().getSimpleName());
        };
    }
}
