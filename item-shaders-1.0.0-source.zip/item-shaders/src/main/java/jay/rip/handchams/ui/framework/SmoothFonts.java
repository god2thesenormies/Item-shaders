package jay.rip.handchams.ui.framework;

import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FreeType;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class SmoothFonts {
    private static final Set<Long> UNHINTED_FACES = Collections.synchronizedSet(new HashSet<>());

    private SmoothFonts() {
    }

    public static void markUnhinted(FT_Face face) {
        if (face != null) {
            UNHINTED_FACES.add(face.address());
        }
    }

    public static boolean isUnhinted(FT_Face face) {
        return face != null && UNHINTED_FACES.contains(face.address());
    }

    public static int darken(int coverage) {
        return DARKEN[coverage & 0xFF];
    }

    private static final int[] DARKEN = new int[256];

    static {
        for (int i = 0; i < 256; i++) {
            DARKEN[i] = Math.round((1f - (float) Math.pow(1f - i / 255f, 1.3)) * 255f);
        }
    }

    public static int loadFlags(FT_Face face, int flags) {
        return isUnhinted(face) ? flags | FreeType.FT_LOAD_NO_HINTING : flags;
    }
}
