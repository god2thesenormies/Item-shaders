package jay.rip.handchams.ui.component;

import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Icons;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;
import org.lwjgl.glfw.GLFW;

public final class SearchField {
    private static final float TEXT_SIZE = 18f;
    private static final float GROW = 24f;
    private static final int MAX_LENGTH = 32;
    private static final int PLACEHOLDER = Colors.rgb(160, 160, 160);

    private final StringBuilder text = new StringBuilder();
    private final Spring focus = new Spring(0f, 14f, 0.5f);
    private final Approach hover = new Approach(0f);
    private final Spring iconScale = new Spring(1f, 16f, 0.3f);
    private final Jelly jelly = new Jelly();

    public String text() {
        return text.toString();
    }

    public void clear() {
        text.setLength(0);
    }

    public void render(Ui ui, float x, float y, float width, float height) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();

        float focusAmount = focus.value();
        float left = x - GROW * focusAmount;
        float boxWidth = width + GROW * focusAmount;

        boolean hovered = input.hovering(left, y, boxWidth, height);
        if (input.clicked(left, y, boxWidth, height)) {
            ui.focus(this);
        } else if (input.wasPressed(Input.LEFT) && !hovered) {
            ui.unfocus(this);
        }
        boolean focused = ui.hasFocus(this);
        if (focused) {
            handleTyping(ui);
            focused = ui.hasFocus(this);
        }

        focusAmount = focus.update(focused ? 1f : 0f, delta);
        float hoverAmount = hover.update(hovered ? 1f : 0f, delta);
        float radius = height * 0.5f;
        float rim = Math.clamp(focusAmount, 0f, 1f);
        jelly.update(input.held(left, y, boxWidth, height), false, 0.5f, delta);
        jelly.push(renderer, left + boxWidth * 0.5f, y + height * 0.5f);

        if (rim > 0.01f) {
            renderer.roundedRect(left - 1.5f, y - 1.5f, boxWidth + 3f, height + 3f, radius + 1.5f, Colors.fade(Theme.accent(), 0.6f * rim));
        }
        renderer.roundedRectBorder(left, y, boxWidth, height, radius,
                Colors.mix(Theme.SEARCH, Theme.SEARCH_HOVER, Math.max(hoverAmount, focusAmount)), Theme.CARD_RIM);

        float centerY = y + height * 0.5f;
        float icon = iconScale.update(focused ? 1.12f : hovered ? 1.06f : 1f, delta);
        renderer.push();
        renderer.scaleAround(left + 26f, centerY, icon, icon);
        renderer.icon(Icons.SEARCH, left + 26f, centerY, 21f, Colors.mix(Colors.rgb(225, 225, 225), Theme.accentText(), focusAmount), 0.9f);
        renderer.pop();

        float textX = left + 48f;
        float textWidth = x + width - 18f - textX;
        if (text.isEmpty()) {
            renderer.text(TextFont.REGULAR, "Search", textX, centerY, TEXT_SIZE, PLACEHOLDER);
        } else {
            String shown = visibleTail(renderer, textWidth);
            renderer.text(TextFont.REGULAR, shown, textX, centerY, TEXT_SIZE, Colors.rgb(228, 228, 228));
            textX += renderer.textWidth(TextFont.REGULAR, shown, TEXT_SIZE);
        }
        if (focused && (ui.time() * 2f) % 2f < 1.2f) {
            float caretX = text.isEmpty() ? textX - 4f : textX + 1.5f;
            renderer.rect(caretX, centerY - 9f, 1.5f, 18f, Theme.accent());
        }
        renderer.pop();
    }

    private void handleTyping(Ui ui) {
        Input input = ui.input();
        for (char c : input.typed().toCharArray()) {
            if (c >= ' ' && text.length() < MAX_LENGTH) {
                text.append(c);
            }
        }
        for (int key : input.keys()) {
            switch (key) {
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    if (!text.isEmpty()) {
                        text.setLength(text.length() - 1);
                    }
                }
                case GLFW.GLFW_KEY_DELETE -> clear();
                case GLFW.GLFW_KEY_ESCAPE, GLFW.GLFW_KEY_ENTER -> ui.unfocus(this);
                default -> {
                }
            }
        }
    }

    private String visibleTail(Renderer renderer, float maxWidth) {
        String value = text.toString();
        int start = 0;
        while (start < value.length() && renderer.textWidth(TextFont.REGULAR, value.substring(start), TEXT_SIZE) > maxWidth) {
            start++;
        }
        return value.substring(start);
    }
}
