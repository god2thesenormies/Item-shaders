package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class KeybindSetting extends Setting<Integer> {
    public static final int NONE = InputConstants.UNKNOWN.getValue();

    private static final int MOUSE_BASE = 0x10000;

    public KeybindSetting(String name, String description, int defaultKey) {
        super(name, description, defaultKey);
    }

    public static int mouse(int button) {
        return MOUSE_BASE + button;
    }

    public boolean isBound() {
        return get() != NONE;
    }

    public boolean isMouse() {
        return get() >= MOUSE_BASE;
    }

    public boolean matches(int key) {
        return isBound() && !isMouse() && get() == key;
    }

    public String keyName() {
        if (!isBound()) {
            return "Unbound";
        }
        if (isMouse()) {
            return switch (get() - MOUSE_BASE) {
                case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "Left Click";
                case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "Right Click";
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "Middle Click";
                default -> "Mouse " + (get() - MOUSE_BASE + 1);
            };
        }
        return InputConstants.Type.KEYSYM.getOrCreate(get()).getDisplayName().getString();
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement json) {
        set(json.getAsInt());
    }
}
