package jay.rip.handchams.module;

import com.google.gson.JsonObject;
import jay.rip.handchams.setting.KeybindSetting;
import jay.rip.handchams.setting.Setting;
import jay.rip.handchams.setting.SettingGroup;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module extends SettingGroup {
    protected final Minecraft mc = Minecraft.getInstance();

    private final Category category;
    private final KeybindSetting keybind = new KeybindSetting("Keybind", "Toggles this module", KeybindSetting.NONE);
    private boolean enabled;

    protected Module(String name, String description, Category category) {
        super(name, description);
        this.category = category;
    }

    public Category category() {
        return category;
    }

    public String subcategory() {
        return null;
    }

    public KeybindSetting keybind() {
        return keybind;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public int splitIndex() {
        return -1;
    }

    public void onTick() {
    }

    @Override
    public List<Setting<?>> settings() {
        List<Setting<?>> settings = new ArrayList<>(super.settings());
        settings.add(keybind);
        return settings;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("enabled", enabled);
        return json;
    }

    @Override
    public void fromJson(JsonObject json) {
        super.fromJson(json);
        if (json.has("enabled")) {
            setEnabled(json.get("enabled").getAsBoolean());
        }
    }
}
