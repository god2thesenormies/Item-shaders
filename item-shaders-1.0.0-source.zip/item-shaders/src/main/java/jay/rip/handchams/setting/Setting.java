package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import jay.rip.handchams.ui.framework.Label;

import java.util.function.BooleanSupplier;

public abstract class Setting<T> {
    private final Label name;
    private final Label description;
    private final String configKey;
    private final T defaultValue;
    private T value;
    private BooleanSupplier visibility = () -> true;

    private SectionSetting section;

    protected Setting(String name, String description, T defaultValue) {
        this.name = new Label(name);
        this.description = new Label(description);
        this.configKey = this.name.configKey();
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public Label name() {
        return name;
    }

    public Label description() {
        return description;
    }

    public String configKey() {
        return configKey;
    }

    public T get() {
        return value;
    }

    public void set(T value) {
        this.value = sanitize(value);
    }

    public T defaultValue() {
        return defaultValue;
    }

    public boolean isVisible() {
        return visibility.getAsBoolean() && (section == null || (section.isVisible() && section.isOpen()));
    }

    void setSection(SectionSetting section) {
        this.section = section;
    }

    public SectionSetting section() {
        return section;
    }

    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S visibleWhen(BooleanSupplier condition) {
        this.visibility = condition;
        return (S) this;
    }

    public boolean isPersistent() {
        return true;
    }

    protected T sanitize(T value) {
        return value;
    }

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement json);
}
