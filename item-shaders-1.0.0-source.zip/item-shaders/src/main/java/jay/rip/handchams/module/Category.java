package jay.rip.handchams.module;

public enum Category {
    VISUALS("Visuals");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
