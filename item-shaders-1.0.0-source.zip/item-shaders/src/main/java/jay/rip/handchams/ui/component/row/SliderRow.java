package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.NumberSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class SliderRow extends SettingRow<NumberSetting> {
    private static final float WIDTH = 135f;
    private static final float TRACK_INSET = 8f;
    private static final float VALUE_SIZE = 15.5f;
    private static final float PILL_HEIGHT = 31f;

    private final Spring position;
    private final Spring knobSize = new Spring(8f, 18f, 0.32f);
    private final Approach active = new Approach(0f, 12f);
    private final Spring valueWidth = new Spring(0f, 18f, 0.6f);
    private final Spring valuePuff = new Spring(1f, 16f, 0.3f);
    private boolean dragging;
    private boolean sized;

    public SliderRow(NumberSetting setting) {
        super(setting);
        this.position = new Spring((float) setting.progress(), 18f, 0.6f);
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();

        float left = right - WIDTH;
        float trackLeft = left + TRACK_INSET;
        float trackRight = right - TRACK_INSET;
        float trackWidth = trackRight - trackLeft;
        boolean trackHovered = input.hovering(left, centerY - 13f, WIDTH, 26f);
        if (input.clicked(left, centerY - 13f, WIDTH, 26f)) {
            dragging = true;
        }
        if (dragging) {
            setting.setProgress(Math.clamp((input.mouseX() - trackLeft) / trackWidth, 0f, 1f));
            dragging = input.isDown(Input.LEFT);
        }

        float t = Math.clamp(position.update((float) setting.progress(), delta), 0f, 1f);
        float activeAmount = active.update(dragging ? 1f : 0f, delta);
        float radius = knobSize.update(dragging ? 11f : trackHovered ? 9.5f : 8f, delta);

        float knobX = trackLeft + trackWidth * t;
        renderer.roundedRect(trackLeft - 3f, centerY - 3f, trackWidth + 6f, 6f, 3f, Theme.CONTROL);
        renderer.roundedRect(trackLeft - 3f, centerY - 3f, knobX - trackLeft + 6f, 6f, 3f, Theme.accent());
        if (activeAmount > 0.01f) {
            renderer.circle(knobX, centerY, radius + 6f * activeAmount, Colors.fade(Theme.accent(), 0.22f * activeAmount));
        }

        float stretch = 1f + Math.min(Math.abs(position.velocity()) * 0.06f, 0.45f);
        float halfWidth = radius * stretch;
        float halfHeight = radius / (float) Math.sqrt(stretch);
        renderer.roundedRect(knobX - halfWidth, centerY - halfHeight + 1.5f, halfWidth * 2f, halfHeight * 2f, halfHeight, Theme.KNOB_SHADOW);
        renderer.roundedRect(knobX - halfWidth, centerY - halfHeight, halfWidth * 2f, halfHeight * 2f, Math.min(halfWidth, halfHeight), Theme.KNOB);

        String value = setting.format();
        float textWidth = renderer.textWidth(TextFont.REGULAR, value, VALUE_SIZE);
        if (!sized) {
            valueWidth.snap(textWidth);
            sized = true;
        }
        float shownWidth = valueWidth.update(textWidth, delta);
        float pillRight = left - 8f;
        float pillLeft = pillRight - shownWidth - 18f;

        float puff = valuePuff.update(dragging ? 1.1f : 1f, delta);
        renderer.push();
        renderer.scaleAround((pillLeft + pillRight) * 0.5f, centerY, puff, puff);
        renderer.roundedRect(pillLeft, centerY - PILL_HEIGHT * 0.5f, pillRight - pillLeft, PILL_HEIGHT, PILL_HEIGHT * 0.5f,
                Colors.mix(Theme.CONTROL, Theme.CONTROL_HOVER, activeAmount));
        renderer.textCentered(TextFont.REGULAR, value, (pillLeft + pillRight) * 0.5f, centerY, VALUE_SIZE,
                Colors.mix(Theme.CONTROL_TEXT, Theme.accentText(), activeAmount));
        renderer.pop();
        return pillLeft;
    }
}
