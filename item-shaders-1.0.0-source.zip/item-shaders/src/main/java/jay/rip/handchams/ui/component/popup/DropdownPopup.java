package jay.rip.handchams.ui.component.popup;

import jay.rip.handchams.setting.ModeSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Popup;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

import java.util.ArrayList;
import java.util.List;

public final class DropdownPopup implements Popup {
    private static final float ITEM_HEIGHT = 32f;
    private static final float ITEM_GAP = 2f;
    private static final float PADDING = 5f;
    private static final float RADIUS = 16f;
    private static final float TEXT_SIZE = 18f;
    private static final int ITEM_TEXT = Colors.rgb(190, 190, 190);

    private final ModeSetting setting;
    private final Spring reveal = new Spring(0f, 15f, 0.45f);
    private final Spring highlight = new Spring(0f, 20f, 0.55f);
    private final List<Spring> itemHovers = new ArrayList<>();
    private float x;
    private float y;
    private float width;

    public DropdownPopup(ModeSetting setting) {
        this.setting = setting;
    }

    public void open(Ui ui, float x, float y, float width) {
        this.x = x;
        this.y = Math.min(y, ui.viewHeight() - fullHeight() - 8f);
        this.width = width;
        reveal.snap(0f);
        highlight.snap(setting.index());
        itemHovers.clear();
        ui.openPopup(this);
    }

    private float fullHeight() {
        int count = setting.modes().size();
        return count * ITEM_HEIGHT + (count - 1) * ITEM_GAP + PADDING * 2f;
    }

    @Override
    public boolean contains(float px, float py) {
        return px >= x && px < x + width && py >= y && py < y + fullHeight();
    }

    @Override
    public void render(Ui ui) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();
        float step = ITEM_HEIGHT + ITEM_GAP;

        float progress = reveal.update(1f, delta);
        float drawY = y;
        float height = fullHeight() * Math.max(progress, 0.03f);
        float fullWidth = width;
        float shownWidth = fullWidth * (0.9f + 0.1f * progress);
        float x = this.x + (fullWidth - shownWidth) * 0.5f;
        float width = shownWidth;
        renderer.pushOpacity(Math.clamp(progress * 2.5f, 0f, 1f));

        Theme.shadow(renderer, x, drawY, width, height, RADIUS, 3);
        renderer.roundedRect(x - 1f, drawY - 1f, width + 2f, height + 2f, RADIUS + 1f, Theme.POPUP_BORDER);
        renderer.roundedRect(x, drawY, width, height, RADIUS, Theme.POPUP);
        ui.pushClip(x, drawY, width, height);

        int hovered = -1;
        float relativeY = input.mouseY() - drawY - PADDING;
        if (input.hovering(x, drawY, width, height) && relativeY >= 0f) {
            int index = (int) (relativeY / step);
            hovered = index < setting.modes().size() ? index : -1;
        }
        float highlightIndex = highlight.update(hovered >= 0 ? hovered : setting.index(), delta);
        renderer.roundedRect(x + PADDING, drawY + PADDING + highlightIndex * step, width - PADDING * 2f, ITEM_HEIGHT, 12f, Theme.POPUP_HIGHLIGHT);

        int count = setting.modes().size();
        float stagger = Math.min(0.12f, 0.55f / Math.max(count, 1));
        for (int i = 0; i < count; i++) {
            String mode = setting.modes().get(i);
            float itemY = drawY + PADDING + i * step;
            float appear = Math.clamp((progress - i * stagger) / 0.35f, 0f, 1f);
            float centerY = itemY + ITEM_HEIGHT * 0.5f + (1f - appear) * 6f;
            boolean selected = i == setting.index();
            while (itemHovers.size() <= i) {
                itemHovers.add(new Spring(0f, 16f, 0.55f));
            }
            float itemHover = itemHovers.get(i).update(i == hovered ? 1f : 0f, delta);

            int color = selected ? Theme.accentText() : Colors.mix(ITEM_TEXT, Theme.TEXT, itemHover);
            renderer.pushOpacity(appear);
            renderer.text(TextFont.SEMIBOLD, mode, x + PADDING + 11f + itemHover * 4f + (1f - appear) * 12f, centerY, TEXT_SIZE, color);
            renderer.popOpacity();

            if (input.clicked(x + PADDING, itemY, width - PADDING * 2f, ITEM_HEIGHT)) {
                setting.select(i);
                ui.closePopup();
            }
        }

        ui.popClip();
        renderer.popOpacity();
    }
}
