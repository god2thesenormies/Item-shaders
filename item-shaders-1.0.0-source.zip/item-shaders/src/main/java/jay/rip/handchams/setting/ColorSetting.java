package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class ColorSetting extends Setting<Integer> {
    private final boolean allowAlpha;

    public ColorSetting(String name, String description, int defaultValue) {
        this(name, description, defaultValue, true);
    }

    public ColorSetting(String name, String description, int defaultValue, boolean allowAlpha) {
        super(name, description, defaultValue);
        this.allowAlpha = allowAlpha;
    }

    public boolean allowsAlpha() {
        return allowAlpha;
    }

    public String hex() {
        String rgb = String.format("#%06X", get() & 0xFFFFFF);
        int alpha = get() >>> 24;
        return alpha == 255 ? rgb : rgb + " " + Math.round(alpha / 2.55f) + "%";
    }

    @Override
    protected Integer sanitize(Integer value) {
        return allowAlpha ? value : value | 0xFF000000;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(String.format("%08X", get()));
    }

    @Override
    public void fromJson(JsonElement json) {
        set(Integer.parseUnsignedInt(json.getAsString(), 16));
    }
}
