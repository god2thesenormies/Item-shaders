package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.ui.framework.Label;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SettingGroup {
    private final Label name;
    private final Label description;
    private final String configKey;
    private final List<Setting<?>> settings = new ArrayList<>();

    private SectionSetting currentSection;

    public SettingGroup(String name, String description) {
        this.name = new Label(name);
        this.description = new Label(description);
        this.configKey = this.name.configKey();
    }

    public Label name() {
        return name;
    }

    public Label description() {
        return description;
    }

    public String configKey() {
        return configKey;
    }

    public List<Setting<?>> settings() {
        return Collections.unmodifiableList(settings);
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        if (setting instanceof SectionSetting section) {
            currentSection = section;
        } else if (currentSection != null) {
            setting.setSection(currentSection);
        }
        return setting;
    }

    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        for (Setting<?> setting : settings()) {
            if (setting.isPersistent()) {
                json.add(setting.configKey(), setting.toJson());
            }
        }
        return json;
    }

    public void fromJson(JsonObject json) {
        for (Setting<?> setting : settings()) {
            JsonElement value = json.get(setting.configKey());
            if (value == null || !setting.isPersistent()) {
                continue;
            }
            try {
                setting.fromJson(value);
            } catch (RuntimeException e) {
                ItemShaders.LOGGER.warn("Couldn't load setting '{}' in '{}'", setting.configKey(), configKey(), e);
            }
        }
    }
}
