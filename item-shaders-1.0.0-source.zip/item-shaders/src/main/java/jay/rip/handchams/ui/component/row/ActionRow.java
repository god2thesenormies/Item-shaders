package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.ActionSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class ActionRow extends SettingRow<ActionSetting> {
    private static final float BUTTON_HEIGHT = 31f;
    private static final float TEXT_SIZE = 16.5f;
    private static final float RIPPLE_TIME = 0.6f;

    private final Approach hover = new Approach(0f);
    private final Jelly jelly = new Jelly();
    private float rippleAge = RIPPLE_TIME;
    private float rippleX;

    public ActionRow(ActionSetting setting) {
        super(setting);
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();

        float buttonWidth = renderer.textWidth(TextFont.SEMIBOLD, setting.label(), TEXT_SIZE) + 34f;
        float buttonX = right - buttonWidth;
        float buttonY = centerY - BUTTON_HEIGHT * 0.5f;
        float radius = BUTTON_HEIGHT * 0.5f;

        boolean buttonHovered = input.hovering(buttonX, buttonY, buttonWidth, BUTTON_HEIGHT);
        if (input.clicked(buttonX, buttonY, buttonWidth, BUTTON_HEIGHT)) {
            setting.run();
            rippleAge = 0f;
            rippleX = input.mouseX() - buttonX;
        }
        rippleAge += delta;

        float hoverAmount = hover.update(buttonHovered ? 1f : 0f, delta);
        jelly.update(input.held(buttonX, buttonY, buttonWidth, BUTTON_HEIGHT), buttonHovered, 1f, delta);
        jelly.push(renderer, buttonX + buttonWidth * 0.5f, centerY);
        renderer.roundedRect(buttonX, buttonY, buttonWidth, BUTTON_HEIGHT, radius, Colors.mix(Theme.CONTROL, Theme.CONTROL_HOVER, hoverAmount));
        if (rippleAge < RIPPLE_TIME) {
            float progress = rippleAge / RIPPLE_TIME;
            float spread = Math.max(Easing.outCubic(progress) * buttonWidth, radius);
            float left = Math.max(buttonX, buttonX + rippleX - spread);
            float rippleRight = Math.min(buttonX + buttonWidth, buttonX + rippleX + spread);
            renderer.roundedRect(left, buttonY, rippleRight - left, BUTTON_HEIGHT, radius, Colors.fade(Theme.accent(), 0.45f * (1f - progress)));
        }
        int textColor = Colors.mix(Theme.CONTROL_TEXT, Theme.accentText(), hoverAmount);
        renderer.textCentered(TextFont.SEMIBOLD, setting.label(), buttonX + buttonWidth * 0.5f, centerY, TEXT_SIZE, textColor);
        renderer.pop();
        return buttonX;
    }
}
