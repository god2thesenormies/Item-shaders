package jay.rip.handchams.ui.component;

import jay.rip.handchams.module.Module;
import jay.rip.handchams.setting.SettingGroup;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class ContentPanel {
    private static final float PADDING_X = 17f;
    private static final float PADDING_Y = 20f;
    private static final float GAP = 16f;
    private static final float SCROLL_STEP = 90f;
    private static final float FADE_HEIGHT = 44f;

    private final Map<SettingGroup, Card> cards = new HashMap<>();
    private final Spring overscroll = new Spring(0f, 16f, 0.45f);
    private final Spring scrollbar = Spring.smooth(0f);
    private Object page;
    private float scrollTarget;
    private float scrollPosition;
    private float scrollSpeed;
    private float contentHeight;
    private Card topCard;
    private float topCardBottom;
    private Card bottomCard;
    private float bottomCardTop;

    public void render(Ui ui, Object page, List<? extends SettingGroup> groups, float x, float y, float width, float height) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();
        Theme.panel(renderer, x, y, width, height);

        if (!Objects.equals(page, this.page)) {
            this.page = page;
            scrollTarget = 0f;
            scrollPosition = 0f;
            overscroll.snap(0f);
            ui.restartPage();
        }
        float pageTime = ui.pageTime();

        float maxScroll = Math.max(0f, contentHeight - height);
        scrollTarget -= input.takeScroll(x, y, width, height) * SCROLL_STEP;
        float clamped = Math.clamp(scrollTarget, 0f, maxScroll);
        float over = Math.clamp(scrollTarget - clamped, -80f, 80f) * (1f - Math.clamp(delta * 9f, 0f, 1f));
        scrollTarget = clamped + over;
        float previous = scrollPosition;
        scrollPosition += (clamped - scrollPosition) * Math.clamp(delta * 14f, 0f, 1f);
        if (Math.abs(scrollPosition - clamped) < 0.5f) {
            scrollPosition = clamped;
        }
        scrollSpeed = delta > 0f ? (scrollPosition - previous) / delta : 0f;
        float offset = scrollPosition;

        float shift = overscroll.update(-over * 0.6f, delta);

        ui.pushClip(x + 1f, y + 1f, width - 2f, height - 2f);

        float cardX = x + PADDING_X;
        float cardWidth = width - PADDING_X * 2f;
        float cardY = y + PADDING_Y - offset + shift;
        topCard = null;
        bottomCard = null;
        for (int i = 0; i < groups.size(); i++) {
            Card card = cards.computeIfAbsent(groups.get(i), group -> new Card(group, !(group instanceof Module)));
            float cardHeight = card.update(delta);

            float intro = pageTime - i * 0.09f;
            float alpha = Math.clamp(intro / 0.22f, 0f, 1f);
            float rise = (1f - Easing.outBack(intro / 0.5f)) * 20f;

            float top = cardY + rise;
            if (top + cardHeight > y && top < y + height && alpha > 0f) {
                renderer.pushOpacity(alpha);
                card.render(ui, cardX, top, cardWidth);
                renderer.popOpacity();

                if (top < y + FADE_HEIGHT && top + cardHeight > y) {
                    topCard = card;
                    topCardBottom = top + cardHeight;
                }
                if (top < y + height && top + cardHeight > y + height - FADE_HEIGHT) {
                    bottomCard = card;
                    bottomCardTop = top;
                }
            }
            cardY += cardHeight + GAP;
        }
        contentHeight = cardY + offset - shift - GAP + PADDING_Y - y;

        if (groups.isEmpty()) {
            boolean searching = page instanceof String key && key.startsWith("search:");
            String title = searching ? "Nothing found" : "No modules yet";
            String hint = searching ? "Try a different search" : "Modules added to this category show up here";
            renderer.textCentered(TextFont.SEMIBOLD, title, x + width * 0.5f, y + height * 0.42f, 21f, Theme.TEXT);
            renderer.textCentered(TextFont.REGULAR, hint, x + width * 0.5f, y + height * 0.42f + 26f, 17f, Theme.TEXT_DIM);
        }

        renderEdgeFades(renderer, x, y, width, height, cardX, cardWidth, offset, maxScroll);
        renderScrollbar(ui, x, y, width, height, offset, maxScroll);
        ui.popClip();
    }

    private void renderEdgeFades(Renderer renderer, float x, float y, float width, float height, float cardX, float cardWidth,
                                 float offset, float maxScroll) {
        float top = Math.clamp(offset / PADDING_Y, 0f, 1f);
        float bottom = Math.clamp((maxScroll - offset) / PADDING_Y, 0f, 1f);
        float cardRight = cardX + cardWidth;
        if (top > 0f) {
            Fade fade = new Fade(y, y + FADE_HEIGHT, top, 0f);
            fade.draw(renderer, x, cardX - x, y, y + FADE_HEIGHT, Theme.PANEL);
            fade.draw(renderer, cardRight, x + width - cardRight, y, y + FADE_HEIGHT, Theme.PANEL);
            float cardEnd = topCard != null ? Math.min(topCardBottom, y + FADE_HEIGHT) : y;
            if (topCard != null) {
                fade.draw(renderer, cardX, cardWidth, y, cardEnd, topCard.background());
            }
            fade.draw(renderer, cardX, cardWidth, cardEnd, y + FADE_HEIGHT, Theme.PANEL);
        }
        if (bottom > 0f) {
            float fadeTop = y + height - FADE_HEIGHT;
            Fade fade = new Fade(fadeTop, y + height, 0f, bottom);
            fade.draw(renderer, x, cardX - x, fadeTop, y + height, Theme.PANEL);
            fade.draw(renderer, cardRight, x + width - cardRight, fadeTop, y + height, Theme.PANEL);
            float cardStart = bottomCard != null ? Math.max(bottomCardTop, fadeTop) : y + height;
            fade.draw(renderer, cardX, cardWidth, fadeTop, cardStart, Theme.PANEL);
            if (bottomCard != null) {
                fade.draw(renderer, cardX, cardWidth, cardStart, y + height, bottomCard.background());
            }
        }
    }

    private record Fade(float top, float bottom, float topStrength, float bottomStrength) {
        void draw(Renderer renderer, float x, float width, float from, float to, int color) {
            if (width <= 0f || to - from <= 0f) {
                return;
            }
            int start = Colors.fade(color, strengthAt(from));
            int end = Colors.fade(color, strengthAt(to));
            renderer.gradientVertical(x, from, width, to - from, start, end);
        }

        private float strengthAt(float y) {
            float t = Math.clamp((y - top) / (bottom - top), 0f, 1f);
            return topStrength + (bottomStrength - topStrength) * t;
        }
    }

    private void renderScrollbar(Ui ui, float x, float y, float width, float height, float offset, float maxScroll) {
        boolean scrolling = Math.abs(scrollSpeed) > 5f;
        boolean hovered = ui.input().hovering(x + width - PADDING_X, y, PADDING_X, height);
        float visible = scrollbar.update(maxScroll > 0f && (scrolling || hovered) ? 1f : 0f, ui.delta());
        if (visible < 0.01f) {
            return;
        }
        float trackHeight = height - 24f;
        float thumbHeight = Math.max(40f, trackHeight * height / contentHeight);
        float thumbY = y + 12f + (trackHeight - thumbHeight) * (offset / maxScroll);
        ui.renderer().roundedRect(x + width - 9f, thumbY, 4f, thumbHeight, 2f, Colors.fade(Theme.accent(), 0.55f * visible));
    }
}
