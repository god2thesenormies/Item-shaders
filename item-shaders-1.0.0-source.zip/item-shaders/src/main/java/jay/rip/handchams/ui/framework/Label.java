package jay.rip.handchams.ui.framework;

import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

import java.util.Locale;

public final class Label {
    private final String text;
    private final int[] codepoints;

    public Label(String text) {
        this.text = text;
        this.codepoints = text.codePoints().toArray();
    }

    public String text() {
        return text;
    }

    public int length() {
        return codepoints.length;
    }

    public boolean isEmpty() {
        return codepoints.length == 0;
    }

    public FormattedCharSequence sequence(Style style) {
        return sequence(style, codepoints.length, false);
    }

    public FormattedCharSequence sequence(Style style, int limit, boolean ellipsis) {
        return output -> {
            int shown = Math.min(limit, codepoints.length);
            for (int i = 0; i < shown; i++) {
                if (!output.accept(i, style, codepoints[i])) {
                    return false;
                }
            }
            if (ellipsis && shown < codepoints.length) {
                for (int i = 0; i < 3; i++) {
                    if (!output.accept(shown + i, style, '.')) {
                        return false;
                    }
                }
            }
            return true;
        };
    }

    public boolean containsLower(String query) {
        return query.isEmpty() || text.toLowerCase(Locale.ROOT).contains(query);
    }

    public String configKey() {
        return text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", "");
    }

    @Override
    public String toString() {
        return text;
    }
}
