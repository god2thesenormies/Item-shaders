package jay.rip.handchams.ui.framework;

public final class Easing {
    private Easing() {
    }

    public static float clamp01(float t) {
        return Math.clamp(t, 0f, 1f);
    }

    public static float outCubic(float t) {
        t = 1f - clamp01(t);
        return 1f - t * t * t;
    }

    public static float outBack(float t) {
        t = clamp01(t) - 1f;
        float s = 1.7f;
        return 1f + (s + 1f) * t * t * t + s * t * t;
    }
}
