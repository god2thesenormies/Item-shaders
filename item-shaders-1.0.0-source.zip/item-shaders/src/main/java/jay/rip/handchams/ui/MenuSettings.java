package jay.rip.handchams.ui;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.setting.ActionSetting;
import jay.rip.handchams.setting.BooleanSetting;
import jay.rip.handchams.setting.ColorSetting;
import jay.rip.handchams.setting.KeybindSetting;
import jay.rip.handchams.setting.NumberSetting;
import jay.rip.handchams.setting.SettingGroup;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class MenuSettings {
    public final General general = new General();
    public final Appearance appearance = new Appearance();
    public final Config config = new Config();

    public List<SettingGroup> groups() {
        return List.of(general, appearance, config);
    }

    public static final class General extends SettingGroup {
        public final KeybindSetting menuKey = add(new KeybindSetting("Menu Key",
                "Opens and closes the menu", GLFW.GLFW_KEY_RIGHT_SHIFT));
        public final NumberSetting scale = add(new NumberSetting("Menu Scale",
                "Size of the menu on screen", 1.0, 0.6, 1.6, 0.05, "x"));
        public final NumberSetting animationSpeed = add(new NumberSetting("Animation Speed",
                "How fast the menu animates", 1.0, 0.25, 2.0, 0.05, "x"));
        public final BooleanSetting blur = add(new BooleanSetting("Background Blur",
                "Blurs the game behind the menu", true));
        public final BooleanSetting tooltips = add(new BooleanSetting("Tooltips",
                "Hides descriptions and shows them only when hovering", true));

        private General() {
            super("General", "How the menu behaves");
        }
    }

    public static final class Appearance extends SettingGroup {
        public final ColorSetting accent = add(new ColorSetting("Accent",
                "Main highlight color", 0xFFD6A4AE, false));
        public final ColorSetting secondary = add(new ColorSetting("Secondary",
                "Second color used in gradients", 0xFFB4848E, false));
        public final NumberSetting cornerRadius = add(new NumberSetting("Corner Radius",
                "Roundness of panels and cards", 20, 0, 24, 1, "px"));

        private Appearance() {
            super("Appearance", "Colors and shape");
        }
    }

    public static final class Config extends SettingGroup {
        public final ActionSetting save = add(new ActionSetting("Save Config",
                "Writes every setting to disk", "Save", () -> ItemShaders.config().save()));
        public final ActionSetting load = add(new ActionSetting("Load Config",
                "Reloads settings from disk", "Load", () -> ItemShaders.config().load()));

        private Config() {
            super("Config", "Saving and loading");
        }
    }
}
