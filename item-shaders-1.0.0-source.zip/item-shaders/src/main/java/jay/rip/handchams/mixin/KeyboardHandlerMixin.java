package jay.rip.handchams.mixin;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.ui.MenuScreen;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.AbstractSignEditScreen;
import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import net.minecraft.client.gui.screens.options.controls.KeyBindsScreen;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin {
    @Shadow
    @Final
    private Minecraft minecraft;

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void itemshaders$onKeyPress(long window, int action, KeyEvent event, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) {
            return;
        }
        Screen screen = minecraft.screen;
        if (screen == null) {
            if (ItemShaders.onKeyPressed(event.key())) {
                ci.cancel();
            }
        } else if (canOpenMenuOver(screen) && ItemShaders.onKeyPressedInScreen(event.key())) {
            ci.cancel();
        }
    }

    private static boolean canOpenMenuOver(Screen screen) {
        if (screen instanceof MenuScreen || screen instanceof ChatScreen || screen instanceof AbstractSignEditScreen
                || screen instanceof BookEditScreen || screen instanceof KeyBindsScreen
                || screen instanceof AbstractContainerScreen<?>) {
            return false;
        }
        return !(screen.getFocused() instanceof EditBox box && box.isFocused());
    }
}
