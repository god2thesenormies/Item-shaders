package jay.rip.handchams.ui;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.module.Category;
import jay.rip.handchams.module.Module;
import jay.rip.handchams.setting.SettingGroup;
import jay.rip.handchams.ui.component.ContentPanel;
import jay.rip.handchams.ui.component.SearchField;
import jay.rip.handchams.ui.component.Sidebar;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Label;
import jay.rip.handchams.ui.framework.Popup;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;
import net.minecraft.client.gui.GuiGraphics;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class Menu {
    public static final float WIDTH = 1061f;
    public static final float HEIGHT = 689f;

    private static final float BASE_SCALE = 0.82f;

    private static final float MARGIN = 12f;
    private static final float CONTENT_X = Sidebar.WIDTH + MARGIN * 2f;
    private static final float TOP_BAR_HEIGHT = 82f;
    private static final float SEARCH_WIDTH = 202f;
    private static final float SEARCH_HEIGHT = 43f;

    private final Ui ui = new Ui();
    private final Sidebar sidebar = new Sidebar(this);
    private final SearchField search = new SearchField();
    private final ContentPanel content = new ContentPanel();
    private final Spring openX = new Spring(0f, 14f, 0.4f);
    private final Spring openY = new Spring(0f, 11f, 0.36f);
    private final Approach fade = new Approach(0f);
    private final Spring titleSwap = new Spring(1f, 16f, 1f);
    private Tab tab = Tab.VISUALS;
    private float x;
    private float y;
    private float offsetX;
    private float offsetY;
    private boolean dragging;
    private float dragOffsetX;
    private float dragOffsetY;
    private boolean closing;
    private float scale = BASE_SCALE;

    private final Map<Category, String> activeSubtab = new EnumMap<>(Category.class);
    private final Spring subtabLeft = new Spring(0f, 19f, 0.6f);
    private final Spring subtabRight = new Spring(0f, 19f, 0.6f);
    private final Jelly subtabSelectionJelly = new Jelly();
    private final Map<String, Spring> subtabGhosts = new HashMap<>();
    private final Map<String, Approach> subtabActive = new HashMap<>();
    private final Map<String, Jelly> subtabJellies = new HashMap<>();
    private boolean subtabSelectionPlaced;
    private float tabsTime;

    public Ui ui() {
        return ui;
    }

    public Tab tab() {
        return tab;
    }

    public void selectTab(Tab tab) {
        if (this.tab == tab) {
            return;
        }
        this.tab = tab;
        search.clear();
        ui.closePopup();
        titleSwap.snap(0f);
        subtabSelectionPlaced = false;
        tabsTime = 0f;
    }

    public float scale() {
        return scale;
    }

    public void open() {
        closing = false;
        openX.snap(0f);
        openY.snap(0f);
        fade.snap(0f);
        ui.restartPage();
        tabsTime = 0f;
        sidebar.replayIntro();
    }

    public void close() {
        closing = true;
        dragging = false;
        ui.closePopup();
        ui.clearFocus();
    }

    public boolean isClosed() {
        return closing && fade.value() < 0.02f;
    }

    public float openProgress() {
        return Math.clamp(fade.value(), 0f, 1f);
    }

    public void render(GuiGraphics graphics, float viewWidth, float viewHeight) {
        MenuSettings.General general = ItemShaders.menuSettings().general;
        ui.beginFrame(graphics, viewWidth, viewHeight, general.animationSpeed.floatValue());
        Renderer renderer = ui.renderer();
        Input input = ui.input();

        if (!input.isDown(Input.LEFT)) {
            scale = general.scale.floatValue() * BASE_SCALE;
        }

        Popup popup = ui.popup();
        if (popup != null && !popup.contains(input.mouseX(), input.mouseY())
                && (input.wasPressed(Input.LEFT) || input.wasPressed(Input.RIGHT))) {
            ui.closePopup();
            input.takeClick();
        }
        input.setBlocked(closing || ui.popup() != null);

        handleDragging(input, viewWidth, viewHeight);
        renderWindow(renderer);

        input.setBlocked(closing);
        if (ui.popup() != null) {
            renderer.nextLayer();
            renderer.pushOpacity(openProgress());
            ui.popup().render(ui);
            renderer.popOpacity();
        }
        if (ui.tooltipText() != null) {
            renderer.nextLayer();
            renderTooltip(renderer, viewWidth, viewHeight);
        }
        input.setBlocked(false);
        input.endFrame();
    }

    private void handleDragging(Input input, float viewWidth, float viewHeight) {
        float centerX = (viewWidth - WIDTH) * 0.5f;
        float centerY = (viewHeight - HEIGHT) * 0.5f;
        x = centerX + offsetX;
        y = centerY + offsetY;

        if (input.clicked(x + MARGIN, y + MARGIN, Sidebar.WIDTH, Sidebar.LOGO_HEIGHT)) {
            dragging = true;
            dragOffsetX = input.mouseX() - x;
            dragOffsetY = input.mouseY() - y;
        }
        if (dragging) {
            x = input.mouseX() - dragOffsetX;
            y = input.mouseY() - dragOffsetY;
            dragging = input.isDown(Input.LEFT);
        }
        x = Math.clamp(x, Math.min(0f, viewWidth - WIDTH), Math.max(0f, viewWidth - WIDTH));
        y = Math.clamp(y, Math.min(0f, viewHeight - HEIGHT), Math.max(0f, viewHeight - HEIGHT));
        offsetX = x - centerX;
        offsetY = y - centerY;
    }

    private void renderWindow(Renderer renderer) {
        float delta = ui.delta();
        tabsTime += delta;

        float target = closing ? 0f : 1f;
        float sx = openX.update(target, delta, closing ? 20f : 14f, closing ? 1f : 0.4f);
        float sy = openY.update(target, delta, closing ? 20f : 11f, closing ? 1f : 0.36f);
        fade.update(target, delta * (closing ? 16f / 14f : 12f / 14f));
        float scaleX = 0.86f + 0.14f * sx;
        float scaleY = 0.86f + 0.14f * sy;

        renderer.push();
        if (Math.abs(scaleX - 1f) > 1e-4f || Math.abs(scaleY - 1f) > 1e-4f) {
            renderer.scaleAround(x + WIDTH * 0.5f, y + HEIGHT * 0.45f, scaleX, scaleY);
        }
        renderer.pushOpacity(openProgress());

        renderFrame(renderer);
        sidebar.render(ui, x + MARGIN, y + MARGIN, HEIGHT - MARGIN * 2f);

        float mainX = x + CONTENT_X;
        float mainWidth = WIDTH - CONTENT_X - MARGIN - 2f;
        renderTopBar(renderer, mainX, y + MARGIN, mainWidth);

        String query = search.text().trim().toLowerCase(Locale.ROOT);
        Object page = query.isEmpty() ? tab + "/" + activeSubtab.get(tab.category()) : "search:" + query;
        float contentY = y + MARGIN + TOP_BAR_HEIGHT + MARGIN + 2f;
        content.render(ui, page, groups(query), mainX, contentY, mainWidth, y + HEIGHT - MARGIN - contentY);

        renderer.popOpacity();
        renderer.pop();
    }

    private void renderFrame(Renderer renderer) {
        float radius = Theme.radius();
        Theme.shadow(renderer, x, y, WIDTH, HEIGHT, radius, 6);

        renderer.shadow(x, y, WIDTH, HEIGHT, radius, 14f, Colors.fade(Theme.accent(), 0.18f));
        renderer.roundedRectBorder(x, y, WIDTH, HEIGHT, radius, Theme.WINDOW, Colors.fade(Theme.accent(), 0.6f));

        float travel = ((ui.time() * 0.16f) % 1.5f - 0.25f) * WIDTH;
        float glowX = x + travel;
        int glow = Colors.rgba(255, 235, 245, 150);
        int clear = Colors.withAlpha(glow, 0);
        renderer.pushClip(x + radius, y, WIDTH - radius * 2f, 2f);
        renderer.gradientHorizontal(glowX - 140f, y, 140f, 2f, clear, glow);
        renderer.gradientHorizontal(glowX, y, 140f, 2f, glow, clear);
        renderer.popClip();
    }

    private void renderTopBar(Renderer renderer, float barX, float barY, float barWidth) {
        Theme.panel(renderer, barX, barY, barWidth, TOP_BAR_HEIGHT);

        float swap = titleSwap.update(1f, ui.delta());
        boolean searching = !search.text().isBlank();
        String title = searching ? "Search" : tab.title();
        renderer.pushOpacity(Math.clamp(swap * 1.4f, 0f, 1f));
        float titleY = barY + 31f + (1f - swap) * 6f;
        renderer.text(TextFont.BOLD, title, barX + 22f, titleY, 23f, Theme.TEXT);
        renderer.text(TextFont.REGULAR, subtitle(searching), barX + 23f, titleY + 25f, 16f, Theme.TEXT_DIM);
        renderer.popOpacity();

        if (!searching && tab.category() != null) {
            List<String> subs = ItemShaders.modules().subcategories(tab.category());
            if (!subs.isEmpty()) {
                float titleEnd = barX + 22f + Math.max(renderer.textWidth(TextFont.BOLD, title, 23f),
                        renderer.textWidth(TextFont.REGULAR, subtitle(false), 16f));
                renderSubtabPills(renderer, subs, barX, barY, barWidth, titleEnd);
            }
        }

        search.render(ui, barX + barWidth - 17f - SEARCH_WIDTH, barY + (TOP_BAR_HEIGHT - SEARCH_HEIGHT) * 0.5f, SEARCH_WIDTH, SEARCH_HEIGHT);
    }

    private void renderSubtabPills(Renderer renderer, List<String> subcategories, float barX, float barY, float barWidth, float titleEnd) {
        Input input = ui.input();
        float delta = ui.delta();
        Category cat = tab.category();
        String active = activeSubtab.get(cat);

        String generalLabel = "General";
        int pillCount = 1 + subcategories.size();

        float pillHeight = 30f;
        float pillPadding = 14f;
        float pillGap = 6f;
        float pillSize = 14.5f;
        float pillRadius = pillHeight * 0.5f;
        float pillY = barY + (TOP_BAR_HEIGHT - pillHeight) * 0.5f;

        float areaLeft = titleEnd + 28f;
        float areaRight = barX + barWidth - 17f - SEARCH_WIDTH - 22f;
        float availableWidth = Math.max(areaRight - areaLeft, 0f);

        String[] labels = new String[pillCount];
        labels[0] = generalLabel;
        for (int i = 0; i < subcategories.size(); i++) {
            labels[i + 1] = subcategories.get(i);
        }
        float[] pillWidths = new float[pillCount];
        float totalPillsWidth = measurePills(renderer, labels, pillWidths, pillSize, pillPadding, pillGap);

        if (totalPillsWidth > availableWidth) {
            pillPadding = 9f;
            pillGap = 4f;
            totalPillsWidth = measurePills(renderer, labels, pillWidths, pillSize, pillPadding, pillGap);
        }
        if (totalPillsWidth > availableWidth) {
            pillSize = Math.max(11.5f, pillSize * availableWidth / totalPillsWidth);
            totalPillsWidth = measurePills(renderer, labels, pillWidths, pillSize, pillPadding, pillGap);
        }

        float pillStartX = areaLeft + Math.max(availableWidth - totalPillsWidth, 0f) * 0.5f;
        float cursor = pillStartX;

        float selectionTarget = 0f;
        float selectionWidth = pillWidths[0];
        for (int i = 0; i < pillCount; i++) {
            String subKey = i == 0 ? null : labels[i];
            if (java.util.Objects.equals(subKey, active)) {
                selectionTarget = cursor;
                selectionWidth = pillWidths[i];
                break;
            }
            cursor += pillWidths[i] + pillGap;
        }

        float selectionLeft = selectionTarget - pillStartX;
        float selectionRight = selectionLeft + selectionWidth;
        if (!subtabSelectionPlaced) {
            subtabLeft.snap(selectionLeft);
            subtabRight.snap(selectionRight);
            subtabSelectionPlaced = true;
        }
        boolean movingRight = selectionLeft > subtabLeft.value() + 0.5f;
        float left = subtabLeft.update(selectionLeft, delta, movingRight ? 11f : 19f, 0.6f);
        float right = subtabRight.update(selectionRight, delta, movingRight ? 19f : 11f, 0.6f);
        right = Math.max(right, left + 30f);

        boolean heldActive = false;
        cursor = pillStartX;
        for (int i = 0; i < pillCount; i++) {
            String subKey = i == 0 ? null : labels[i];
            if (java.util.Objects.equals(subKey, active) && input.held(cursor, pillY, pillWidths[i], pillHeight)) {
                heldActive = true;
            }
            cursor += pillWidths[i] + pillGap;
        }
        subtabSelectionJelly.update(heldActive, false, 0.9f, delta);
        float selectionCenter = pillStartX + (left + right) * 0.5f;
        subtabSelectionJelly.push(renderer, selectionCenter, pillY + pillHeight * 0.5f);
        renderer.roundedRect(pillStartX + left, pillY, right - left, pillHeight, pillRadius,
                Colors.mix(Theme.PILL, Theme.accent(), 0.20f));
        renderer.pop();

        cursor = pillStartX;
        for (int i = 0; i < pillCount; i++) {
            String subKey = i == 0 ? null : labels[i];
            boolean selected = java.util.Objects.equals(subKey, active);
            float pillX = cursor;
            float pillWidth = pillWidths[i];
            boolean hovered = input.hovering(pillX, pillY, pillWidth, pillHeight);
            boolean held = input.held(pillX, pillY, pillWidth, pillHeight);

            if (input.clicked(pillX, pillY, pillWidth, pillHeight) && !selected) {
                activeSubtab.put(cat, subKey);
            }

            String key = labels[i];
            float ghost = subtabGhosts.computeIfAbsent(key, k -> new Spring(0f, 16f, 0.55f))
                    .update(hovered && !selected ? 1f : 0f, delta);
            float activeAmount = subtabActive.computeIfAbsent(key, k -> new Approach(0f)).update(selected ? 1f : 0f, delta);
            Jelly jelly = subtabJellies.computeIfAbsent(key, k -> new Jelly());
            jelly.update(held, hovered, 1f, delta);

            float centerX = pillX + pillWidth * 0.5f;
            float centerY = pillY + pillHeight * 0.5f;
            if (ghost > 0.01f) {
                jelly.push(renderer, centerX, centerY, 0.85f + 0.15f * ghost);
                renderer.roundedRect(pillX, pillY, pillWidth, pillHeight, pillRadius,
                        Colors.fade(Theme.PILL_HOVER, Math.clamp(ghost, 0f, 1f)));
                renderer.pop();
            }

            float labelTime = tabsTime - i * 0.06f;
            float labelAlpha = Math.clamp(labelTime / 0.22f, 0f, 1f);
            float labelDrop = (1f - Easing.outBack(labelTime / 0.45f)) * 10f;
            int textColor = Colors.mix(Colors.mix(Theme.NAV_TEXT, Theme.TEXT_BRIGHT, Math.clamp(ghost, 0f, 1f)),
                    Theme.accentText(), activeAmount);
            jelly.push(renderer, centerX, centerY);
            renderer.textCentered(TextFont.SEMIBOLD, labels[i], centerX, centerY + labelDrop, pillSize,
                    Colors.fade(textColor, labelAlpha));
            renderer.pop();
            cursor += pillWidth + pillGap;
        }
    }

    private static float measurePills(Renderer renderer, String[] labels, float[] widths, float size, float padding, float gap) {
        float total = 0f;
        for (int i = 0; i < labels.length; i++) {
            widths[i] = renderer.textWidth(TextFont.SEMIBOLD, labels[i], size) + padding * 2f;
            total += widths[i] + (i > 0 ? gap : 0f);
        }
        return total;
    }

    private String subtitle(boolean searching) {
        if (searching) {
            int results = groups(search.text().trim().toLowerCase(Locale.ROOT)).size();
            return results == 1 ? "1 module found" : results + " modules found";
        }
        if (tab.category() == null) {
            return "Menu preferences and config";
        }

        List<? extends SettingGroup> shown = groups("");
        long enabled = shown.stream()
                .filter(g -> g instanceof Module m && m.isEnabled())
                .count();
        String count = shown.size() == 1 ? "1 module" : shown.size() + " modules";
        return count + ", " + enabled + " enabled";
    }

    private List<? extends SettingGroup> groups(String query) {
        if (!query.isEmpty()) {
            return ItemShaders.modules().all().stream()
                    .filter(module -> module.name().containsLower(query)
                            || module.description().containsLower(query))
                    .toList();
        }
        if (tab.category() == null) {
            return ItemShaders.menuSettings().groups();
        }

        Category cat = tab.category();
        List<String> subs = ItemShaders.modules().subcategories(cat);
        if (!subs.isEmpty()) {
            String active = activeSubtab.get(cat);
            return ItemShaders.modules().inSubcategory(cat, active);
        }
        return ItemShaders.modules().inCategory(cat);
    }

    private void renderTooltip(Renderer renderer, float viewWidth, float viewHeight) {
        Label text = ui.tooltipText();
        float size = 15f;
        float width = renderer.textWidth(TextFont.REGULAR, text, size) + 22f;
        float height = 30f;
        float tooltipX = Math.min(ui.tooltipX() + 14f, viewWidth - width - 4f);
        float tooltipY = Math.min(ui.tooltipY() + 16f, viewHeight - height - 4f);

        renderer.roundedRect(tooltipX - 1f, tooltipY - 1f, width + 2f, height + 2f, height * 0.5f + 1f, Theme.POPUP_BORDER);
        renderer.roundedRect(tooltipX, tooltipY, width, height, height * 0.5f, Theme.POPUP);
        renderer.text(TextFont.REGULAR, text, tooltipX + 11f, tooltipY + height * 0.5f, size, Theme.TEXT, Float.MAX_VALUE);
    }
}
