package jay.rip.handchams.ui.framework;

public interface Popup {
    boolean contains(float x, float y);

    void render(Ui ui);
}
