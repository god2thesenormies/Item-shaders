package jay.rip.handchams.ui.framework;

import com.mojang.blaze3d.platform.NativeImage;
import jay.rip.handchams.compat.Masks;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

final class ShapeMasks {
    record Mask(String texture, int size, int corner) {
    }

    @FunctionalInterface
    private interface Coverage {
        float at(int x, int y);
    }

    private static final int MAX_MASKS = 256;
    private static final Map<Long, Mask> MASKS = new HashMap<>();

    private ShapeMasks() {
    }

    static Mask corner(float radius) {
        int r = Math.max(Math.round(radius), 1);
        long key = (long) r;
        return cached(key, () -> create("corner_" + r, r, (x, y) -> {
            float dx = r - (x + 0.5f);
            float dy = r - (y + 0.5f);
            if (dx <= 0f || dy <= 0f) {
                return 1f;
            }
            return Math.clamp(r + 0.5f - (float) Math.sqrt(dx * dx + dy * dy), 0f, 1f);
        }));
    }

    static Mask shadow(float radius, float blur) {
        int r = Math.max(Math.round(radius), 1);
        int b = Math.max(Math.round(blur), 2);
        long key = 1L << 40 | (long) r << 20 | b;
        return cached(key, () -> {
            int pad = shadowPadding(b);
            int corner = (int) Math.ceil(pad + r + b * 0.5f);
            return create("shadow_" + r + "_" + b, corner, (x, y) -> {
                float qx = r - (x + 0.5f - pad);
                float qy = r - (y + 0.5f - pad);
                float outsideX = Math.max(qx, 0f);
                float outsideY = Math.max(qy, 0f);
                float distance = (float) Math.sqrt(outsideX * outsideX + outsideY * outsideY) + Math.min(Math.max(qx, qy), 0f) - r;
                float t = Math.clamp(0.5f - distance / b, 0f, 1f);
                return t * t * (3f - 2f * t);
            });
        });
    }

    static int shadowPadding(float blur) {
        return (int) Math.ceil(blur * 0.5f);
    }

    private static Mask cached(long key, Supplier<Mask> factory) {
        Mask mask = MASKS.get(key);
        if (mask == null) {
            if (MASKS.size() >= MAX_MASKS) {
                clear();
            }
            mask = factory.get();
            MASKS.put(key, mask);
        }
        return mask;
    }

    private static Mask create(String name, int corner, Coverage coverage) {
        int size = corner * 2;
        NativeImage image = new NativeImage(size, size, false);
        for (int y = 0; y < size; y++) {
            int localY = y < corner ? y : size - 1 - y;
            for (int x = 0; x < size; x++) {
                int localX = x < corner ? x : size - 1 - x;
                int alpha = Math.round(Math.clamp(coverage.at(localX, localY), 0f, 1f) * 255f);
                image.setPixel(x, y, alpha << 24 | 0x00FFFFFF);
            }
        }
        String texture = "mask/" + name;
        Masks.register(texture, "Item Shaders mask " + name, image);
        return new Mask(texture, size, corner);
    }

    static void clear() {
        for (Mask mask : MASKS.values()) {
            Masks.release(mask.texture());
        }
        MASKS.clear();
    }
}
