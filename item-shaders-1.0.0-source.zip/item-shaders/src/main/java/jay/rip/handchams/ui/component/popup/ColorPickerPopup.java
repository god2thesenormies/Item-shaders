package jay.rip.handchams.ui.component.popup;

import jay.rip.handchams.setting.ColorSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Popup;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class ColorPickerPopup implements Popup {
    private static final float PADDING = 12f;
    private static final float AREA_WIDTH = 190f;
    private static final float AREA_HEIGHT = 140f;
    private static final float BAR = 15f;
    private static final float GAP = 10f;
    private static final float FOOTER = 26f;
    private static final int[] HUES = {
            0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000
    };

    private enum Drag { NONE, AREA, HUE, ALPHA }

    private final ColorSetting setting;
    private final Spring reveal = new Spring(0f, 18f, 1f);
    private Drag drag = Drag.NONE;
    private float x;
    private float y;
    private float hue;
    private float saturation;
    private float value;
    private int alpha;

    public ColorPickerPopup(ColorSetting setting) {
        this.setting = setting;
    }

    public void open(Ui ui, float right, float top) {
        x = Math.clamp(right - width(), 8f, ui.viewWidth() - width() - 8f);
        y = top + height() > ui.viewHeight() - 8f ? top - height() - 36f : top;

        float[] hsv = Colors.toHsv(setting.get());
        hue = hsv[0];
        saturation = hsv[1];
        value = hsv[2];
        alpha = Colors.alpha(setting.get());
        drag = Drag.NONE;
        reveal.snap(0f);
        ui.openPopup(this);
    }

    private float width() {
        return PADDING * 2f + AREA_WIDTH + GAP + BAR;
    }

    private float height() {
        float alphaBar = setting.allowsAlpha() ? GAP + BAR : 0f;
        return PADDING * 2f + AREA_HEIGHT + alphaBar + GAP + FOOTER;
    }

    @Override
    public boolean contains(float px, float py) {
        return px >= x && px < x + width() && py >= y && py < y + height();
    }

    @Override
    public void render(Ui ui) {
        Renderer renderer = ui.renderer();
        float progress = reveal.update(1f, ui.delta());
        float scale = 0.9f + 0.1f * progress;

        renderer.push();
        renderer.scaleAround(x + width(), y, scale, scale);
        renderer.pushOpacity(Math.clamp(progress * 2.5f, 0f, 1f));

        Theme.shadow(renderer, x, y, width(), height(), 16f, 3);
        renderer.roundedRect(x - 1f, y - 1f, width() + 2f, height() + 2f, 17f, Theme.POPUP_BORDER);
        renderer.roundedRect(x, y, width(), height(), 16f, Theme.POPUP);

        float areaX = x + PADDING;
        float areaY = y + PADDING;
        float hueX = areaX + AREA_WIDTH + GAP;
        float alphaY = areaY + AREA_HEIGHT + GAP;
        float alphaWidth = AREA_WIDTH + GAP + BAR;

        handleInput(ui.input(), areaX, areaY, hueX, alphaY, alphaWidth);

        drawArea(renderer, areaX, areaY);
        drawHueBar(renderer, hueX, areaY);
        if (setting.allowsAlpha()) {
            drawAlphaBar(renderer, areaX, alphaY, alphaWidth);
        }

        float footerY = y + height() - PADDING - FOOTER * 0.5f;
        checkerboard(renderer, areaX, footerY - 10f, 20f, 20f, 10f);
        renderer.roundedRect(areaX, footerY - 10f, 20f, 20f, 10f, setting.get());
        renderer.text(TextFont.SEMIBOLD, setting.hex(), areaX + 30f, footerY, 16f, Theme.CONTROL_TEXT);

        renderer.popOpacity();
        renderer.pop();
    }

    private void handleInput(Input input, float areaX, float areaY, float hueX, float alphaY, float alphaWidth) {
        if (input.clicked(areaX, areaY, AREA_WIDTH, AREA_HEIGHT)) {
            drag = Drag.AREA;
        } else if (input.clicked(hueX, areaY, BAR, AREA_HEIGHT)) {
            drag = Drag.HUE;
        } else if (setting.allowsAlpha() && input.clicked(areaX, alphaY, alphaWidth, BAR)) {
            drag = Drag.ALPHA;
        }

        switch (drag) {
            case AREA -> {
                saturation = Math.clamp((input.mouseX() - areaX) / AREA_WIDTH, 0f, 1f);
                value = 1f - Math.clamp((input.mouseY() - areaY) / AREA_HEIGHT, 0f, 1f);
            }
            case HUE -> hue = Math.clamp((input.mouseY() - areaY) / AREA_HEIGHT, 0f, 0.999f);
            case ALPHA -> alpha = Math.round(Math.clamp((input.mouseX() - areaX) / alphaWidth, 0f, 1f) * 255f);
            case NONE -> {
                return;
            }
        }
        setting.set(Colors.fromHsv(hue, saturation, value, alpha));
        if (!input.isDown(Input.LEFT)) {
            drag = Drag.NONE;
        }
    }

    private void drawArea(Renderer renderer, float areaX, float areaY) {
        renderer.gradientHorizontal(areaX, areaY, AREA_WIDTH, AREA_HEIGHT, 0xFFFFFFFF, Colors.fromHsv(hue, 1f, 1f, 255));
        renderer.gradientVertical(areaX, areaY, AREA_WIDTH, AREA_HEIGHT, 0x00000000, 0xFF000000);

        float markerX = areaX + saturation * AREA_WIDTH;
        float markerY = areaY + (1f - value) * AREA_HEIGHT;
        renderer.circle(markerX, markerY, 5.5f, Theme.KNOB);
        renderer.circle(markerX, markerY, 4f, Colors.fromHsv(hue, saturation, value, 255));
    }

    private void drawHueBar(Renderer renderer, float barX, float barY) {
        float segment = AREA_HEIGHT / (HUES.length - 1);
        for (int i = 0; i < HUES.length - 1; i++) {
            renderer.gradientVertical(barX, barY + segment * i, BAR, segment, HUES[i], HUES[i + 1]);
        }
        float markerY = barY + hue * AREA_HEIGHT;
        renderer.roundedRect(barX - 2f, markerY - 3f, BAR + 4f, 6f, 3f, Theme.KNOB);
        renderer.rect(barX, markerY - 1f, BAR, 2f, Colors.fromHsv(hue, 1f, 1f, 255));
    }

    private void drawAlphaBar(Renderer renderer, float barX, float barY, float barWidth) {
        checkerboard(renderer, barX, barY, barWidth, BAR);
        int opaque = Colors.fromHsv(hue, saturation, value, 255);
        renderer.gradientHorizontal(barX, barY, barWidth, BAR, Colors.withAlpha(opaque, 0), opaque);

        float markerX = barX + alpha / 255f * barWidth;
        renderer.roundedRect(markerX - 3f, barY - 2f, 6f, BAR + 4f, 3f, Theme.KNOB);
    }

    public static void checkerboard(Renderer renderer, float x, float y, float width, float height) {
        checkerboard(renderer, x, y, width, height, 5f);
    }

    public static void checkerboard(Renderer renderer, float x, float y, float width, float height, float radius) {
        float cell = 4f;
        int columns = (int) Math.ceil(width / cell);
        int rows = (int) Math.ceil(height / cell);
        renderer.roundedRect(x, y, width, height, radius, CHECK_DARK);
        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                if ((row + column) % 2 == 0) {
                    continue;
                }
                float cellX = column * cell;
                float cellY = row * cell;
                float cellWidth = Math.min(cell, width - cellX);
                float cellHeight = Math.min(cell, height - cellY);
                if (!insideRounded(cellX, cellY, width, height, radius) || !insideRounded(cellX + cellWidth, cellY, width, height, radius)
                        || !insideRounded(cellX, cellY + cellHeight, width, height, radius)
                        || !insideRounded(cellX + cellWidth, cellY + cellHeight, width, height, radius)) {
                    continue;
                }
                renderer.rect(x + cellX, y + cellY, cellWidth, cellHeight, CHECK_LIGHT);
            }
        }
    }

    private static final int CHECK_DARK = 0xFF4A4C5C;
    private static final int CHECK_LIGHT = 0xFF6E7082;

    private static boolean insideRounded(float px, float py, float width, float height, float radius) {
        float qx = Math.abs(px - width * 0.5f) - (width * 0.5f - radius);
        float qy = Math.abs(py - height * 0.5f) - (height * 0.5f - radius);
        float outsideX = Math.max(qx, 0f);
        float outsideY = Math.max(qy, 0f);
        return outsideX * outsideX + outsideY * outsideY <= radius * radius + 0.01f;
    }
}
