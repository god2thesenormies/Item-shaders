package jay.rip.handchams.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.module.Module;
import jay.rip.handchams.setting.SettingGroup;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve(ItemShaders.MOD_ID + ".json");

    public void save() {
        JsonObject modules = new JsonObject();
        for (Module module : ItemShaders.modules().all()) {
            modules.add(module.configKey(), module.toJson());
        }
        JsonObject menu = new JsonObject();
        for (SettingGroup group : ItemShaders.menuSettings().groups()) {
            menu.add(group.configKey(), group.toJson());
        }

        JsonObject root = new JsonObject();
        root.add("m", modules);
        root.add("u", menu);

        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
        } catch (IOException | RuntimeException e) {
            ItemShaders.LOGGER.error("Couldn't save config to {}", file, e);
        }
    }

    public void load() {
        if (!Files.exists(file)) {
            return;
        }
        JsonObject root;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            root = JsonParser.parseReader(reader).getAsJsonObject();
        } catch (IOException | RuntimeException e) {
            ItemShaders.LOGGER.error("Couldn't read config from {}", file, e);
            return;
        }

        JsonObject modules = section(root, "m");
        if (modules.size() == 0) modules = section(root, "modules");
        for (Module module : ItemShaders.modules().all()) {
            JsonElement json = modules.get(module.configKey());
            if (json != null && json.isJsonObject()) {
                module.fromJson(json.getAsJsonObject());
            }
        }
        JsonObject menu = section(root, "u");
        if (menu.size() == 0) menu = section(root, "menu");
        for (SettingGroup group : ItemShaders.menuSettings().groups()) {
            JsonElement json = menu.get(group.configKey());
            if (json != null && json.isJsonObject()) {
                group.fromJson(json.getAsJsonObject());
            }
        }
    }

    private static JsonObject section(JsonObject root, String name) {
        JsonElement element = root.get(name);
        return element != null && element.isJsonObject() ? element.getAsJsonObject() : new JsonObject();
    }
}
