package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.KeybindSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;
import org.lwjgl.glfw.GLFW;

public final class KeybindRow extends SettingRow<KeybindSetting> {
    private static final float PILL_HEIGHT = 31f;
    private static final float TEXT_SIZE = 18f;

    private final Spring width = new Spring(60f, 15f, 0.45f);
    private final Approach hover = new Approach(0f);
    private final Spring pop = new Spring(1f, 16f, 0.32f);
    private final Jelly jelly = new Jelly();

    public KeybindRow(KeybindSetting setting) {
        super(setting);
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();

        boolean listening = ui.hasFocus(this);
        String text = setting.keyName();
        float targetWidth = listening ? 62f : Math.max(renderer.textWidth(TextFont.SEMIBOLD, text, TEXT_SIZE) + 24f, 50f);
        float pillWidth = width.update(targetWidth, delta);
        float pillX = right - pillWidth;
        float pillY = centerY - PILL_HEIGHT * 0.5f;

        boolean pillHovered = input.hovering(pillX, pillY, pillWidth, PILL_HEIGHT);
        if (input.clicked(pillX, pillY, pillWidth, PILL_HEIGHT)) {
            listening = !listening;
            if (listening) {
                ui.focus(this);
            } else {
                ui.unfocus(this);
            }
            pop.snap(0.6f);
        } else if (listening) {
            listening = listen(ui, pillHovered);
        }

        float hoverAmount = hover.update(pillHovered || listening ? 1f : 0f, delta);
        float scale = pop.update(1f, delta);
        jelly.update(input.held(pillX, pillY, pillWidth, PILL_HEIGHT), pillHovered, 0.8f, delta);
        float centerX = pillX + pillWidth * 0.5f;
        jelly.push(renderer, centerX, centerY);
        renderer.roundedRect(pillX, pillY, pillWidth, PILL_HEIGHT, PILL_HEIGHT * 0.5f, Colors.mix(Theme.CONTROL, Theme.CONTROL_HOVER, hoverAmount));
        if (listening) {
            float breathe = 0.45f + 0.3f * (float) Math.sin(ui.time() * 5f);
            renderer.roundedRect(pillX - 1.5f, pillY - 1.5f, pillWidth + 3f, PILL_HEIGHT + 3f, PILL_HEIGHT * 0.5f + 1.5f, Colors.fade(Theme.accent(), breathe));
            renderer.roundedRect(pillX, pillY, pillWidth, PILL_HEIGHT, PILL_HEIGHT * 0.5f, Theme.CONTROL_HOVER);
            for (int i = 0; i < 3; i++) {
                float hop = Math.max(0f, (float) Math.sin(ui.time() * 7f - i * 0.8f)) * 4.5f;
                renderer.circle(centerX + (i - 1) * 9f, centerY + 1.5f - hop, 2.6f, Theme.accent());
            }
        } else {
            int color = setting.isBound() ? Theme.CONTROL_TEXT : Theme.TEXT_DIM;
            renderer.push();
            renderer.scaleAround(centerX, centerY, scale, scale);
            renderer.textCentered(TextFont.SEMIBOLD, text, centerX, centerY, TEXT_SIZE, color);
            renderer.pop();
        }
        renderer.pop();
        return pillX;
    }

    private boolean listen(Ui ui, boolean pillHovered) {
        Input input = ui.input();
        if (!input.keys().isEmpty()) {
            int key = input.keys().getFirst();
            boolean clear = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE;
            setting.set(clear ? KeybindSetting.NONE : key);
            stopListening(ui);
            return false;
        }

        for (int button = Input.RIGHT; button < 8; button++) {
            if (input.wasPressed(button)) {
                input.takeClick();
                setting.set(KeybindSetting.mouse(button));
                stopListening(ui);
                return false;
            }
        }
        if (input.wasReleased(Input.LEFT) && !pillHovered) {
            stopListening(ui);
            return false;
        }
        return true;
    }

    private void stopListening(Ui ui) {
        ui.unfocus(this);
        pop.snap(0.6f);
    }
}
