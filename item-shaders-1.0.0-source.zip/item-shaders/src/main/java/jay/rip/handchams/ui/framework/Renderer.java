package jay.rip.handchams.ui.framework;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import jay.rip.handchams.compat.Masks;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import org.joml.Matrix3x2fStack;

import java.util.ArrayDeque;
import java.util.Deque;

public final class Renderer {
    private final Deque<Float> opacityStack = new ArrayDeque<>();
    private int floating;
    private GuiGraphics graphics;
    private float opacity = 1f;

    public void begin(GuiGraphics graphics) {
        this.graphics = graphics;
        this.opacity = 1f;
        this.opacityStack.clear();
    }

    public GuiGraphics graphics() {
        return graphics;
    }

    private Font font() {
        return Minecraft.getInstance().font;
    }

    public void push() {
        pose().pushMatrix();
    }

    public void pop() {
        pose().popMatrix();
    }

    public void translate(float x, float y) {
        pose().translate(x, y);
    }

    public void scale(float x, float y) {
        pose().scale(x, y);
    }

    public void scaleAround(float centerX, float centerY, float scaleX, float scaleY) {
        pose().translate(centerX, centerY);
        pose().scale(scaleX, scaleY);
        pose().translate(-centerX, -centerY);
    }

    public void rotateAround(float centerX, float centerY, float radians) {
        pose().translate(centerX, centerY);
        pose().rotate(radians);
        pose().translate(-centerX, -centerY);
    }

    private Matrix3x2fStack pose() {
        return graphics.pose();
    }

    public void pushOpacity(float factor) {
        opacityStack.push(opacity);
        opacity *= Math.clamp(factor, 0f, 1f);
    }

    public void popOpacity() {
        opacity = opacityStack.pop();
    }

    public float opacity() {
        return opacity;
    }

    public void pushFloating() {
        floating++;
    }

    public void popFloating() {
        floating--;
    }

    private int apply(int color) {
        return opacity >= 1f ? color : Colors.fade(color, opacity);
    }

    public void pushClip(float x, float y, float width, float height) {
        graphics.enableScissor((int) Math.floor(x), (int) Math.floor(y), (int) Math.ceil(x + width), (int) Math.ceil(y + height));
    }

    public void popClip() {
        graphics.disableScissor();
    }

    public void nextLayer() {
        graphics.nextStratum();
    }

    public void rect(float x, float y, float width, float height, int color) {
        color = apply(color);
        if (Colors.alpha(color) == 0) {
            return;
        }
        if (!axisAligned()) {
            graphics.fill(Math.round(x), Math.round(y), Math.round(x + width), Math.round(y + height), color);
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int x1 = Math.max(deviceX(x + width), width > 0f ? x0 + 1 : x0);
        int y1 = Math.max(deviceY(y + height), height > 0f ? y0 + 1 : y0);
        enterDeviceSpace();
        graphics.fill(x0, y0, x1, y1, color);
        pop();
    }

    public void roundedRect(float x, float y, float width, float height, float radius, int color) {
        color = apply(color);
        if (Colors.alpha(color) == 0 || width <= 0f || height <= 0f) {
            return;
        }
        if (!axisAligned()) {
            int x0 = Math.round(x);
            int y0 = Math.round(y);
            drawRounded(x0, y0, Math.round(x + width) - x0, Math.round(y + height) - y0, radius, color);
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int x1 = Math.max(deviceX(x + width), x0 + 1);
        int y1 = Math.max(deviceY(y + height), y0 + 1);
        float deviceRadius = radius * Math.min(deviceScaleX(), deviceScaleY());
        enterDeviceSpace();
        drawMaskedRounded(x0, y0, x1 - x0, y1 - y0, deviceRadius, color);
        pop();
    }

    public void roundedRectBorder(float x, float y, float width, float height, float radius, int bgColor, int borderColor) {
        if (width <= 0f || height <= 0f) {
            return;
        }
        if (!axisAligned()) {
            roundedRect(x - 1f, y - 1f, width + 2f, height + 2f, radius + 1f, borderColor);
            roundedRect(x, y, width, height, radius, bgColor);
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int x1 = Math.max(deviceX(x + width), x0 + 1);
        int y1 = Math.max(deviceY(y + height), y0 + 1);
        float deviceRadius = radius * Math.min(deviceScaleX(), deviceScaleY());
        enterDeviceSpace();
        drawMaskedRounded(x0, y0, x1 - x0, y1 - y0, deviceRadius, borderColor);
        if (x1 - x0 > 2 && y1 - y0 > 2) {
            drawMaskedRounded(x0 + 1, y0 + 1, x1 - x0 - 2, y1 - y0 - 2, Math.max(deviceRadius - 1f, 0.5f), bgColor);
        }
        pop();
    }

    private float deviceSize(float units) {
        return units * devicePerUnit();
    }

    public void circle(float centerX, float centerY, float radius, int color) {
        roundedRect(centerX - radius, centerY - radius, radius * 2f, radius * 2f, radius, color);
    }

    public void gradientVertical(float x, float y, float width, float height, int top, int bottom) {
        if (!axisAligned()) {
            graphics.fillGradient(Math.round(x), Math.round(y), Math.round(x + width), Math.round(y + height), apply(top), apply(bottom));
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int x1 = deviceX(x + width);
        int y1 = deviceY(y + height);
        enterDeviceSpace();
        graphics.fillGradient(x0, y0, x1, y1, apply(top), apply(bottom));
        pop();
    }

    public void gradientHorizontal(float x, float y, float width, float height, int left, int right) {
        if (!axisAligned()) {
            int x0 = Math.round(x);
            int columns = Math.round(x + width) - x0;
            for (int i = 0; i < columns; i++) {
                float t = columns == 1 ? 0f : i / (float) (columns - 1);
                graphics.fill(x0 + i, Math.round(y), x0 + i + 1, Math.round(y + height), apply(Colors.mix(left, right, t)));
            }
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int x1 = deviceX(x + width);
        int y1 = Math.max(deviceY(y + height), y0 + 1);

        enterDeviceSpace();
        translate(x0, y1);
        pose().rotate((float) (-Math.PI * 0.5));
        graphics.fillGradient(0, 0, y1 - y0, x1 - x0, apply(left), apply(right));
        pop();
    }

    private static float guiScale() {
        return (float) Minecraft.getInstance().getWindow().getGuiScale();
    }

    private boolean axisAligned() {
        Matrix3x2fStack pose = pose();
        return Math.abs(pose.m01()) < 1e-5f && Math.abs(pose.m10()) < 1e-5f && pose.m00() > 1e-5f && pose.m11() > 1e-5f;
    }

    private float deviceScaleX() {
        return pose().m00() * guiScale();
    }

    private float deviceScaleY() {
        return pose().m11() * guiScale();
    }

    private float deviceExactX(float x) {
        return (pose().m00() * x + pose().m20()) * guiScale();
    }

    private float deviceExactY(float y) {
        return (pose().m11() * y + pose().m21()) * guiScale();
    }

    private int deviceX(float x) {
        return Math.round((pose().m00() * x + pose().m20()) * guiScale());
    }

    private int deviceY(float y) {
        return Math.round((pose().m11() * y + pose().m21()) * guiScale());
    }

    private void enterDeviceSpace() {
        Matrix3x2fStack pose = pose();
        float scaleX = deviceScaleX();
        float scaleY = deviceScaleY();
        float originX = -pose.m20() / pose.m00();
        float originY = -pose.m21() / pose.m11();
        push();
        translate(originX, originY);
        scale(1f / scaleX, 1f / scaleY);
    }

    public void shadow(float x, float y, float width, float height, float radius, float blur, int color) {
        color = apply(color);
        if (Colors.alpha(color) == 0 || width <= 0f || height <= 0f || !axisAligned()) {
            return;
        }
        int x0 = deviceX(x);
        int y0 = deviceY(y);
        int boxWidth = deviceX(x + width) - x0;
        int boxHeight = deviceY(y + height) - y0;
        float scale = Math.min(deviceScaleX(), deviceScaleY());
        float deviceRadius = Math.min(radius * scale, Math.min(boxWidth, boxHeight) * 0.5f);
        float deviceBlur = Math.max(blur * scale, 1f);

        ShapeMasks.Mask mask = ShapeMasks.shadow(deviceRadius, deviceBlur);
        int pad = ShapeMasks.shadowPadding(Math.max(Math.round(deviceBlur * 2f), 2) / 2f);
        int areaX = x0 - pad;
        int areaY = y0 - pad;
        int areaWidth = boxWidth + pad * 2;
        int areaHeight = boxHeight + pad * 2;
        int corner = mask.corner();
        if (areaWidth < corner * 2 || areaHeight < corner * 2) {
            return;
        }
        int size = mask.size();
        int far = size - corner;
        int edgeWidth = areaWidth - corner * 2;
        int edgeHeight = areaHeight - corner * 2;
        enterDeviceSpace();
        maskQuad(mask, areaX, areaY, 0, 0, corner, corner, color);
        maskQuad(mask, areaX + areaWidth - corner, areaY, far, 0, corner, corner, color);
        maskQuad(mask, areaX, areaY + areaHeight - corner, 0, far, corner, corner, color);
        maskQuad(mask, areaX + areaWidth - corner, areaY + areaHeight - corner, far, far, corner, corner, color);

        maskStretch(mask, areaX + corner, areaY, edgeWidth, corner, corner - 1, 0, 1, corner, color);
        maskStretch(mask, areaX + corner, areaY + areaHeight - corner, edgeWidth, corner, corner - 1, far, 1, corner, color);
        maskStretch(mask, areaX, areaY + corner, corner, edgeHeight, 0, corner - 1, corner, 1, color);
        maskStretch(mask, areaX + areaWidth - corner, areaY + corner, corner, edgeHeight, far, corner - 1, corner, 1, color);
        if (edgeWidth > 0 && edgeHeight > 0) {
            graphics.fill(areaX + corner, areaY + corner, areaX + corner + edgeWidth, areaY + corner + edgeHeight, color);
        }
        pop();
    }

    private void drawMaskedRounded(int x0, int y0, int width, int height, float radius, int color) {
        if (width <= 0 || height <= 0) {
            return;
        }
        float r = Math.min(radius, Math.min(width, height) * 0.5f);
        if (r < 0.5f) {
            graphics.fill(x0, y0, x0 + width, y0 + height, color);
            return;
        }
        ShapeMasks.Mask mask = ShapeMasks.corner(r);
        int corner = mask.corner();
        int size = mask.size();

        int left = Math.min(corner, (width + 1) / 2);
        int right = Math.min(corner, width - left);
        int top = Math.min(corner, (height + 1) / 2);
        int bottom = Math.min(corner, height - top);

        maskQuad(mask, x0, y0, 0, 0, left, top, color);
        maskQuad(mask, x0 + width - right, y0, size - right, 0, right, top, color);
        maskQuad(mask, x0, y0 + height - bottom, 0, size - bottom, left, bottom, color);
        maskQuad(mask, x0 + width - right, y0 + height - bottom, size - right, size - bottom, right, bottom, color);
        if (width - left - right > 0) {
            graphics.fill(x0 + left, y0, x0 + width - right, y0 + top, color);
            graphics.fill(x0 + left, y0 + height - bottom, x0 + width - right, y0 + height, color);
        }
        if (height - top - bottom > 0) {
            graphics.fill(x0, y0 + top, x0 + width, y0 + height - bottom, color);
        }
    }

    private void maskQuad(ShapeMasks.Mask mask, int x, int y, int u, int v, int width, int height, int color) {
        maskStretch(mask, x, y, width, height, u, v, width, height, color);
    }

    private void maskStretch(ShapeMasks.Mask mask, int x, int y, int width, int height, int u, int v, int regionWidth, int regionHeight, int color) {
        if (width <= 0 || height <= 0) {
            return;
        }
        Masks.blit(graphics, mask.texture(), x, y, u, v, width, height, regionWidth, regionHeight, mask.size(), color);
    }

    private void drawRounded(int x0, int y0, int width, int height, float radius, int color) {
        drawRounded(x0, y0, width, height, radius, color, 1f);
    }

    private void drawRounded(int x0, int y0, int width, int height, float radius, int color, float softness) {
        if (width <= 0 || height <= 0) {
            return;
        }
        float r = Math.min(radius, Math.min(width, height) * 0.5f);
        if (softness <= 1f && r < 0.5f) {
            graphics.fill(x0, y0, x0 + width, y0 + height, color);
            return;
        }

        int pad = softness <= 1f ? 0 : (int) Math.ceil(softness * 0.5f);
        Shape shape = new Shape(x0 - pad, width + pad * 2, width * 0.5f, r, softness, color);
        int areaY = y0 - pad;
        int areaHeight = height + pad * 2;
        float halfHeight = height * 0.5f;
        float centerY = areaHeight * 0.5f;

        float uniformBelow = Math.min(0f, r - softness * 0.5f);

        int row = 0;
        for (; row < (areaHeight + 1) / 2; row++) {
            float qy = Math.abs(row + 0.5f - centerY) - (halfHeight - r);
            if (qy <= uniformBelow) {
                break;
            }
            int mirror = areaHeight - 1 - row;
            shapeRows(shape, qy, areaY + row, areaY + row + 1, areaY + mirror, mirror != row);
        }
        if (areaHeight - row * 2 > 0) {
            shapeRows(shape, uniformBelow - 1f, areaY + row, areaY + areaHeight - row, 0, false);
        }
    }

    private record Shape(int areaX, int areaWidth, float halfWidth, float radius, float softness, int color) {
    }

    private void shapeRows(Shape shape, float qy, int fromY, int toY, int mirrorY, boolean mirrored) {
        int width = shape.areaWidth();
        float center = width * 0.5f;
        int half = width / 2;
        int px = 0;
        int runStart = 0;
        int runColor = 0;
        for (; px < half; px++) {
            float coverage = coverage(shape, Math.abs(px + 0.5f - center) - (shape.halfWidth() - shape.radius()), qy);
            if (coverage >= 1f) {
                break;
            }
            int shade = Colors.fade(shape.color(), coverage);
            if (shade != runColor) {
                mirroredSpan(shape, runStart, px, fromY, toY, mirrorY, mirrored, runColor);
                runStart = px;
                runColor = shade;
            }
        }
        mirroredSpan(shape, runStart, px, fromY, toY, mirrorY, mirrored, runColor);

        if (width - px > px) {
            int middle = shape.color();
            if (px == half) {
                middle = Colors.fade(middle, coverage(shape, -(shape.halfWidth() - shape.radius()), qy));
            }
            if (Colors.alpha(middle) != 0) {
                rowsFill(shape.areaX() + px, shape.areaX() + width - px, fromY, toY, mirrorY, mirrored, middle);
            }
        }
    }

    private static float coverage(Shape shape, float qx, float qy) {
        float outsideX = Math.max(qx, 0f);
        float outsideY = Math.max(qy, 0f);
        float distance = (float) Math.sqrt(outsideX * outsideX + outsideY * outsideY) + Math.min(Math.max(qx, qy), 0f) - shape.radius();
        float softness = shape.softness();
        float t = Math.clamp(0.5f - distance / softness, 0f, 1f);
        if (softness <= 1f) {
            return t;
        }

        t = t * t * (3f - 2f * t);
        return Math.round(t * 48f) / 48f;
    }

    private void mirroredSpan(Shape shape, int from, int to, int fromY, int toY, int mirrorY, boolean mirrored, int color) {
        if (to <= from || Colors.alpha(color) == 0) {
            return;
        }
        int x0 = shape.areaX();
        int width = shape.areaWidth();
        rowsFill(x0 + from, x0 + to, fromY, toY, mirrorY, mirrored, color);
        rowsFill(x0 + width - to, x0 + width - from, fromY, toY, mirrorY, mirrored, color);
    }

    private void rowsFill(int fromX, int toX, int fromY, int toY, int mirrorY, boolean mirrored, int color) {
        graphics.fill(fromX, fromY, toX, toY, color);
        if (mirrored) {
            graphics.fill(fromX, mirrorY, toX, mirrorY + 1, color);
        }
    }

    public void text(TextFont textFont, String text, float x, float centerY, float size, int color) {
        text(textFont, text, x, centerY, size, color, 0f);
    }

    public void text(TextFont textFont, String text, float x, float centerY, float size, int color, float smear) {
        if (text.isEmpty()) {
            return;
        }
        int raster = textFont.rasterFor(size * devicePerUnit());
        draw(textFont, textFont.of(text, raster).getVisualOrderText(), raster, x, centerY, size, color, smear);
    }

    public boolean text(TextFont textFont, Label text, float x, float centerY, float size, int color, float maxWidth) {
        if (text.isEmpty()) {
            return false;
        }
        int raster = textFont.rasterFor(size * devicePerUnit());
        Style style = textFont.style(raster);
        float unit = shownSize(textFont, size, raster) / TextFont.BASE_SIZE;
        FormattedCharSequence shown = text.sequence(style);
        boolean trimmed = font().width(shown) * unit > maxWidth;
        if (trimmed) {
            int low = 0;
            int high = text.length();
            while (low < high) {
                int mid = (low + high + 1) >>> 1;
                if (font().width(text.sequence(style, mid, true)) * unit <= maxWidth) {
                    low = mid;
                } else {
                    high = mid - 1;
                }
            }
            shown = text.sequence(style, low, true);
        }
        draw(textFont, shown, raster, x, centerY, size, color, 0f);
        return trimmed;
    }

    public float textWidth(TextFont textFont, Label text, float size) {
        int raster = textFont.rasterFor(size * devicePerUnit());
        return font().width(text.sequence(textFont.style(raster))) * shownSize(textFont, size, raster) / TextFont.BASE_SIZE;
    }

    private void draw(TextFont textFont, FormattedCharSequence component, int raster, float x, float centerY, float size, int color, float smear) {
        color = apply(color);
        if (Colors.alpha(color) < 4) {
            return;
        }
        float device = devicePerUnit();
        float shownSize = shownSize(textFont, size, raster);
        float scale = shownSize / TextFont.BASE_SIZE;

        float tx = x;
        float ty = centerY - shownSize * textFont.center();
        if (axisAligned() && floating == 0) {
            Matrix3x2fStack pose = pose();
            float guiScale = guiScale();
            float screenX = (pose.m00() * tx + pose.m20()) * guiScale;
            float screenY = (pose.m11() * ty + pose.m21()) * guiScale;
            tx = (Math.round(screenX) / guiScale - pose.m20()) / pose.m00();
            ty = (Math.round(screenY) / guiScale - pose.m21()) / pose.m11();
        }

        push();
        translate(tx, ty);
        scale(scale, scale);
        graphics.drawString(font(), component, 0, 0, color, false);
        if (smear > 0f) {
            float offset = smear / (scale * device);
            translate(offset, 0f);
            graphics.drawString(font(), component, 0, 0, color, false);
            translate(0f, offset);
            graphics.drawString(font(), component, 0, 0, color, false);
            translate(-offset, 0f);
            graphics.drawString(font(), component, 0, 0, color, false);
        }
        pop();
    }

    public void textCentered(TextFont textFont, String text, float centerX, float centerY, float size, int color) {
        text(textFont, text, centerX - textWidth(textFont, text, size) * 0.5f, centerY, size, color);
    }

    public void textRight(TextFont textFont, String text, float rightX, float centerY, float size, int color) {
        text(textFont, text, rightX - textWidth(textFont, text, size), centerY, size, color);
    }

    public void icon(String glyph, float centerX, float centerY, float size, int color) {
        icon(glyph, centerX, centerY, size, color, 0.4f);
    }

    public void icon(String glyph, float centerX, float centerY, float size, int color, float smear) {
        float width = textWidth(TextFont.ICONS, glyph, size);
        text(TextFont.ICONS, glyph, centerX - width * 0.5f, centerY, size, color, smear);
    }

    public float textWidth(TextFont textFont, String text, float size) {
        int raster = textFont.rasterFor(size * devicePerUnit());
        return font().width(textFont.of(text, raster)) * shownSize(textFont, size, raster) / TextFont.BASE_SIZE;
    }

    private float devicePerUnit() {
        Matrix3x2fStack pose = pose();
        return (float) Math.sqrt(pose.m00() * pose.m00() + pose.m01() * pose.m01()) * guiScale();
    }

    private float shownSize(TextFont textFont, float size, int raster) {
        float device = devicePerUnit();
        if (device < 1e-6f || !textFont.covers(size * device)) {
            return size;
        }
        return raster / (float) textFont.supersample() / device;
    }

    public String trim(TextFont textFont, String text, float size, float maxWidth) {
        if (textWidth(textFont, text, size) <= maxWidth) {
            return text;
        }
        String ellipsis = "...";
        int low = 0;
        int high = text.length();
        while (low < high) {
            int mid = (low + high + 1) >>> 1;
            if (textWidth(textFont, text.substring(0, mid) + ellipsis, size) <= maxWidth) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return text.substring(0, low).stripTrailing() + ellipsis;
    }
}
