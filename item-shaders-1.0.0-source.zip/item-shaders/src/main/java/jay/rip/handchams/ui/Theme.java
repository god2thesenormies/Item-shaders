package jay.rip.handchams.ui;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Renderer;

import static jay.rip.handchams.ui.framework.Colors.rgb;
import static jay.rip.handchams.ui.framework.Colors.rgba;

public final class Theme {
    public static final int WINDOW = rgb(14, 14, 14);
    public static final int PANEL = rgb(20, 20, 20);
    public static final int PANEL_RIM = rgba(255, 255, 255, 30);

    public static final int CARD_RIM = rgba(255, 255, 255, 18);
    public static final int CARD = rgb(26, 26, 26);
    public static final int PILL = rgb(44, 44, 44);
    public static final int PILL_HOVER = rgb(36, 36, 36);
    public static final int CONTROL = rgb(38, 38, 38);
    public static final int CONTROL_HOVER = rgb(50, 50, 50);
    public static final int CONTROL_TEXT = rgb(220, 220, 220);
    public static final int SEARCH = rgb(32, 32, 32);
    public static final int SEARCH_HOVER = rgb(42, 42, 42);
    public static final int ROW_SEPARATOR = rgb(34, 34, 34);
    public static final int LOGO_SEPARATOR = rgb(58, 58, 58);
    public static final int POPUP = rgb(24, 24, 24);
    public static final int POPUP_BORDER = rgb(60, 60, 60);
    public static final int POPUP_HIGHLIGHT = rgb(40, 40, 40);
    public static final int TEXT = rgb(228, 228, 228);
    public static final int TEXT_BRIGHT = rgb(255, 255, 255);
    public static final int TEXT_DIM = rgb(150, 150, 150);
    public static final int TEXT_MUTED = rgb(110, 110, 110);
    public static final int NAV_TEXT = rgb(190, 190, 190);
    public static final int KNOB = rgb(236, 236, 236);
    public static final int KNOB_SHADOW = rgba(0, 0, 0, 80);

    private Theme() {
    }

    public static int accent() {
        return ItemShaders.menuSettings().appearance.accent.get();
    }

    public static int secondary() {
        return ItemShaders.menuSettings().appearance.secondary.get();
    }

    public static int accentText() {
        return readable(accent());
    }

    public static int secondaryText() {
        return readable(secondary());
    }

    public static int readable(int color) {
        float luminance = (0.2126f * Colors.red(color) + 0.7152f * Colors.green(color) + 0.0722f * Colors.blue(color)) / 255f;
        float lift = Math.clamp((0.55f - luminance) * 1.25f, 0f, 0.6f);
        return lift <= 0f ? color : Colors.mix(color, KNOB, lift);
    }

    public static int shimmer(float time, float letter) {
        float t = (float) (Math.sin(time * 1.1f - letter * 0.5f) * 0.5f + 0.5f);
        return Colors.withAlpha(Colors.mix(accentText(), secondaryText(), t), 255);
    }

    public static float radius() {
        return ItemShaders.menuSettings().appearance.cornerRadius.floatValue();
    }

    public static void panel(Renderer renderer, float x, float y, float width, float height) {
        renderer.roundedRectBorder(x, y, width, height, radius(), PANEL, PANEL_RIM);
    }

    public static void shadow(Renderer renderer, float x, float y, float width, float height, float radius, int depth) {
        renderer.shadow(x, y + depth * 0.6f, width, height, radius, depth * 7f, rgba(0, 0, 0, 40 + depth * 8));
    }
}
