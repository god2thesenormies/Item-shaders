package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.ColorSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.component.popup.ColorPickerPopup;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class ColorRow extends SettingRow<ColorSetting> {
    private static final float SWATCH_WIDTH = 56f;
    private static final float SWATCH_HEIGHT = 31f;

    private final ColorPickerPopup picker;
    private final Spring hover = Spring.smooth(0f);

    public ColorRow(ColorSetting setting) {
        super(setting);
        this.picker = new ColorPickerPopup(setting);
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float swatchX = right - SWATCH_WIDTH;
        float swatchY = centerY - SWATCH_HEIGHT * 0.5f;
        float radius = SWATCH_HEIGHT * 0.5f;

        boolean open = ui.isOpen(picker);
        if (input.clicked(swatchX, swatchY, SWATCH_WIDTH, SWATCH_HEIGHT) || rowClicked(ui, cardX, top, cardWidth)) {
            picker.open(ui, swatchX + SWATCH_WIDTH, swatchY + SWATCH_HEIGHT + 8f);
        }
        float hoverAmount = hover.update(hovered || open ? 1f : 0f, ui.delta());

        String hex = setting.hex();
        float hexRight = swatchX - 12f;
        renderer.textRight(TextFont.REGULAR, hex, hexRight, centerY, 16f, Colors.fade(Theme.TEXT_DIM, hoverAmount));

        renderer.roundedRect(swatchX - 2f, swatchY - 2f, SWATCH_WIDTH + 4f, SWATCH_HEIGHT + 4f, radius + 2f,
                Colors.mix(Theme.CONTROL, Theme.accent(), open ? 1f : hoverAmount * 0.35f));
        if (Colors.alpha(setting.get()) < 255) {
            ColorPickerPopup.checkerboard(renderer, swatchX, swatchY, SWATCH_WIDTH, SWATCH_HEIGHT, radius);
        }
        renderer.roundedRect(swatchX, swatchY, SWATCH_WIDTH, SWATCH_HEIGHT, radius, setting.get());
        return hexRight - renderer.textWidth(TextFont.REGULAR, hex, 16f) * hoverAmount;
    }
}
