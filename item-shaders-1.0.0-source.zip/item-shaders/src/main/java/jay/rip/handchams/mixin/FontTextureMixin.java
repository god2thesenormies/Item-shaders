package jay.rip.handchams.mixin;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.compat.Fonts;
import net.minecraft.client.gui.font.FontTexture;
import net.minecraft.client.gui.font.GlyphRenderTypes;
import net.minecraft.client.renderer.texture.AbstractTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;

@Mixin(FontTexture.class)
public abstract class FontTextureMixin {
    @Inject(method = "<init>", at = @At("TAIL"))
    private void itemshaders$trackMenuFonts(Supplier<String> label, GlyphRenderTypes renderTypes, boolean colored, CallbackInfo ci) {
        if (label.get().startsWith(ItemShaders.MOD_ID + ":")) {
            AbstractTexture texture = (AbstractTexture) (Object) this;

            NativeImage.Format format = colored ? NativeImage.Format.RGBA : NativeImage.Format.LUMINANCE;
            GpuTexture gpu = texture.getTexture();
            try (NativeImage blank = new NativeImage(format, gpu.getWidth(0), gpu.getHeight(0), true)) {
                RenderSystem.getDevice().createCommandEncoder().writeToTexture(gpu, blank);
            } catch (RuntimeException e) {
                ItemShaders.LOGGER.warn("Couldn't clear font atlas {}", label.get(), e);
            }
            Fonts.smooth(texture);
        }
    }
}
