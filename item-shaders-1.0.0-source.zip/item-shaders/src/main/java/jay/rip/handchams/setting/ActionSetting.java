package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

public final class ActionSetting extends Setting<Runnable> {
    private final String label;

    public ActionSetting(String name, String description, String label, Runnable action) {
        super(name, description, action);
        this.label = label;
    }

    public String label() {
        return label;
    }

    public void run() {
        get().run();
    }

    @Override
    public boolean isPersistent() {
        return false;
    }

    @Override
    public JsonElement toJson() {
        return JsonNull.INSTANCE;
    }

    @Override
    public void fromJson(JsonElement json) {
    }
}
