package jay.rip.handchams.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        register(new HandChams());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> inCategory(Category category) {
        return modules.stream().filter(module -> module.category() == category).toList();
    }

    public List<String> subcategories(Category category) {
        return modules.stream()
                .filter(module -> module.category() == category && module.subcategory() != null)
                .map(Module::subcategory)
                .distinct()
                .toList();
    }

    public List<Module> inSubcategory(Category category, String subcategory) {
        return modules.stream()
                .filter(module -> module.category() == category
                        && Objects.equals(module.subcategory(), subcategory))
                .toList();
    }

    public Optional<Module> byName(String name) {
        return modules.stream().filter(module -> module.name().text().equalsIgnoreCase(name)).findFirst();
    }

    @SuppressWarnings("unchecked")
    public <M extends Module> M get(Class<M> type) {
        for (Module module : modules) {
            if (module.getClass() == type) {
                return (M) module;
            }
        }
        throw new IllegalArgumentException("No module registered for " + type.getSimpleName());
    }

    public void onKeyPressed(int key) {
        for (Module module : modules) {
            if (module.keybind().matches(key)) {
                module.toggle();
            }
        }
    }

    public void onTick() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }
}
