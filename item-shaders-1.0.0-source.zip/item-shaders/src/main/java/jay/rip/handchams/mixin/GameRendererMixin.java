package jay.rip.handchams.mixin;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.module.HandChams;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    private static final String RENDER_HANDS = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderHandsWithItems"
            + "(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;"
            + "Lnet/minecraft/client/player/LocalPlayer;I)V";

    @Unique
    private boolean itemshaders$capturingHand;

    @Inject(method = "renderItemInHand", at = @At(value = "INVOKE", target = RENDER_HANDS))
    private void itemshaders$beginHandChams(float partialTick, boolean sleeping, Matrix4f view, CallbackInfo ci) {
        HandChams chams = ItemShaders.modules() == null ? null : ItemShaders.modules().get(HandChams.class);
        itemshaders$capturingHand = chams != null && chams.shouldRender(sleeping) && chams.beginCapture();
    }

    @Inject(method = "renderItemInHand", at = @At(value = "INVOKE", target = RENDER_HANDS, shift = At.Shift.AFTER))
    private void itemshaders$endHandChams(float partialTick, boolean sleeping, Matrix4f view, CallbackInfo ci) {
        if (!itemshaders$capturingHand) {
            return;
        }
        itemshaders$capturingHand = false;
        ItemShaders.modules().get(HandChams.class).endCapture();
    }
}
