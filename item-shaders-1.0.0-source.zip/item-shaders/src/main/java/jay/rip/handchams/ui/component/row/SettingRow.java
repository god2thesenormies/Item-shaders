package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.setting.Setting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Label;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public abstract class SettingRow<S extends Setting<?>> {
    public static final float HEIGHT = 64f;

    protected static final float CONTROL_INSET = 24f;

    protected static final float CONTROL_CENTER = 26f;
    private static final float TEXT_INSET = 24f;
    private static final float NAME_SIZE = 17.5f;
    private static final float DESCRIPTION_SIZE = 14.5f;
    private static final float TOOLTIP_DELAY = 0.6f;

    protected final S setting;
    private final Spring visibility;
    private final Spring hover = new Spring(0f, 14f, 0.65f);
    private float hoverTime;

    protected SettingRow(S setting) {
        this.setting = setting;
        this.visibility = Spring.smooth(setting.isVisible() ? 1f : 0f);
    }

    public S setting() {
        return setting;
    }

    public float height() {
        return HEIGHT;
    }

    public float update(float delta) {
        visibility.update(setting.isVisible() ? 1f : 0f, delta);
        return currentHeight();
    }

    public float currentHeight() {
        return height() * Math.max(0f, visibility.value());
    }

    protected float shown() {
        return Math.clamp(visibility.value(), 0f, 1f);
    }

    public boolean isSection() {
        return false;
    }

    public void render(Ui ui, float cardX, float top, float cardWidth, boolean first) {
        render(ui, cardX, top, cardWidth, first, cardX, cardWidth);
    }

    public void render(Ui ui, float cardX, float top, float cardWidth, boolean first, float clipX, float clipWidth) {
        float shown = Math.clamp(visibility.value(), 0f, 1f);
        if (shown < 0.01f) {
            return;
        }
        Renderer renderer = ui.renderer();
        Input input = ui.input();

        float rowTime = ui.pageTime() - 0.06f - ui.nextRowIndex() * 0.035f;
        float slide = (1f - Easing.outBack(rowTime / 0.45f)) * 28f;
        float entrance = Math.clamp(rowTime / 0.25f, 0f, 1f);

        boolean clipped = shown < 0.99f;
        if (clipped) {
            ui.pushClip(clipX, top - 16f, clipWidth, height() * shown + 16f);
        }
        renderer.pushOpacity(shown * entrance);

        if (!first) {
            renderer.roundedRect(cardX + 20f, top - 12f, cardWidth - 38f, 2f, 1f, Theme.ROW_SEPARATOR);
        }
        boolean hovered = input.hovering(cardX + 14f, top - 6f, cardWidth - 28f, 56f);
        float hoverAmount = hover.update(hovered ? 1f : 0f, ui.delta());
        float wash = Math.clamp(hoverAmount, 0f, 1f);
        if (wash > 0.01f) {
            renderer.roundedRect(cardX + 14f, top - 6f, cardWidth - 28f, 56f, 10f, Colors.rgba(255, 255, 255, Math.round(7 * wash)));
        }

        float right = cardX + cardWidth - CONTROL_INSET + slide;
        float controlLeft = renderControl(ui, right, top + CONTROL_CENTER, cardX, top, cardWidth, hovered);

        float textX = cardX + TEXT_INSET + slide + hoverAmount * 3f;
        float maxWidth = Math.max(controlLeft - 14f - textX, 100f);
        boolean tooltips = ItemShaders.menuSettings().general.tooltips.isEnabled();
        if (tooltips) {
            renderer.text(TextFont.BOLD, setting.name(), textX, top + CONTROL_CENTER, NAME_SIZE, Theme.TEXT, maxWidth);
            updateTooltip(ui, hovered, setting.description());
        } else {
            renderer.text(TextFont.BOLD, setting.name(), textX, top + 15f, NAME_SIZE, Theme.TEXT, maxWidth);
            renderer.text(TextFont.REGULAR, setting.description(), textX, top + 34f, DESCRIPTION_SIZE, Theme.TEXT_DIM, maxWidth);
            hoverTime = 0f;
        }

        renderer.popOpacity();
        if (clipped) {
            ui.popClip();
        }
    }

    protected abstract float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered);

    protected boolean rowClicked(Ui ui, float cardX, float top, float cardWidth) {
        return ui.input().clicked(cardX + 14f, top - 6f, cardWidth - 28f, 56f);
    }

    private void updateTooltip(Ui ui, boolean show, Label description) {
        hoverTime = show ? hoverTime + ui.delta() : 0f;
        if (hoverTime > TOOLTIP_DELAY) {
            ui.tooltip(description, ui.input().mouseX(), ui.input().mouseY());
        }
    }
}
