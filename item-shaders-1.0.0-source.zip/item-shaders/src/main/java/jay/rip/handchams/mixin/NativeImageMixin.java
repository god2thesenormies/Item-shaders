package jay.rip.handchams.mixin;

import com.mojang.blaze3d.platform.NativeImage;
import jay.rip.handchams.ui.framework.SmoothFonts;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FreeType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(NativeImage.class)
public abstract class NativeImageMixin {
    @Shadow
    public abstract int getWidth();

    @Shadow
    public abstract int getHeight();

    @Shadow
    public abstract long getPointer();

    @Redirect(method = "copyFromFont", at = @At(value = "INVOKE",
            target = "Lorg/lwjgl/util/freetype/FreeType;FT_Load_Glyph(Lorg/lwjgl/util/freetype/FT_Face;II)I"))
    private int itemshaders$renderUnhinted(FT_Face face, int glyphIndex, int flags) {
        return FreeType.FT_Load_Glyph(face, glyphIndex, SmoothFonts.loadFlags(face, flags));
    }

    @Inject(method = "copyFromFont", at = @At("RETURN"))
    private void itemshaders$darkenStems(FT_Face face, int glyphIndex, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() || !SmoothFonts.isUnhinted(face)) {
            return;
        }

        long pointer = getPointer();
        int count = getWidth() * getHeight();
        for (int i = 0; i < count; i++) {
            byte value = MemoryUtil.memGetByte(pointer + i);
            MemoryUtil.memPutByte(pointer + i, (byte) SmoothFonts.darken(value));
        }
    }
}
