package jay.rip.handchams.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.math.BigDecimal;
import java.util.Locale;

public final class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;
    private final String suffix;

    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
        this(name, description, defaultValue, min, max, step, "");
    }

    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step, String suffix) {
        super(name, description, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
        this.suffix = suffix;
    }

    public double min() {
        return min;
    }

    public double max() {
        return max;
    }

    public double step() {
        return step;
    }

    public float floatValue() {
        return get().floatValue();
    }

    public double progress() {
        return (get() - min) / (max - min);
    }

    public void setProgress(double progress) {
        set(min + (max - min) * progress);
    }

    public String format() {
        int decimals = Math.max(0, BigDecimal.valueOf(step).stripTrailingZeros().scale());
        return String.format(Locale.ROOT, "%." + decimals + "f", get()) + suffix;
    }

    @Override
    protected Double sanitize(Double value) {
        double snapped = Math.round((value - min) / step) * step + min;
        return Math.clamp(snapped, min, max);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement json) {
        set(json.getAsDouble());
    }
}
