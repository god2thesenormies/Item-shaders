package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.ModeSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.component.popup.DropdownPopup;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Icons;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class ModeRow extends SettingRow<ModeSetting> {
    private static final float BOX_HEIGHT = 31f;
    private static final float TEXT_SIZE = 16.5f;

    private final DropdownPopup dropdown;
    private final Approach hover = new Approach(0f);
    private final Spring arrow = new Spring(0f, 15f, 0.4f);
    private final Spring change = new Spring(1f, 15f, 0.45f);
    private final Jelly jelly = new Jelly();
    private String shownMode;

    public ModeRow(ModeSetting setting) {
        super(setting);
        this.dropdown = new DropdownPopup(setting);
        this.shownMode = setting.get();
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float delta = ui.delta();

        float widest = 0f;
        for (String mode : setting.modes()) {
            widest = Math.max(widest, renderer.textWidth(TextFont.SEMIBOLD, mode, TEXT_SIZE));
        }
        float maxBoxWidth = Math.max(cardWidth * 0.45f, 90f);
        float minBoxWidth = Math.min(143f, maxBoxWidth);
        float boxWidth = Math.clamp(widest + 64f, minBoxWidth, maxBoxWidth);
        float boxX = right - boxWidth;
        float boxY = centerY - BOX_HEIGHT * 0.5f;

        boolean open = ui.isOpen(dropdown);
        if (input.clicked(boxX, boxY, boxWidth, BOX_HEIGHT)) {
            dropdown.open(ui, boxX, boxY + BOX_HEIGHT + 6f, boxWidth);
        }
        boolean boxHovered = input.hovering(boxX, boxY, boxWidth, BOX_HEIGHT);
        float hoverAmount = hover.update(boxHovered || open ? 1f : 0f, delta);
        float arrowAmount = arrow.update(open ? 1f : 0f, delta);
        jelly.update(input.held(boxX, boxY, boxWidth, BOX_HEIGHT), boxHovered, 0.7f, delta);

        if (!shownMode.equals(setting.get())) {
            shownMode = setting.get();
            change.snap(0f);
        }
        float changeAmount = change.update(1f, delta);

        jelly.push(renderer, boxX + boxWidth * 0.5f, centerY);
        renderer.roundedRectBorder(boxX, boxY, boxWidth, BOX_HEIGHT, BOX_HEIGHT * 0.5f,
                Colors.mix(Theme.CONTROL, Theme.CONTROL_HOVER, hoverAmount), Theme.CARD_RIM);
        renderer.pushClip(boxX, boxY, boxWidth, BOX_HEIGHT);
        renderer.pushOpacity(Math.clamp(changeAmount * 1.5f, 0f, 1f));
        String text = renderer.trim(TextFont.SEMIBOLD, shownMode, TEXT_SIZE, boxWidth - 54f);
        renderer.text(TextFont.SEMIBOLD, text, boxX + 16f, centerY - (1f - changeAmount) * 12f, TEXT_SIZE, Theme.CONTROL_TEXT);
        renderer.popOpacity();
        renderer.popClip();

        float arrowX = boxX + boxWidth - 26f;
        renderer.push();
        renderer.rotateAround(arrowX, centerY, (float) Math.PI * arrowAmount);
        renderer.icon(Icons.CHEVRON_DOWN, arrowX, centerY, 16f, Colors.mix(Colors.rgb(180, 180, 180), Theme.accentText(), arrowAmount));
        renderer.pop();
        renderer.pop();
        return boxX;
    }
}
