package jay.rip.handchams.ui.component;

import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Approach;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Jelly;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.Ui;

public final class Switch {
    public static final float WIDTH = 52f;
    public static final float HEIGHT = 27f;

    private final Spring knob = new Spring(0f, 15f, 0.45f);
    private final Approach tint = new Approach(0f, 12f);
    private final Approach hover = new Approach(0f);
    private final Spring press = new Spring(0f, 22f, 0.5f);
    private final Jelly jelly = new Jelly();

    public Switch(boolean initial) {
        knob.snap(initial ? 1f : 0f);
        tint.snap(initial ? 1f : 0f);
    }

    public boolean render(Ui ui, float x, float y, boolean on) {
        Input input = ui.input();
        Renderer renderer = ui.renderer();
        float delta = ui.delta();

        float hitX = x - 3f;
        float hitY = y - 3f;
        boolean hovered = input.hovering(hitX, hitY, WIDTH + 6f, HEIGHT + 6f);
        boolean held = input.held(hitX, hitY, WIDTH + 6f, HEIGHT + 6f);
        boolean clicked = input.clicked(hitX, hitY, WIDTH + 6f, HEIGHT + 6f);

        float position = knob.update(on ? 1f : 0f, delta);
        float velocity = knob.velocity();
        float color = tint.update(on ? 1f : 0f, delta);
        float hoverAmount = hover.update(hovered ? 1f : 0f, delta);
        float pressAmount = press.update(held ? 1f : 0f, delta);
        jelly.update(held, hovered, 0.6f, delta);

        float centerY = y + HEIGHT * 0.5f;
        jelly.push(renderer, x + WIDTH * 0.5f, centerY);
        int off = Colors.mix(Theme.CONTROL, Theme.CONTROL_HOVER, hoverAmount);
        renderer.roundedRect(x, y, WIDTH, HEIGHT, HEIGHT * 0.5f, Colors.mix(off, Theme.accent(), color));

        float radius = HEIGHT * 0.5f - 3f;
        float travel = Math.clamp(position, 0f, 1f);
        float over = Math.abs(position - travel);
        float stretch = 1f + Math.min(Math.abs(velocity) * 0.045f, 0.5f);
        float grow = pressAmount * 4f * (radius / 12.5f);
        float halfWidth = Math.max(radius * (stretch - over * 1.6f), radius * 0.56f) + grow;
        float halfHeight = radius / (float) Math.sqrt(stretch) * (1f + over * 1.2f) * (1f - pressAmount * 0.06f);
        float start = x + HEIGHT * 0.5f;
        float end = x + WIDTH - HEIGHT * 0.5f;
        float centerX = start + (end - start) * travel + (on ? -grow : grow);
        float corner = Math.min(halfWidth, halfHeight);
        renderer.roundedRect(centerX - halfWidth, centerY - halfHeight + 1.5f, halfWidth * 2f, halfHeight * 2f, halfHeight, Theme.KNOB_SHADOW);
        renderer.roundedRect(centerX - halfWidth, centerY - halfHeight, halfWidth * 2f, halfHeight * 2f, corner, Theme.KNOB);
        renderer.pop();
        return clicked;
    }
}
