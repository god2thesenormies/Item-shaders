package jay.rip.handchams.ui.framework;

public final class Jelly {
    private final Spring x = new Spring(1f, 17f, 0.3f);
    private final Spring y = new Spring(1f, 21f, 0.28f);

    public void update(boolean held, boolean hovered, float amount, float delta) {
        float targetX = held ? 1f + 0.05f * amount : hovered ? 1f + 0.018f * amount : 1f;
        float targetY = held ? 1f - 0.10f * amount : hovered ? 1f + 0.018f * amount : 1f;
        x.update(targetX, delta);
        y.update(targetY, delta);
    }

    public void poke(float scaleY) {
        y.snap(scaleY);
    }

    public float scaleX() {
        return x.value();
    }

    public float scaleY() {
        return y.value();
    }

    public void push(Renderer renderer, float centerX, float centerY) {
        push(renderer, centerX, centerY, 1f);
    }

    public void push(Renderer renderer, float centerX, float centerY, float extra) {
        renderer.push();
        float sx = x.value() * extra;
        float sy = y.value() * extra;
        if (Math.abs(sx - 1f) > 1e-4f || Math.abs(sy - 1f) > 1e-4f) {
            renderer.scaleAround(centerX, centerY, sx, sy);
        }
    }
}
