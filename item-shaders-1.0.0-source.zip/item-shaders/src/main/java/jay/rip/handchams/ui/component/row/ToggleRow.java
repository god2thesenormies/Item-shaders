package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.BooleanSetting;
import jay.rip.handchams.ui.component.Switch;
import jay.rip.handchams.ui.framework.Ui;

public final class ToggleRow extends SettingRow<BooleanSetting> {
    private final Switch toggle;

    public ToggleRow(BooleanSetting setting) {
        super(setting);
        this.toggle = new Switch(setting.isEnabled());
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        float left = right - Switch.WIDTH;
        boolean clicked = toggle.render(ui, left, centerY - Switch.HEIGHT * 0.5f, setting.isEnabled());
        if (clicked || rowClicked(ui, cardX, top, cardWidth)) {
            setting.toggle();
        }
        return left;
    }
}
