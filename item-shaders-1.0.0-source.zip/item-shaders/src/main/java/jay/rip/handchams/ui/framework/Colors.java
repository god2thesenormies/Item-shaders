package jay.rip.handchams.ui.framework;

public final class Colors {
    private Colors() {
    }

    public static int rgb(int r, int g, int b) {
        return rgba(r, g, b, 255);
    }

    public static int rgba(int r, int g, int b, int a) {
        return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
    }

    public static int alpha(int color) {
        return color >>> 24;
    }

    public static int red(int color) {
        return color >> 16 & 0xFF;
    }

    public static int green(int color) {
        return color >> 8 & 0xFF;
    }

    public static int blue(int color) {
        return color & 0xFF;
    }

    public static int fade(int color, float factor) {
        int alpha = Math.round(alpha(color) * Math.clamp(factor, 0f, 1f));
        return color & 0x00FFFFFF | alpha << 24;
    }

    public static int withAlpha(int color, int alpha) {
        return color & 0x00FFFFFF | (alpha & 0xFF) << 24;
    }

    public static int mix(int from, int to, float t) {
        t = Math.clamp(t, 0f, 1f);
        return rgba(
                lerp(red(from), red(to), t),
                lerp(green(from), green(to), t),
                lerp(blue(from), blue(to), t),
                lerp(alpha(from), alpha(to), t));
    }

    public static int fromHsv(float hue, float saturation, float value, int alpha) {
        float h = (hue - (float) Math.floor(hue)) * 6f;
        int sector = (int) h;
        float f = h - sector;
        float p = value * (1f - saturation);
        float q = value * (1f - saturation * f);
        float t = value * (1f - saturation * (1f - f));
        float r, g, b;
        switch (sector) {
            case 0 -> { r = value; g = t; b = p; }
            case 1 -> { r = q; g = value; b = p; }
            case 2 -> { r = p; g = value; b = t; }
            case 3 -> { r = p; g = q; b = value; }
            case 4 -> { r = t; g = p; b = value; }
            default -> { r = value; g = p; b = q; }
        }
        return rgba(Math.round(r * 255), Math.round(g * 255), Math.round(b * 255), alpha);
    }

    public static float[] toHsv(int color) {
        float r = red(color) / 255f;
        float g = green(color) / 255f;
        float b = blue(color) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float delta = max - min;

        float hue = 0f;
        if (delta > 0f) {
            if (max == r) {
                hue = ((g - b) / delta) % 6f;
            } else if (max == g) {
                hue = (b - r) / delta + 2f;
            } else {
                hue = (r - g) / delta + 4f;
            }
            hue /= 6f;
            if (hue < 0f) {
                hue += 1f;
            }
        }
        float saturation = max == 0f ? 0f : delta / max;
        return new float[]{hue, saturation, max};
    }

    private static int lerp(int a, int b, float t) {
        return Math.round(a + (b - a) * t);
    }
}
