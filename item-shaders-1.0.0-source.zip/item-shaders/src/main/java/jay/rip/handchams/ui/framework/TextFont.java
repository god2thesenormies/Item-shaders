package jay.rip.handchams.ui.framework;

import jay.rip.handchams.compat.Ids;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;

import java.util.Locale;

public enum TextFont {
    REGULAR("regular", 0.37f, 8, 40, 1),

    SEMIBOLD("semibold", 0.37f, 8, 40, 1),

    BOLD("bold", 0.37f, 8, 40, 1),

    HEAVY("heavy", 0.37f, 16, 64, 1),

    ICONS("icons", 0.2f, 20, 56, 2);

    public static final float BASE_SIZE = 10f;

    private final Style[] styles;
    private final float center;
    private final int minRaster;
    private final int maxRaster;
    private final int supersample;

    TextFont(String name, float center, int minRaster, int maxRaster, int supersample) {
        this.center = center;
        this.minRaster = minRaster;
        this.maxRaster = maxRaster;
        this.supersample = supersample;
        this.styles = new Style[(maxRaster - minRaster) / supersample + 1];
        for (int raster = minRaster; raster <= maxRaster; raster += supersample) {
            String path = String.format(Locale.ROOT, "%s_%02d", name, raster);
            styles[(raster - minRaster) / supersample] = Style.EMPTY.withFont(new FontDescription.Resource(Ids.of(path)));
        }
    }

    public float center() {
        return center;
    }

    public int supersample() {
        return supersample;
    }

    public int rasterFor(float pixelSize) {
        int raster = Math.round(pixelSize) * supersample;
        return Math.clamp(raster, minRaster, maxRaster);
    }

    public boolean covers(float pixelSize) {
        float raster = pixelSize * supersample;
        return raster >= minRaster - 0.5f * supersample && raster <= maxRaster + 0.5f * supersample;
    }

    public Style style(int raster) {
        return styles[(raster - minRaster) / supersample];
    }

    public Component of(String text, int raster) {
        return Component.literal(text).withStyle(styles[(raster - minRaster) / supersample]);
    }
}
