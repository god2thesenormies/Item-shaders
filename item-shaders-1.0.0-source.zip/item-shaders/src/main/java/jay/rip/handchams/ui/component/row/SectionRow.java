package jay.rip.handchams.ui.component.row;

import jay.rip.handchams.setting.SectionSetting;
import jay.rip.handchams.ui.Theme;
import jay.rip.handchams.ui.framework.Colors;
import jay.rip.handchams.ui.framework.Easing;
import jay.rip.handchams.ui.framework.Icons;
import jay.rip.handchams.ui.framework.Input;
import jay.rip.handchams.ui.framework.Renderer;
import jay.rip.handchams.ui.framework.Spring;
import jay.rip.handchams.ui.framework.TextFont;
import jay.rip.handchams.ui.framework.Ui;

public final class SectionRow extends SettingRow<SectionSetting> {
    private static final float ROW_HEIGHT = 56f;

    private static final float TITLE_CENTER = 30f;
    private static final float TITLE_SIZE = 16f;

    private final Spring open;
    private final Spring hover = new Spring(0f, 14f, 0.65f);

    public SectionRow(SectionSetting setting) {
        super(setting);
        this.open = Spring.smooth(setting.isOpen() ? 1f : 0f);
    }

    @Override
    public float height() {
        return ROW_HEIGHT;
    }

    @Override
    public boolean isSection() {
        return true;
    }

    @Override
    public void render(Ui ui, float cardX, float top, float cardWidth, boolean first, float clipX, float clipWidth) {
        float shown = shown();
        if (shown < 0.01f) {
            return;
        }
        Renderer renderer = ui.renderer();
        Input input = ui.input();
        float rowTime = ui.pageTime() - 0.06f - ui.nextRowIndex() * 0.035f;
        float slide = (1f - Easing.outBack(rowTime / 0.45f)) * 28f;
        float entrance = Math.clamp(rowTime / 0.25f, 0f, 1f);

        boolean clipped = shown < 0.99f;
        if (clipped) {
            ui.pushClip(clipX, top - 16f, clipWidth, height() * shown + 16f);
        }
        renderer.pushOpacity(shown * entrance);

        float centerY = top + TITLE_CENTER;
        float hitTop = centerY - 18f;
        boolean hovered = input.hovering(cardX + 14f, hitTop, cardWidth - 28f, 36f);
        float hoverAmount = hover.update(hovered ? 1f : 0f, ui.delta());
        float openAmount = open.update(setting.isOpen() ? 1f : 0f, ui.delta());
        float wash = Math.clamp(hoverAmount, 0f, 1f);
        if (wash > 0.01f) {
            renderer.roundedRect(cardX + 14f, hitTop, cardWidth - 28f, 36f, 10f, Colors.rgba(255, 255, 255, Math.round(6 * wash)));
        }

        int accent = Theme.accentText();
        int titleColor = Colors.mix(accent, Theme.TEXT_BRIGHT, 0.2f * wash);
        float textX = cardX + 24f + slide + hoverAmount * 3f;
        float chevronX = cardX + cardWidth - CONTROL_INSET - 9f + slide;
        float titleWidth = Math.min(renderer.textWidth(TextFont.SEMIBOLD, setting.name(), TITLE_SIZE), chevronX - 40f - textX);

        renderer.text(TextFont.SEMIBOLD, setting.name(), textX, centerY, TITLE_SIZE, titleColor, titleWidth + 1f);

        float ruleLeft = textX + titleWidth + 14f;
        float ruleRight = chevronX - 20f;
        if (ruleRight - ruleLeft > 12f) {
            renderer.gradientHorizontal(ruleLeft, centerY, ruleRight - ruleLeft, 1f,
                    Colors.fade(Theme.accent(), 0.35f), Colors.fade(Theme.accent(), 0.04f));
        }

        renderer.push();
        renderer.rotateAround(chevronX, centerY, (float) Math.PI * openAmount);
        renderer.icon(Icons.CHEVRON_DOWN, chevronX, centerY, 17f,
                Colors.mix(Colors.rgb(160, 160, 160), Colors.rgb(230, 230, 230), wash));
        renderer.pop();

        if (input.clicked(cardX + 14f, hitTop, cardWidth - 28f, 36f)) {
            setting.toggle();
        }

        renderer.popOpacity();
        if (clipped) {
            ui.popClip();
        }
    }

    @Override
    protected float renderControl(Ui ui, float right, float centerY, float cardX, float top, float cardWidth, boolean hovered) {
        return right;
    }
}
