#version 330

uniform sampler2D InSampler;

out vec4 fragColor;

vec4 encode(vec2 a, vec2 b) {
    return (vec4(a, b) * 127.0 + 128.0) / 255.0;
}

vec4 decode(vec4 stored) {
    return (stored * 255.0 - 128.0) / 127.0;
}

void main() {
    ivec2 p = ivec2(gl_FragCoord.xy);

#ifdef GATHER
    vec2 texel = 1.0 / vec2(textureSize(InSampler, 0));
    vec2 normals[16];
    float weights[16];
    vec2 acc4 = vec2(0.0);
    float total = 0.0;
    for (int i = 0; i < 16; i++) {
        vec2 uv = (vec2(p) * 8.0 + vec2(i % 4, i / 4) * 2.0 + 1.0) * texel;
        float l = texture(InSampler, uv - vec2(texel.x, 0.0)).b;
        float r = texture(InSampler, uv + vec2(texel.x, 0.0)).b;
        float d = texture(InSampler, uv - vec2(0.0, texel.y)).b;
        float u = texture(InSampler, uv + vec2(0.0, texel.y)).b;
        vec2 g = vec2(r - l, u - d);
        float m = length(g);
        weights[i] = m > 0.01 ? m : 0.0;
        normals[i] = m > 0.01 ? g / m : vec2(1.0, 0.0);
        if (m > 0.01) {
            float a = atan(g.y, g.x) * 4.0;
            acc4 += m * vec2(cos(a), sin(a));
            total += m;
        }
    }
    if (total <= 0.0) {
        fragColor = encode(vec2(0.0), vec2(0.0));
        return;
    }

    float base = atan(acc4.y, acc4.x) * 0.25;
    vec2 refA = vec2(cos(2.0 * base), sin(2.0 * base));
    vec2 accA = vec2(0.0);
    vec2 accB = vec2(0.0);
    for (int i = 0; i < 16; i++) {
        if (weights[i] <= 0.0) continue;
        vec2 n = normals[i];
        vec2 doubled = vec2(n.x * n.x - n.y * n.y, 2.0 * n.x * n.y);
        if (dot(doubled, refA) >= 0.0) accA += weights[i] * doubled;
        else accB += weights[i] * doubled;
    }
    fragColor = encode(accA / total, accB / total);
#else
    ivec2 size = textureSize(InSampler, 0);

    vec2 refA = vec2(0.0);
    vec2 refB = vec2(0.0);
    float best = 0.0;
    for (int y = -5; y <= 5; y++) {
        for (int x = -5; x <= 5; x++) {
            vec4 c = decode(texelFetch(InSampler, clamp(p + ivec2(x, y), ivec2(0), size - 1), 0));
            float strength = (length(c.xy) + length(c.zw)) * exp(-float(x * x + y * y) / 12.5);
            if (strength > best) {
                best = strength;
                refA = c.xy;
                refB = c.zw;
            }
        }
    }
    vec2 accA = vec2(0.0);
    vec2 accB = vec2(0.0);
    for (int y = -5; y <= 5; y++) {
        for (int x = -5; x <= 5; x++) {
            vec4 c = decode(texelFetch(InSampler, clamp(p + ivec2(x, y), ivec2(0), size - 1), 0));
            float w = exp(-float(x * x + y * y) / 12.5);
            vec2 a = c.xy;
            vec2 b = c.zw;
            if (dot(a, refA) + dot(b, refB) < dot(a, refB) + dot(b, refA)) {
                vec2 swap = a;
                a = b;
                b = swap;
            }
            accA += a * w;
            accB += b * w;
        }
    }
    float la = length(accA);
    float lb = length(accB);

    vec2 a = la > 1e-4 ? accA / la : (lb > 1e-4 ? -accB / lb : vec2(1.0, 0.0));
    vec2 b = lb > 1e-4 ? accB / lb : -a;
    fragColor = encode(a, b);
#endif
}
