#version 330

uniform sampler2D HandSampler;
uniform sampler2D SceneSampler;
uniform sampler2D BlurSampler;
uniform sampler2D DistSampler;
uniform sampler2D OrientSampler;

layout(std140) uniform HandChamsConfig {
    vec4 Info;
    vec4 Radii;
    vec4 Common;
    vec4 Edge;
    vec4 GlowCfg;
    vec4 OutlineCfg;
    vec4 OutlineColor;
    vec4 OutlineColor2;
    vec4 FillColor;
    vec4 GlassA;
    vec4 GlassB;
    vec4 GlassC;
    vec4 GlassD;
    vec4 GlassTint;
    vec4 GlassBevel;
    vec4 GlassReflect;
    vec4 WaterA;
    vec4 WaterB;
    vec4 WaterColor;
    vec4 WaterHighlight;
    vec4 ChromeA;
    vec4 ChromeTint;
    vec4 ChromeHighlight;
    vec4 MetalA;
    vec4 MetalB;
    vec4 MetalC;
    vec4 MetalD;
    vec4 MetalE;
    vec4 MetalColor1;
    vec4 MetalColor2;
    vec4 MetalColor3;
    vec4 MetalColor4;
    vec4 AuroraA;
    vec4 AuroraColor1;
    vec4 AuroraColor2;
    vec4 AuroraSky;
    vec4 GalaxyA;
    vec4 GalaxyB;
    vec4 GalaxyColor1;
    vec4 GalaxyColor2;
    vec4 HoloA;
    vec4 HoloColor;
    vec4 ElectricA;
    vec4 ElectricColor;
    vec4 LavaA;
    vec4 LavaHot;
    vec4 LavaCrust;
};

in vec2 texCoord;

out vec4 fragColor;

const float TAU = 6.28318530718;
const float NO_EDGE = 1e4;

vec2 px() {
    return 1.0 / Info.zw;
}

vec2 aspectUv(vec2 uv) {
    return uv * vec2(Info.z / Info.w, 1.0);
}

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float maskAt(vec2 uv) {
    return texture(HandSampler, uv).a;
}

float surfaceAt(vec2 uv) {
    vec4 b = texture(BlurSampler, uv);
    return b.r + b.a / 255.0;
}

float glowAt(vec2 uv) {
    float g = texture(BlurSampler, uv).g;
    return g * g;
}

vec3 handNormal(vec2 uv) {
    vec2 e = px() * 2.0;
    float k = 0.12 * Common.y;
    float hl = surfaceAt(uv - vec2(e.x, 0.0)) + luma(texture(HandSampler, uv - vec2(e.x, 0.0)).rgb) * k;
    float hr = surfaceAt(uv + vec2(e.x, 0.0)) + luma(texture(HandSampler, uv + vec2(e.x, 0.0)).rgb) * k;
    float hd = surfaceAt(uv - vec2(0.0, e.y)) + luma(texture(HandSampler, uv - vec2(0.0, e.y)).rgb) * k;
    float hu = surfaceAt(uv + vec2(0.0, e.y)) + luma(texture(HandSampler, uv + vec2(0.0, e.y)).rgb) * k;
    return normalize(vec3(-(hr - hl) * 6.0, -(hu - hd) * 6.0, 1.0));
}

float textureLines(vec2 uv) {
    vec2 p = px();
    float l = luma(texture(HandSampler, uv - vec2(p.x, 0.0)).rgb);
    float r = luma(texture(HandSampler, uv + vec2(p.x, 0.0)).rgb);
    float d = luma(texture(HandSampler, uv - vec2(0.0, p.y)).rgb);
    float u = luma(texture(HandSampler, uv + vec2(0.0, p.y)).rgb);
    return clamp((abs(r - l) + abs(u - d)) * 4.0, 0.0, 1.0);
}

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

vec3 sceneAt(vec2 uv) {
    return texture(SceneSampler, clamp(uv, px(), 1.0 - px())).rgb;
}

vec3 frosted(vec2 uv, float frost) {
    if (frost < 0.5) return sceneAt(uv);
    vec2 b = px() * frost * 0.12;
    vec3 s = sceneAt(uv) * 0.2;
    s += sceneAt(uv + vec2(b.x, b.y)) * 0.1;
    s += sceneAt(uv + vec2(-b.x, b.y)) * 0.1;
    s += sceneAt(uv + vec2(b.x, -b.y)) * 0.1;
    s += sceneAt(uv + vec2(-b.x, -b.y)) * 0.1;
    s += sceneAt(uv + vec2(b.x * 1.5, 0.0)) * 0.1;
    s += sceneAt(uv - vec2(b.x * 1.5, 0.0)) * 0.1;
    s += sceneAt(uv + vec2(0.0, b.y * 1.5)) * 0.1;
    s += sceneAt(uv - vec2(0.0, b.y * 1.5)) * 0.1;
    return s;
}

vec4 distAt() {
    return texelFetch(DistSampler, ivec2(gl_FragCoord.xy), 0);
}

float insideDistance(vec4 d, out vec2 outward) {
    vec2 raw = floor(d.rg * 255.0 + 0.5);
    if (raw.x < 0.5) {
        outward = vec2(0.0);
        return NO_EDGE;
    }
    vec2 offset = raw - 128.0;
    float len = length(offset);
    outward = len > 0.0 ? offset / len : vec2(0.0);

    return max(len - 0.5, 0.0);
}

float outsideDistance(vec4 d) {
    vec2 raw = floor(d.ba * 255.0 + 0.5);
    if (raw.x < 0.5) return NO_EDGE;
    return max(length(raw - 128.0) - 0.5, 0.0);
}

vec3 shaderColor(vec2 uv);

vec3 outlineColor(vec2 uv) {
    float t = Info.x * GlowCfg.w;
    int mode = int(GlowCfg.y + 0.5);
    if (mode == 4) return shaderColor(uv);
    if (mode == 1) return hsv2rgb(vec3(fract(t * 0.2 + (uv.x + uv.y) * 0.5), 0.75, 1.0));
    if (mode == 2) return mix(OutlineColor.rgb, OutlineColor2.rgb, 0.5 + 0.5 * sin(t * 3.0));
    if (mode == 3) return mix(OutlineColor.rgb, OutlineColor2.rgb, 0.5 + 0.5 * sin((uv.x - uv.y) * 6.0 + t * 2.0));
    return OutlineColor.rgb;
}

void edgeNormals(vec4 o, out vec2 n1, out vec2 n2) {
    float aa = atan(o.y, o.x) * 0.5;
    float ab = atan(o.w, o.z) * 0.5;
    n1 = vec2(cos(aa), sin(aa));
    n2 = vec2(cos(ab), sin(ab));
    if (abs(dot(n1, n2)) > 0.85) n2 = vec2(-n1.y, n1.x);
}

vec4 decodeOrient(vec4 stored) {
    return (stored * 255.0 - 128.0) / 127.0;
}

vec4 orientAt(vec2 uv) {
    ivec2 size = textureSize(OrientSampler, 0);
    vec2 pos = uv * vec2(size) - 0.5;
    ivec2 base = ivec2(floor(pos));
    vec2 f = pos - vec2(base);
    vec4 first = decodeOrient(texelFetch(OrientSampler, clamp(base, ivec2(0), size - 1), 0));
    vec4 sum = vec4(0.0);
    for (int i = 0; i < 4; i++) {
        ivec2 o = ivec2(i & 1, i >> 1);
        vec4 c = decodeOrient(texelFetch(OrientSampler, clamp(base + o, ivec2(0), size - 1), 0));
        if (dot(c.xy, first.xy) + dot(c.zw, first.zw) < dot(c.xy, first.zw) + dot(c.zw, first.xy)) {
            c = c.zwxy;
        }
        float w = (o.x == 1 ? f.x : 1.0 - f.x) * (o.y == 1 ? f.y : 1.0 - f.y);
        sum += c * w;
    }
    return sum;
}

float gridDistance(vec2 offset, vec2 n1, vec2 n2) {
    return max(abs(dot(offset, n1)), abs(dot(offset, n2)));
}

float gridDistanceAt(ivec2 q, vec2 n1, vec2 n2) {
    vec2 raw = floor(texelFetch(DistSampler, q, 0).rg * 255.0 + 0.5);
    if (raw.x < 0.5) return 0.0;
    return gridDistance(raw - 128.0, n1, n2);
}

vec3 glassEffect(vec2 uv, vec3 handRgb, float dist, vec2 outward) {
    float t = Info.x;
    float radius = max(GlassB.z, 1.0);
    float sharp = GlassB.w * 0.01;

    vec2 facetOut = outward;
    if (dist < NO_EDGE) {
        vec2 n1;
        vec2 n2;
        edgeNormals(orientAt(uv), n1, n2);
        vec2 o = outward * (dist + 0.5);
        float d1 = dot(o, n1);
        float d2 = dot(o, n2);
        float grid = max(max(abs(d1), abs(d2)) - 0.5, 0.0);
        dist = mix(dist, grid, 0.35 + 0.65 * sharp);

        ivec2 c = ivec2(gl_FragCoord.xy);
        float g[9];
        for (int i = 0; i < 9; i++) {
            g[i] = gridDistanceAt(c + ivec2(i % 3 - 1, i / 3 - 1), n1, n2);
        }
        vec2 slope = vec2(g[2] + 2.0 * g[5] + g[8] - g[0] - 2.0 * g[3] - g[6],
                          g[6] + 2.0 * g[7] + g[8] - g[0] - 2.0 * g[1] - g[2]);
        vec2 out2 = length(slope) > 1e-4 ? -normalize(slope) : outward;
        float a1 = dot(out2, n1);
        float a2 = dot(out2, n2);
        vec2 f1 = a1 >= 0.0 ? n1 : -n1;
        vec2 f2 = a2 >= 0.0 ? n2 : -n2;
        facetOut = normalize(mix(f2, f1, smoothstep(-0.15, 0.15, abs(a1) - abs(a2))) + 1e-5);
    }
    float interior = clamp(dist / radius, 0.0, 1.0);
    float bevel = 1.0 - interior;

    vec2 ge = px() * max(radius, 4.0);
    vec2 grad = vec2(surfaceAt(uv + vec2(ge.x, 0.0)) - surfaceAt(uv - vec2(ge.x, 0.0)),
                     surfaceAt(uv + vec2(0.0, ge.y)) - surfaceAt(uv - vec2(0.0, ge.y)));
    vec2 broadOut = length(grad) > 1e-6 ? -normalize(grad) : outward;
    vec2 dir = normalize(mix(broadOut, facetOut, sharp) + 1e-5);

    float inBevel = 1.0 - smoothstep(radius - 0.6, radius + 0.6, dist);
    float rise = sqrt(max(1.0 - bevel * bevel, 0.0));
    vec3 roundN = normalize(vec3(dir * bevel, max(rise, 0.1)));
    vec3 chamferN = normalize(vec3(dir * 0.7 * inBevel, 1.0));
    float relief = (luma(handRgb) - 0.5) * 0.15 * Common.y;
    vec3 n = normalize(mix(roundN, chamferN, sharp) + vec3(relief, relief, 0.0));
    float bevelMask = mix(smoothstep(0.0, 1.0, bevel), inBevel, sharp);
    float cosTheta = clamp(n.z, 0.0, 1.0);

    vec2 lightDir = vec2(cos(GlassB.x), sin(GlassB.x));
    float facing = dot(dir, lightDir);
    float lit = smoothstep(-0.2, 1.0, facing);
    float edgeLight = GlassB.y * 0.01;

    float refr = GlassA.x * 0.01;
    float disp = GlassA.w * 0.01;
    vec2 bend = (-n.xy * (6.0 + radius * 0.9) - lightDir * GlassA.y * 0.04) * refr * px();
    float frost = GlassA.z;
    vec3 behind;
    behind.r = frosted(uv + bend * (1.0 - disp * 0.6), frost).r;
    behind.g = frosted(uv + bend, frost).g;
    behind.b = frosted(uv + bend * (1.0 + disp * 0.6), frost).b;

    float path = (0.3 + 0.7 * interior) * (0.25 + GlassA.y * 0.015) + bevelMask * GlassD.y * 0.012;
    vec3 absorb = exp(-(vec3(1.0) - max(GlassTint.rgb, vec3(0.02))) * path * GlassTint.a * 3.0);
    vec3 col = behind * absorb;

    col = mix(col, GlassTint.rgb * (0.75 + 0.25 * lit), 0.05 + GlassTint.a * 0.08);

    col *= 1.0 - bevelMask * (1.0 - lit) * (0.12 + GlassD.y * 0.004);

    vec3 r = reflect(vec3(0.0, 0.0, -1.0), n);
    float fresnel = 0.04 + 0.96 * pow(1.0 - cosTheta, 5.0);

    float reflSlider = GlassC.x * 0.01;
    float reflAmount = clamp(fresnel * reflSlider * 2.0 + reflSlider * reflSlider * reflSlider * 0.75, 0.0, 1.0);
    vec3 mirrored = frosted(vec2(uv.x + r.x * 0.2, uv.y + 0.28 + r.y * 0.2), 30.0 + frost * 0.5);
    float skyY = clamp(r.y * 0.6 + 0.5 + (uv.y - 0.3) * 0.4, 0.0, 1.0);
    vec3 sky = mix(vec3(0.42, 0.45, 0.5), vec3(0.92, 0.95, 1.0), smoothstep(0.0, 1.0, skyY));
    vec3 env = mix(mirrored, sky, 0.35);
    vec2 q = r.xy - lightDir * 0.45;
    q = mat2(lightDir.x, -lightDir.y, lightDir.y, lightDir.x) * q;
    env += smoothstep(0.32, 0.18, abs(q.x)) * smoothstep(0.55, 0.3, abs(q.y)) * GlassC.w * 0.016;
    col = mix(col, env * GlassReflect.rgb, reflAmount);

    if (GlassD.x > 0.001) {
        float film = interior * 1.1 + (1.0 - cosTheta) * 1.6 + noise(aspectUv(uv) * 3.0 + t * 0.15) * 0.5 + t * 0.04;
        vec3 irid = 0.5 + 0.5 * cos(TAU * (film + vec3(0.0, 0.33, 0.67)));
        col += (irid - 0.35) * GlassD.x * 0.01 * (bevelMask * 0.4 + fresnel * 0.7 + 0.05) * 0.6;
    }

    col += GlassBevel.rgb * bevelMask * lit * lit * edgeLight * 0.55;

    float rimLine = exp(-dist * dist / 0.9);
    col += GlassBevel.rgb * rimLine * (0.35 + 0.65 * lit) * edgeLight * 0.85;
    float facetLine = exp(-pow((dist - radius) / 0.6, 2.0));
    col += GlassBevel.rgb * facetLine * sharp * (0.25 + 0.75 * lit) * edgeLight * 0.55;

    float diag = uv.x * (Info.z / Info.w) * 0.7 + uv.y;
    float sweepPos = fract(t * 0.12) * 3.4 - 0.7;
    float band = exp(-pow((diag - sweepPos) * 9.0, 2.0)) + 0.4 * exp(-pow((diag - sweepPos + 0.12) * 22.0, 2.0));
    col += GlassReflect.rgb * band * GlassC.z * 0.005 * (0.4 + 0.6 * interior);

    vec3 key = normalize(vec3(lightDir * 0.75, 0.66));
    float rk = max(dot(r, key), 0.0);
    col += GlassReflect.rgb * (pow(rk, 160.0) * 1.6 + pow(rk, 24.0) * 0.12) * GlassC.y * 0.01;
    return col;
}

float waveHeight(vec2 p, float t) {
    float h = 0.0;
    float amp = 1.0;
    float freq = 0.6 + WaterB.x * 3.0;
    float chop = max(WaterA.w, 1.0);
    vec2 dir = normalize(vec2(1.0, 0.35));
    for (int i = 0; i < 5; i++) {
        float w = sin(dot(dir, p) * freq + t * (1.0 + 0.35 * float(i)));
        h += pow(0.5 + 0.5 * w, 1.0 + chop * 0.35) * amp;
        dir = mat2(0.8, -0.6, 0.6, 0.8) * dir;
        freq *= 1.7;
        amp *= 0.5;
    }
    return h * WaterA.z;
}

vec3 waterEffect(vec2 uv, vec3 n) {
    float t = Info.x * WaterA.x * 1.5;
    vec2 p = aspectUv(uv) * WaterA.y * 6.0 + n.xy * 1.5;
    float e = 0.04;
    float h = waveHeight(p, t);
    float hx = waveHeight(p + vec2(e, 0.0), t) - h;
    float hy = waveHeight(p + vec2(0.0, e), t) - h;
    vec3 wn = normalize(vec3(-hx / e, -hy / e, 1.6));

    vec3 lightDir = normalize(vec3(-0.45, 0.65, 0.6));
    float diffuse = clamp(dot(wn, lightDir), 0.0, 1.0);
    vec3 col = mix(WaterColor.rgb * 0.35, mix(WaterColor.rgb, vec3(1.0), 0.25), diffuse);

    float fold = abs(sin(h * 7.0 - t * 0.6 + noise(p * 0.7) * 2.0));
    col = mix(col, WaterHighlight.rgb, clamp(pow(1.0 - fold, 10.0) * WaterB.w, 0.0, 1.0));
    col += WaterHighlight.rgb * pow(max(dot(reflect(-lightDir, wn), vec3(0.0, 0.0, 1.0)), 0.0), 40.0) * WaterB.z * 2.0;

    vec3 behind = sceneAt(uv + wn.xy * WaterB.y * px() * 3.0);
    return mix(behind, col, WaterColor.a);
}

float swirl(vec2 p, float t) {
    vec2 q = p;
    q.x += 0.6 * sin(q.y * 1.3 + t * 0.7);
    q.y += 0.6 * cos(q.x * 1.1 - t * 0.5);
    q.x += 0.3 * sin(q.y * 2.3 - t * 0.4);
    return 0.5 + 0.5 * sin(q.x * 1.7 + q.y * 0.9 + noise(q * 0.8) * 1.5);
}

vec3 chromeEffect(vec2 uv, vec3 handRgb, vec3 n) {
    float t = Info.x * ChromeA.z;
    vec2 p = aspectUv(uv) * (1.0 + ChromeA.w * 1.5) * 3.0 + n.xy * 2.0;
    float s = swirl(p, t);
    float hi = smoothstep(0.72, 0.98, s);
    float soft = smoothstep(0.35, 0.9, s) * 0.35;
    vec3 base = ChromeTint.rgb * (0.55 + 0.6 * luma(handRgb) * Common.y + 0.45 * (1.0 - Common.y));
    vec3 col = base + ChromeHighlight.rgb * (hi + soft) * ChromeTint.a;
    float rim = pow(clamp(1.0 - n.z, 0.0, 1.0), 1.0 / max(ChromeA.x * 0.25, 0.05)) * ChromeA.y;
    return col + ChromeHighlight.rgb * rim * 0.6;
}

float metalField(vec2 p, float t) {
    float wx = MetalB.y;
    float wy = MetalB.z;
    int octaves = clamp(int(MetalE.y + 0.5), 1, 5);
    for (int i = 1; i <= 5; i++) {
        if (i > octaves) break;
        float fi = float(i);
        p.x += wx / fi * sin(fi * MetalA.z * 0.3 * p.y + t + 0.3 * fi);
        p.y += wy / fi * cos(fi * MetalA.y * 0.3 * p.x + t * 1.3 + 0.7 * fi);
        p.x += wx * 0.5 / fi * sin(MetalB.x * 0.3 * p.y - t * 0.7);
        p.y += wy * 0.5 / fi * cos(MetalA.w * 0.3 * p.x + t * 0.9);
    }
    int pattern = int(MetalD.y + 0.5);
    if (pattern == 1) return 0.5 + 0.125 * (sin(p.x) + sin(p.y) + sin(p.x + p.y) + sin(length(p) + t));
    if (pattern == 2) return 0.5 + 0.5 * sin(length(p) * 2.0 - t * 2.0);
    if (pattern == 3) return 0.5 + 0.5 * sin(p.x * 1.5 + 3.0 * noise(p * 0.8 + t * 0.2));
    return 0.5 + 0.5 * sin(p.x * 0.8 + sin(p.y * 0.9 + t));
}

vec3 metalPalette(float x) {
    x = fract(x + Info.x * MetalD.w * 0.05);
    float s = x * 4.0;
    if (s < 1.0) return mix(MetalColor1.rgb, MetalColor2.rgb, smoothstep(0.0, 1.0, s));
    if (s < 2.0) return mix(MetalColor2.rgb, MetalColor3.rgb, smoothstep(0.0, 1.0, s - 1.0));
    if (s < 3.0) return mix(MetalColor3.rgb, MetalColor4.rgb, smoothstep(0.0, 1.0, s - 2.0));
    return mix(MetalColor4.rgb, MetalColor1.rgb, smoothstep(0.0, 1.0, s - 3.0));
}

vec3 metalEffect(vec2 uv, vec3 n) {
    float t = Info.x * MetalC.x;
    vec2 p = (aspectUv(uv) - vec2(Info.z / Info.w * 0.5, 0.5)) * MetalA.x * 4.0;
    float a = MetalE.x;
    p = mat2(cos(a), -sin(a), sin(a), cos(a)) * p + n.xy * 0.6;

    float v = metalField(p, t);
    vec3 col = metalPalette(v);

    if (MetalC.y > 0.001) col.r = mix(col.r, metalPalette(metalField(p + vec2(MetalC.y * 0.08, 0.0), t)).r, 0.75);
    if (MetalC.z > 0.001) col.b = mix(col.b, metalPalette(metalField(p - vec2(MetalC.z * 0.08, 0.0), t)).b, 0.75);

    float f = fract(v * (1.0 + MetalC.w * 8.0));
    float soft = max(MetalD.x, 0.01);
    float band = smoothstep(0.5 - soft * 0.5, 0.5, f) * smoothstep(0.5 + soft * 0.5, 0.5, f);
    col = mix(col, col * 1.6 + 0.1, band * MetalC.w);

    float dv = metalField(p + vec2(0.03, 0.03), t) - v;
    col += pow(clamp(dv * 12.0 + 0.5, 0.0, 1.0), 6.0) * MetalD.z;
    col *= MetalB.w * 0.5;
    return col + pow(clamp(1.0 - n.z, 0.0, 1.0), 1.2) * MetalE.z * metalPalette(v + 0.25);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * noise(p);
        p = mat2(1.6, 1.2, -1.2, 1.6) * p + 17.3;
        a *= 0.5;
    }
    return v / 0.96875;
}

vec3 handColorAt(vec2 uv) {
    vec4 h = texture(HandSampler, uv);
    return h.a > 0.001 ? h.rgb / h.a : vec3(0.0);
}

vec3 starLayer(vec2 sp, float cellPx, float density, float twinkleAmount, float t) {
    vec2 cell = floor(sp);
    float h = hash(cell);
    if (h < 1.0 - density) return vec3(0.0);
    vec2 offset = vec2(hash(cell + 1.7), hash(cell + 4.1)) - 0.5;
    vec2 f = (fract(sp) - 0.5 - offset * 0.7) * cellPx;
    float bright = fract(h * 37.31);
    float radius = 0.6 + 1.1 * bright * bright;
    float star = exp(-dot(f, f) / (radius * radius));

    if (bright > 0.85) {
        star += (exp(-abs(f.x) * 0.9) * exp(-abs(f.y) * 0.12) + exp(-abs(f.y) * 0.9) * exp(-abs(f.x) * 0.12)) * 0.25;
    }
    float tw = mix(1.0, 0.55 + 0.45 * sin(t * (1.5 + h * 5.0) + h * 61.0), twinkleAmount);
    vec3 tint = mix(vec3(0.72, 0.84, 1.0), vec3(1.0, 0.9, 0.74), hash(cell + 9.3));
    return tint * star * (0.3 + 0.9 * bright) * tw;
}

vec3 auroraEffect(vec2 uv, vec3 n) {
    float t = Info.x * AuroraA.x;
    float size = max(AuroraA.z, 0.1);
    vec2 p = aspectUv(uv) / size + n.xy * 0.05;
    vec3 sky = AuroraSky.rgb * (0.6 + 0.8 * (1.0 - clamp(uv.y, 0.0, 1.0)));
    if (AuroraA.w > 0.001) {
        sky += starLayer(aspectUv(uv) * 60.0 + n.xy * 2.0, Info.w / 60.0, 0.12 * AuroraA.w, 0.7, t * 2.0) * 0.8;
    }
    vec3 light = vec3(0.0);
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float x = p.x * (1.2 + fi * 0.35) + fi * 1.9;
        float drift = t * 0.08 * (1.0 + fi * 0.3);

        float hem = -0.02 + fi * 0.21 + (fbm(vec2(x * 0.7 - drift, fi * 4.3 + t * 0.02)) - 0.5) * 0.55;
        float d = p.y - hem;

        float curtain = d >= 0.0 ? exp(-d * 4.5) : exp(d * 40.0);

        float rays = 0.3 + 0.7 * pow(noise(vec2(x * 70.0 + sin(t * 0.3 + fi) * 3.0, p.y * 1.5 + fi * 7.3 + t * 0.3)), 1.3);
        float folds = smoothstep(0.28, 0.68, fbm(vec2(x * 1.6 - drift * 2.0, fi * 2.1 + 9.0)));
        vec3 c = mix(AuroraColor1.rgb, AuroraColor2.rgb, smoothstep(0.04, 0.3, d));

        c = mix(c, vec3(1.0), 0.3 * exp(-abs(d) * 45.0));
        light += c * curtain * rays * folds * (2.8 - fi * 0.5);
    }

    light = vec3(1.0) - exp(-light * AuroraA.y * 1.5);
    return sky * (1.0 - 0.5 * clamp(luma(light) * 2.0, 0.0, 1.0)) + light;
}

vec3 galaxyEffect(vec2 uv, vec3 n) {
    float t = Info.x * GalaxyA.x;
    float scale = max(GalaxyB.x, 0.1);
    vec2 q = aspectUv(uv) / scale * 4.0 + n.xy * 0.25;
    vec2 w = vec2(fbm(q + vec2(0.0, t * 0.06)), fbm(q + vec2(5.2, 1.3) - t * 0.05));
    float neb = fbm(q + 2.2 * w + vec2(t * 0.03, 0.0));
    float neb2 = fbm(q * 1.6 - 1.7 * w.yx + 3.3);
    float dust = smoothstep(0.3, 0.65, fbm(q * 2.6 + 7.0 + w));
    vec3 col = mix(GalaxyColor1.rgb, GalaxyColor2.rgb, 0.5) * 0.06;
    col += GalaxyColor1.rgb * pow(smoothstep(0.2, 0.9, neb), 1.3) * 1.5;
    col += GalaxyColor2.rgb * pow(smoothstep(0.3, 0.95, neb2), 1.2) * 1.3 * (0.5 + w.x);
    col += vec3(1.0, 0.95, 0.9) * pow(smoothstep(0.3, 0.75, neb * neb2), 2.0) * 0.7;
    col *= (0.5 + 0.5 * dust) * GalaxyA.y;
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float cells = (45.0 + fi * 30.0) / scale;
        vec2 sp = aspectUv(uv) * cells + n.xy * (1.5 + fi * 2.0) + fi * 13.7;
        col += starLayer(sp, Info.w / cells, GalaxyA.z * (0.18 - fi * 0.04), GalaxyA.w, t * 2.0 + fi) * (1.1 - fi * 0.25);
    }
    return col;
}

vec3 hologramEffect(vec2 uv, vec3 n) {
    float t = Info.x;
    float y = gl_FragCoord.y;
    float slot = floor(t * 9.0);

    float bandHeight = max(Info.w / 90.0, 2.0);
    float band = floor(y / bandHeight);
    float slipping = step(1.0 - HoloA.z * 0.1, hash(vec2(band * 0.37, slot)));
    float jolt = step(1.0 - HoloA.z * 0.04, hash(vec2(slot, 3.7)));
    float shift = (hash(vec2(band, slot + 0.5)) - 0.5) * 30.0 * slipping + (hash(vec2(slot, 1.1)) - 0.5) * 10.0 * jolt;
    vec2 su = uv + vec2(shift * px().x, 0.0);
    float split = (1.0 + 3.0 * max(slipping, jolt)) * px().x;
    vec3 lum = vec3(luma(handColorAt(su + vec2(split, 0.0))), luma(handColorAt(su)), luma(handColorAt(su - vec2(split, 0.0))));

    vec3 body = HoloColor.rgb * mix(vec3(0.6), 0.15 + 1.25 * lum, 0.5 + 0.5 * Common.y);
    float s = fract((y - t * 22.0) / max(HoloA.y, 2.0));
    float scan = 1.0 - HoloA.x * 0.65 * pow(0.5 + 0.5 * cos(TAU * s), 3.0);
    float sweepY = fract(t * 0.3) * 1.6 - 0.3;
    float sweep = exp(-pow((uv.y - sweepY) * 14.0, 2.0));
    float rim = pow(clamp(1.0 - n.z, 0.0, 1.0), 1.2) * 2.2;
    float flick = 1.0 - HoloA.w * (0.1 * (0.5 + 0.5 * sin(t * 37.0)) + 0.4 * step(0.92, hash(vec2(floor(t * 14.0), 8.1))));
    vec3 holo = (body * scan + HoloColor.rgb * rim + mix(HoloColor.rgb, vec3(1.0), 0.5) * sweep * 0.45) * flick;
    vec3 behind = sceneAt(uv + n.xy * px() * 4.0) * mix(vec3(1.0), HoloColor.rgb, 0.25);
    return behind * (1.0 - 0.85 * HoloColor.a) + holo * HoloColor.a;
}

vec3 electricEffect(vec2 uv, vec3 n) {
    float t = Info.x * ElectricA.x;
    float zoom = 3.0 / max(ElectricA.z, 0.1);
    vec2 p = aspectUv(uv) * zoom + n.xy * 0.35;
    float pixel = zoom / Info.w;
    float core = 0.0;
    float halo = 0.0;
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float k = 1.0 + fi * 0.45;
        vec2 q = p * k + vec2(fi * 3.1, -fi * 1.7);
        float tt = t * (1.2 + fi * 0.35);
        q += (vec2(fbm(q * 0.9 + vec2(tt * 0.6, 0.0)), fbm(q * 0.9 + vec2(4.0, -tt * 0.5))) - 0.5) * 1.8;
        q += vec2(0.0, tt * 0.25);
        float v = fbm(q);

        vec2 slope = (vec2(fbm(q + vec2(0.01, 0.0)), fbm(q + vec2(0.0, 0.01))) - v) / 0.01;
        float d = abs(v - 0.5) / max(length(slope) * pixel * k, 1e-5);
        float live = smoothstep(0.68 - ElectricA.y * 0.5, 0.82 - ElectricA.y * 0.5,
                noise(q * 0.6 + vec2(tt * 1.7, fi * 5.0)));
        float flick = 0.6 + 0.4 * noise(vec2(tt * 9.0, fi * 3.3));
        core += live * flick * clamp(2.0 - d * 0.55, 0.0, 1.0);
        halo += live * flick * exp(-d * 0.08);
    }

    vec3 col = ElectricColor.rgb * (0.04 + 0.14 * pow(fbm(p * 1.5 + vec2(t * 0.2, -t * 0.15)), 2.0)) + vec3(0.01, 0.012, 0.025);
    col += ElectricColor.rgb * (0.08 + 0.05 * sin(t * 3.0)) * (1.0 - n.z) * 4.0;
    col += ElectricColor.rgb * halo * 0.5 * ElectricA.w;
    col += mix(ElectricColor.rgb, vec3(1.0), 0.75) * min(core, 1.5) * ElectricA.w;
    return col;
}

vec2 cellDistances(vec2 p, float t) {
    vec2 g = floor(p);
    vec2 f = fract(p);
    float d1 = 8.0;
    float d2 = 8.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 o = vec2(x, y);
            vec2 h = vec2(hash(g + o), hash(g + o + 19.19));
            vec2 r = o + 0.5 + 0.38 * sin(t + TAU * h) - f;
            float d = dot(r, r);
            if (d < d1) {
                d2 = d1;
                d1 = d;
            } else if (d < d2) {
                d2 = d;
            }
        }
    }
    return vec2(sqrt(d1), sqrt(d2));
}

vec3 lavaEffect(vec2 uv, vec3 n) {
    float t = Info.x * LavaA.x;
    vec2 p = aspectUv(uv) * 5.0 / max(LavaA.w, 0.1) + n.xy * 0.4;
    p += (vec2(fbm(p * 0.45 + t * 0.08), fbm(p * 0.45 - t * 0.08 + 3.0)) - 0.5) * 1.2;
    vec2 cd = cellDistances(p, t * 0.5);
    float edge = cd.y - cd.x;
    float width = 0.04 + LavaA.y * 0.22;
    float crack = 1.0 - smoothstep(0.0, width, edge);
    float heat = fbm(p * 1.3 - t * 0.2);
    float pulse = 0.75 + 0.25 * sin(t * 1.8 + heat * 6.0);
    vec3 crust = LavaCrust.rgb * (0.55 + 0.9 * fbm(p * 4.0 + 2.0));
    crust += LavaHot.rgb * exp(-edge / (width * 2.5)) * heat * 0.5 * LavaA.z;
    vec3 molten = mix(LavaHot.rgb, vec3(1.0, 0.92, 0.55), crack * crack * pulse * 0.8);
    return mix(crust, molten * (0.6 + 0.6 * LavaA.z * pulse), crack);
}

vec3 shaderColor(vec2 uv) {
    int effect = int(Info.y + 0.5);
    vec3 flatN = vec3(0.0, 0.0, 1.0);
    vec3 c;
    if (effect == 1) {
        c = mix(GlassBevel.rgb, GlassTint.rgb, 0.35 + 0.25 * sin(Info.x * 0.8 + (uv.x - uv.y) * 5.0));
    } else if (effect == 2) {
        c = waterEffect(uv, flatN);
    } else if (effect == 3) {
        c = chromeEffect(uv, vec3(0.5), flatN);
    } else if (effect == 4) {
        c = metalEffect(uv, flatN);
    } else if (effect == 5) {
        c = auroraEffect(uv, flatN);
    } else if (effect == 6) {
        c = galaxyEffect(uv, flatN);
    } else if (effect == 7) {
        c = HoloColor.rgb * (0.85 + 0.15 * sin(Info.x * 3.0 + uv.y * 40.0));
    } else if (effect == 8) {
        c = mix(ElectricColor.rgb, vec3(1.0), 0.25 + 0.25 * sin(Info.x * ElectricA.x * 7.0 + (uv.x + uv.y) * 9.0));
    } else if (effect == 9) {
        c = mix(LavaHot.rgb, vec3(1.0, 0.85, 0.4), 0.3 + 0.3 * sin(Info.x * LavaA.x * 2.0 + (uv.x - uv.y) * 8.0));
    } else {
        c = FillColor.rgb;
    }
    float peak = max(max(c.r, c.g), c.b);
    return clamp(c / max(peak, 0.3), 0.0, 1.0) * 0.85;
}

vec4 over(vec4 top, vec4 bottom) {
    float a = top.a + bottom.a * (1.0 - top.a);
    if (a < 1e-5) return vec4(0.0);
    return vec4((top.rgb * top.a + bottom.rgb * bottom.a * (1.0 - top.a)) / a, a);
}

void main() {
    vec2 uv = texCoord;
    vec4 hand = texture(HandSampler, uv);
    vec2 p = px();

    vec4 handAvg = hand;
    if (Edge.x > 0.5) {
        handAvg = 0.25 * (texture(HandSampler, uv + vec2(0.5, 0.5) * p)
                        + texture(HandSampler, uv + vec2(-0.5, 0.5) * p)
                        + texture(HandSampler, uv + vec2(0.5, -0.5) * p)
                        + texture(HandSampler, uv + vec2(-0.5, -0.5) * p));
    }
    float cover = handAvg.a;

    bool distValid = Radii.z > 0.5;
    vec4 dist = distValid ? distAt() : vec4(0.0);

    float outlineAmt = 0.0;
    if (Edge.y > 0.5 && distValid) {
        float d = outsideDistance(dist);
        float w = Edge.z;
        float fade = 0.5 + Edge.w * w;
        outlineAmt = (1.0 - smoothstep(w - fade, w + 0.5, d)) * OutlineCfg.x;
    }
    float glowAmt = Radii.w > 0.5 ? glowAt(uv) : 0.0;

    if (cover < 0.001 && outlineAmt < 0.002 && glowAmt < 0.0005) {
        discard;
    }

    vec4 result = vec4(0.0);
    vec3 accent = vec3(0.0);
    if (outlineAmt > 0.0 || glowAmt > 0.0 || Common.z > 0.0) {
        accent = outlineColor(uv);
    }
    if (glowAmt > 0.0) {
        float g = pow(clamp(glowAmt * 2.0, 0.0, 1.0), GlowCfg.z) * GlowCfg.x;
        result = vec4(accent, clamp(g, 0.0, 1.0));
    }
    if (outlineAmt > 0.0) {
        result = over(vec4(accent, outlineAmt), result);
    }

    if (cover > 0.001) {
        vec3 handRgb = handAvg.rgb / cover;
        int effect = int(Info.y + 0.5);
        vec3 n = handNormal(uv);
        vec3 col;
        if (effect == 1) {
            vec2 outward = vec2(0.0);
            float d = distValid ? insideDistance(dist, outward) : NO_EDGE;
            col = glassEffect(uv, handRgb, d, outward);
        } else if (effect == 2) {
            col = waterEffect(uv, n);
        } else if (effect == 3) {
            col = chromeEffect(uv, handRgb, n);
        } else if (effect == 4) {
            col = metalEffect(uv, n);
        } else if (effect == 5) {
            col = auroraEffect(uv, n);
        } else if (effect == 6) {
            col = galaxyEffect(uv, n);
        } else if (effect == 7) {
            col = hologramEffect(uv, n);
        } else if (effect == 8) {
            col = electricEffect(uv, n);
        } else if (effect == 9) {
            col = lavaEffect(uv, n);
        } else {
            col = mix(handRgb, FillColor.rgb, FillColor.a);
        }

        if (effect >= 2 && effect != 7) {
            col *= mix(1.0, 0.6 + luma(handRgb) * 0.8, Common.y * 0.5);
        }

        if (Common.w > 0.001) {
            float lines = textureLines(uv) * Common.w * (effect == 1 ? 0.35 : 1.0);
            col = mix(col, col * 1.15 + vec3(0.3), lines * 0.6);
        }
        col = mix(handRgb, col, Common.x);
        if (Common.z > 0.0) {
            col += pow(clamp(1.0 - n.z, 0.0, 1.0), 3.0) * Common.z * 0.7 * accent;
        }
        result = over(vec4(col, cover), result);
    }

    if (result.a <= 0.001) {
        discard;
    }
    fragColor = result;
}
