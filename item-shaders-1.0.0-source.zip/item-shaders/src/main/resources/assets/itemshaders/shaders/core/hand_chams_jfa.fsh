#version 330

uniform sampler2D InSampler;
#ifdef INIT

uniform sampler2D BlurSampler;
#else
uniform sampler2D OrientSampler;
#endif

out vec4 fragColor;

const vec2 NONE = vec2(0.0);

vec2 encode(vec2 offset) {
    return (offset + 128.0) / 255.0;
}

#ifndef INIT

void edgeNormals(vec4 o, out vec2 n1, out vec2 n2) {
    float aa = atan(o.y, o.x) * 0.5;
    float ab = atan(o.w, o.z) * 0.5;
    n1 = vec2(cos(aa), sin(aa));
    n2 = vec2(cos(ab), sin(ab));
    if (abs(dot(n1, n2)) > 0.85) n2 = vec2(-n1.y, n1.x);
}

float gridDistance(vec2 offset, vec2 n1, vec2 n2) {
    return max(abs(dot(offset, n1)), abs(dot(offset, n2)));
}

vec4 decodeOrient(vec4 stored) {
    return (stored * 255.0 - 128.0) / 127.0;
}

vec4 orientAt(vec2 uv) {
    ivec2 size = textureSize(OrientSampler, 0);
    vec2 pos = uv * vec2(size) - 0.5;
    ivec2 base = ivec2(floor(pos));
    vec2 f = pos - vec2(base);
    vec4 first = decodeOrient(texelFetch(OrientSampler, clamp(base, ivec2(0), size - 1), 0));
    vec4 sum = vec4(0.0);
    for (int i = 0; i < 4; i++) {
        ivec2 o = ivec2(i & 1, i >> 1);
        vec4 c = decodeOrient(texelFetch(OrientSampler, clamp(base + o, ivec2(0), size - 1), 0));
        if (dot(c.xy, first.xy) + dot(c.zw, first.zw) < dot(c.xy, first.zw) + dot(c.zw, first.xy)) {
            c = c.zwxy;
        }
        float w = (o.x == 1 ? f.x : 1.0 - f.x) * (o.y == 1 ? f.y : 1.0 - f.y);
        sum += c * w;
    }
    return sum;
}

void consider(vec2 stored, vec2 jump, bool grid, vec2 n1, vec2 n2, inout vec2 best, inout float bestLen) {
    vec2 raw = floor(stored * 255.0 + 0.5);
    if (raw.x < 0.5) return;
    vec2 candidate = jump + raw - 128.0;
    if (abs(candidate.x) > 127.0 || abs(candidate.y) > 127.0) return;
    float len;
    if (grid) {
        len = gridDistance(candidate, n1, n2) + dot(candidate, candidate) * 1e-5;
    } else {
        len = dot(candidate, candidate);
    }
    if (len < bestLen) {
        bestLen = len;
        best = candidate;
    }
}
#endif

void main() {
    ivec2 size = textureSize(InSampler, 0);
    ivec2 p = ivec2(gl_FragCoord.xy);

#ifdef INIT
    float alpha = texelFetch(InSampler, p, 0).a;
    vec4 b = texelFetch(BlurSampler, p, 0);
    float surface = b.r + b.a / 255.0;
    bool inside = alpha >= 0.5;

    bool outside = !inside && surface < 0.5;
    fragColor = vec4(outside ? encode(vec2(0.0)) : NONE, inside ? encode(vec2(0.0)) : NONE);
#else
    vec2 n1;
    vec2 n2;
    edgeNormals(orientAt((vec2(p) + 0.5) / vec2(size)), n1, n2);
    vec2 bestOut = vec2(0.0);
    vec2 bestIn = vec2(0.0);
    float outLen = 1e9;
    float inLen = 1e9;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            ivec2 jump = ivec2(x, y) * STEP;
            ivec2 q = p + jump;
            if (q.x < 0 || q.y < 0 || q.x >= size.x || q.y >= size.y) continue;
            vec4 c = texelFetch(InSampler, q, 0);
            consider(c.rg, vec2(jump), true, n1, n2, bestOut, outLen);
            consider(c.ba, vec2(jump), false, n1, n2, bestIn, inLen);
        }
    }
    fragColor = vec4(outLen < 1e8 ? encode(bestOut) : NONE, inLen < 1e8 ? encode(bestIn) : NONE);
#endif
}
