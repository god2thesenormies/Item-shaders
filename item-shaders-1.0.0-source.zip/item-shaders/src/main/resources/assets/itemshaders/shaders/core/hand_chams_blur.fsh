#version 330

uniform sampler2D InSampler;

layout(std140) uniform HandChamsConfig {
    vec4 Info;
    vec4 Radii;
};

in vec2 texCoord;

out vec4 fragColor;

#ifdef HORIZONTAL
const vec2 DIR = vec2(1.0, 0.0);
#else
const vec2 DIR = vec2(0.0, 1.0);
#endif

float fetch(vec2 uv, int channel) {
    vec4 c = texture(InSampler, uv);
#ifdef HORIZONTAL
    return c.a;
#else
    if (channel == 0) return c.r + c.a / 255.0;
    if (channel == 2) return c.b;
    return c.g * c.g;
#endif
}

float blur(vec2 uv, int channel, float radius, int taps) {
    if (radius < 0.5) {
        return fetch(uv, channel);
    }
    vec2 texel = DIR / Info.zw;
    float sigma = radius * 0.5;
    float stepPx = radius / float(taps);
    float sum = 0.0;
    float weights = 0.0;
    for (int i = -16; i <= 16; i++) {
        if (i < -taps || i > taps) continue;
        float x = float(i) * stepPx;
        float w = exp(-(x * x) / (2.0 * sigma * sigma));
        sum += fetch(uv + texel * x, channel) * w;
        weights += w;
    }
    return sum / weights;
}

void main() {
    vec2 uv = texCoord;
    float surface = blur(uv, 0, Radii.x, clamp(int(Radii.x / 3.0), 4, 12));
    float glow = Radii.w > 0.5 ? blur(uv, 1, Radii.y, clamp(int(Radii.y / 2.5), 6, 16)) : 0.0;
    float edges = blur(uv, 2, 3.0, 3);

    float scaled = clamp(surface, 0.0, 1.0) * 255.0;
    float hi = floor(scaled);

    float dither = (fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5) / 255.0;
    fragColor = vec4(hi / 255.0, clamp(sqrt(glow) + dither, 0.0, 1.0), edges, scaled - hi);
}
