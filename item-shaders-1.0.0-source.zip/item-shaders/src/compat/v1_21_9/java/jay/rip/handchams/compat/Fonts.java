package jay.rip.handchams.compat;

import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.client.renderer.texture.AbstractTexture;

public final class Fonts {
    private Fonts() {
    }

    public static void smooth(AbstractTexture texture) {
        texture.getTexture().setTextureFilter(FilterMode.LINEAR, false);
    }
}
