package jay.rip.handchams.compat;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;

public final class Samplers {
    private Samplers() {
    }

    public static void bind(RenderPass pass, String name, RenderTarget from, boolean linear) {
        GpuTexture texture = from.getColorTexture();
        texture.setTextureFilter(linear ? FilterMode.LINEAR : FilterMode.NEAREST, false);
        texture.setAddressMode(AddressMode.CLAMP_TO_EDGE);
        pass.bindSampler(name, from.getColorTextureView());
    }
}
