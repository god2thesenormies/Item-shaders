package jay.rip.handchams.mixin;

import com.mojang.blaze3d.font.GlyphProvider;
import com.mojang.blaze3d.font.TrueTypeGlyphProvider;
import jay.rip.handchams.ItemShaders;
import jay.rip.handchams.ui.framework.SmoothFonts;
import net.minecraft.client.gui.font.providers.TrueTypeGlyphProviderDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(TrueTypeGlyphProviderDefinition.class)
public abstract class TrueTypeGlyphProviderDefinitionMixin {
    @Shadow
    @Final
    private ResourceLocation location;

    @Inject(method = "load", at = @At("RETURN"))
    private void itemshaders$unhintMenuFonts(ResourceManager resourceManager, CallbackInfoReturnable<GlyphProvider> cir) {
        if (ItemShaders.MOD_ID.equals(location.getNamespace())
                && cir.getReturnValue() instanceof TrueTypeGlyphProvider provider) {
            SmoothFonts.markUnhinted(((TrueTypeGlyphProviderAccessor) provider).itemshaders$face());
        }
    }
}
