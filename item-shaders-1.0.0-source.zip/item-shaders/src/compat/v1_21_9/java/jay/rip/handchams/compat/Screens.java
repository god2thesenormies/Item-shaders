package jay.rip.handchams.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

public final class Screens {
    private Screens() {
    }

    public static void resize(Screen screen, int width, int height) {
        screen.resize(Minecraft.getInstance(), width, height);
    }
}
