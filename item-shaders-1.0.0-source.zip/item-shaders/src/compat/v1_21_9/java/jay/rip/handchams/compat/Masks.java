package jay.rip.handchams.compat;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

public final class Masks {
    private static final Map<String, ResourceLocation> IDS = new HashMap<>();

    private Masks() {
    }

    private static ResourceLocation id(String path) {
        return IDS.computeIfAbsent(path, Ids::of);
    }

    public static void register(String path, String debugName, NativeImage image) {
        Minecraft.getInstance().getTextureManager()
                .register(id(path), new DynamicTexture(() -> debugName, image));
    }

    public static void release(String path) {
        Minecraft.getInstance().getTextureManager().release(id(path));
        IDS.remove(path);
    }

    public static void blit(GuiGraphics graphics, String path, int x, int y, int u, int v,
                            int width, int height, int regionWidth, int regionHeight, int size, int color) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, id(path), x, y, u, v,
                width, height, regionWidth, regionHeight, size, size, color);
    }
}
