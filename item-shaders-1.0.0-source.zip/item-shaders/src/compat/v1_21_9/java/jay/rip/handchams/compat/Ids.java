package jay.rip.handchams.compat;

import jay.rip.handchams.ItemShaders;
import net.minecraft.resources.ResourceLocation;

public final class Ids {
    private Ids() {
    }

    public static ResourceLocation of(String path) {
        return ResourceLocation.fromNamespaceAndPath(ItemShaders.MOD_ID, path);
    }
}
