package jay.rip.handchams.mixin;

import com.mojang.blaze3d.textures.FilterMode;
import jay.rip.handchams.compat.Fonts;
import net.minecraft.client.gui.font.TextRenderable;
import net.minecraft.client.gui.render.state.GlyphRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(GlyphRenderState.class)
public abstract class GlyphRenderStateMixin {
    @Shadow
    public abstract TextRenderable renderable();

    @ModifyArg(method = "textureSetup", at = @At(value = "INVOKE",
            target = "Lcom/mojang/blaze3d/systems/SamplerCache;getClampToEdge(Lcom/mojang/blaze3d/textures/FilterMode;)Lcom/mojang/blaze3d/textures/GpuSampler;"))
    private FilterMode itemshaders$smoothMenuFonts(FilterMode mode) {
        return Fonts.isSmooth(renderable().textureView()) ? FilterMode.LINEAR : mode;
    }
}
