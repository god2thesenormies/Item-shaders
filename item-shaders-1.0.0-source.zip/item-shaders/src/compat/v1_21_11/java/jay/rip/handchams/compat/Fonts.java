package jay.rip.handchams.compat;

import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.renderer.texture.AbstractTexture;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public final class Fonts {
    private static final Set<GpuTextureView> SMOOTH = Collections.newSetFromMap(new WeakHashMap<>());

    private Fonts() {
    }

    public static void smooth(AbstractTexture texture) {
        GpuTextureView view = texture.getTextureView();
        if (view != null) {
            SMOOTH.add(view);
        }
    }

    public static boolean isSmooth(GpuTextureView view) {
        return view != null && SMOOTH.contains(view);
    }
}
