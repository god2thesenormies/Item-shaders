package jay.rip.handchams.compat;

import jay.rip.handchams.ItemShaders;
import net.minecraft.resources.Identifier;

public final class Ids {
    private Ids() {
    }

    public static Identifier of(String path) {
        return Identifier.fromNamespaceAndPath(ItemShaders.MOD_ID, path);
    }
}
