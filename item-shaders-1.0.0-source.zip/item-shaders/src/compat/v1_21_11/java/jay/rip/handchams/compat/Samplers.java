package jay.rip.handchams.compat;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;

public final class Samplers {
    private Samplers() {
    }

    public static void bind(RenderPass pass, String name, RenderTarget from, boolean linear) {
        GpuSampler sampler = RenderSystem.getSamplerCache()
                .getClampToEdge(linear ? FilterMode.LINEAR : FilterMode.NEAREST);
        pass.bindTexture(name, from.getColorTextureView(), sampler);
    }
}
