#Requires -Version 5
<#
    Builds the mod for every supported Minecraft version and leaves the jars in dist/.
    Usage:  .\build-all.ps1
#>

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$versions = Select-String -Path 'build.gradle' -Pattern "^\s*'(1\.[0-9.]+)'\s*:" |
    ForEach-Object { $_.Matches[0].Groups[1].Value }

if (-not $versions) {
    throw 'No Minecraft versions found in build.gradle.'
}

Write-Host "Building for: $($versions -join ', ')"
foreach ($version in $versions) {
    Write-Host ''
    Write-Host "=== $version ===" -ForegroundColor Cyan
    & .\gradlew.bat build "-Pmc=$version"
    if ($LASTEXITCODE -ne 0) {
        throw "Build failed for $version"
    }
}

Write-Host ''
Write-Host 'Done:' -ForegroundColor Green
Get-ChildItem dist -Filter *.jar | ForEach-Object { Write-Host "  dist/$($_.Name)" }
