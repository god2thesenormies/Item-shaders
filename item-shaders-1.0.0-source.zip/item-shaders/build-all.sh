#!/bin/sh
# Builds the mod for every supported Minecraft version and leaves the jars in dist/.
set -eu

cd "$(dirname "$0")"

versions=$(sed -n "s/^[[:space:]]*'\(1\.[0-9.]*\)'[[:space:]]*:.*/\1/p" build.gradle)
if [ -z "$versions" ]; then
    echo "No Minecraft versions found in build.gradle." >&2
    exit 1
fi

echo "Building for:" $versions
for version in $versions; do
    echo
    echo "=== $version ==="
    ./gradlew build "-Pmc=$version"
done

echo
echo "Done:"
ls dist/*.jar | sed 's/^/  /'
